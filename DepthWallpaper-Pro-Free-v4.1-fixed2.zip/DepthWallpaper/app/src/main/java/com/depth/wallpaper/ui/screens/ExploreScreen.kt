package com.depth.wallpaper.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyGridState
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import kotlinx.coroutines.delay
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import com.depth.wallpaper.data.Category
import com.depth.wallpaper.data.Wallpaper
import com.depth.wallpaper.data.WallpaperRepository
import com.depth.wallpaper.ui.AppViewModel
import com.depth.wallpaper.ui.components.AppImage
import com.depth.wallpaper.ui.components.EmptyState
import com.depth.wallpaper.ui.components.GlassChip
import com.depth.wallpaper.ui.components.GlassSurface
import com.depth.wallpaper.ui.components.TopBar
import com.depth.wallpaper.ui.components.WallpaperCard
import com.depth.wallpaper.ui.theme.NeonCyan
import com.depth.wallpaper.ui.theme.TextPrimary
import com.depth.wallpaper.ui.theme.TextSecondary

private const val PAGE_SIZE = 18

@Composable
fun ExploreScreen(vm: AppViewModel, nav: NavHostController, initialCategory: String?) {
    val favs by vm.favorites.collectAsStateWithLifecycle()
    val online by vm.onlineWallpapers.collectAsStateWithLifecycle()
    val onlineLoading by vm.onlineLoading.collectAsStateWithLifecycle()
    val onlineError by vm.onlineError.collectAsStateWithLifecycle()
    var query by rememberSaveable { mutableStateOf("") }
    var selected by rememberSaveable(initialCategory) { mutableStateOf(initialCategory) }
    var sort by rememberSaveable { mutableStateOf("Default") }
    var page by rememberSaveable { mutableIntStateOf(1) }

    val browsing = selected != null || query.isNotBlank()
    val cat = selected?.takeIf { it != "All" }

    BackHandler(enabled = selected != null && initialCategory == null) { selected = null }

    val results = remember(online, sort) {
        if (sort == "A–Z") online.sortedBy { it.title } else online
    }
    LaunchedEffect(query, cat) {
        page = 1
        delay(400)
        vm.loadOnlineWallpapers(query, cat)
    }

    val gridState = rememberLazyGridState()
    val shown = results.take(page * PAGE_SIZE)
    val nearEnd by remember(shown.size) {
        derivedStateOf {
            (gridState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0) >= shown.size - 6
        }
    }
    LaunchedEffect(nearEnd, shown.size, browsing) {
        if (browsing && nearEnd && shown.size < results.size) page++
        else if (browsing && nearEnd && results.isNotEmpty() && !onlineLoading) vm.loadOnlineWallpapers(query, cat, append = true)
    }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        TopBar(
            title = selected?.let { if (it == "All") "All Wallpapers" else it } ?: "Explore",
            onBack = if (selected != null) {
                { if (initialCategory != null) nav.popBackStack() else selected = null }
            } else null
        )
        SearchField(query) { query = it }
        Spacer(Modifier.height(10.dp))

        if (!browsing) {
            CategoryGrid(onAll = { selected = "All" }, onCategory = { selected = it.name })
        } else {
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item { GlassChip("All", cat == null) { selected = "All" } }
                items(WallpaperRepository.categories, key = { it.name }) { c ->
                    GlassChip(c.name, cat == c.name) { selected = c.name }
                }
            }
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text("${results.size} online wallpapers", color = TextSecondary, fontSize = 12.sp, modifier = Modifier.weight(1f))
                GlassChip("Default", sort == "Default") { sort = "Default" }
                GlassChip("A–Z", sort == "A–Z") { sort = "A–Z" }
            }
            if (onlineLoading && results.isEmpty()) {
                EmptyState(
                    icon = Icons.Outlined.Search,
                    title = "Finding real wallpapers…",
                    subtitle = "Loading openly licensed images from Openverse.",
                    actionLabel = "Refresh",
                    onAction = { vm.loadOnlineWallpapers(query, cat) }
                )
            } else if (results.isEmpty()) {
                EmptyState(
                    icon = Icons.Outlined.Search,
                    title = "Online wallpapers unavailable",
                    subtitle = onlineError ?: "Try another keyword or category.",
                    actionLabel = "Retry",
                    onAction = { vm.loadOnlineWallpapers(query, cat) }
                )
            } else {
                WallpaperGrid(
                    list = shown,
                    favs = favs,
                    onFav = { vm.toggleFavorite(it.id) },
                    onOpen = { nav.navigate("preview/${it.id}") },
                    state = gridState
                )
            }
        }
    }
}

@Composable
fun WallpaperGrid(
    list: List<Wallpaper>,
    favs: Set<String>,
    onFav: (Wallpaper) -> Unit,
    onOpen: (Wallpaper) -> Unit,
    modifier: Modifier = Modifier,
    state: LazyGridState = rememberLazyGridState()
) {
    LazyVerticalGrid(
        columns = GridCells.Adaptive(150.dp),
        modifier = modifier,
        state = state,
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 130.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        items(list, key = { it.id }) { w ->
            WallpaperCard(
                w = w,
                favorite = w.id in favs,
                onToggleFav = { onFav(w) },
                onClick = { onOpen(w) },
                modifier = Modifier.fillMaxWidth(),
                badge = if (w.isOnline) "ONLINE" else "4K"
            )
        }
    }
}

@Composable
private fun SearchField(value: String, onChange: (String) -> Unit) {
    GlassSurface(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp).height(56.dp),
        RoundedCornerShape(28.dp)
    ) {
        TextField(
            value = value,
            onValueChange = onChange,
            singleLine = true,
            placeholder = { Text("Search by title or category", color = TextSecondary) },
            leadingIcon = { Icon(Icons.Outlined.Search, null, tint = TextSecondary) },
            trailingIcon = {
                if (value.isNotEmpty()) {
                    IconButton(onClick = { onChange("") }) {
                        Icon(Icons.Outlined.Close, "Clear search", tint = TextSecondary)
                    }
                }
            },
            colors = TextFieldDefaults.colors(
                focusedContainerColor = Color.Transparent,
                unfocusedContainerColor = Color.Transparent,
                focusedIndicatorColor = Color.Transparent,
                unfocusedIndicatorColor = Color.Transparent,
                cursorColor = NeonCyan,
                focusedTextColor = TextPrimary,
                unfocusedTextColor = TextPrimary
            ),
            modifier = Modifier.fillMaxSize()
        )
    }
}

@Composable
private fun CategoryGrid(onAll: () -> Unit, onCategory: (Category) -> Unit) {
    LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 130.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item(span = { GridItemSpan(maxLineSpan) }) {
            GlassSurface(Modifier.fillMaxWidth().height(56.dp), RoundedCornerShape(18.dp), onClick = onAll) {
                Text(
                    "Browse all ${WallpaperRepository.all.size} wallpapers",
                    color = NeonCyan,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.align(Alignment.Center)
                )
            }
        }
        items(WallpaperRepository.categories, key = { it.name }) { c ->
            val shape = RoundedCornerShape(22.dp)
            Box(
                Modifier
                    .fillMaxWidth()
                    .aspectRatio(1.05f)
                    .clip(shape)
                    .border(1.dp, Color.White.copy(alpha = 0.2f), shape)
                    .clickable { onCategory(c) }
            ) {
                AppImage(c.coverUrl, Modifier.fillMaxSize())
                Box(
                    Modifier.fillMaxSize()
                        .background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.78f))))
                )
                Column(Modifier.align(Alignment.BottomStart).padding(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(c.icon, null, tint = NeonCyan, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(c.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    }
                    Text("${c.count} wallpapers", color = TextSecondary, fontSize = 11.sp)
                }
            }
        }
    }
}
