package com.depth.wallpaper.ui

import android.app.Application
import android.graphics.Bitmap
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.depth.wallpaper.data.AutoWallpaper
import com.depth.wallpaper.data.BackupData
import com.depth.wallpaper.data.BackupManager
import com.depth.wallpaper.data.DownloadedFile
import com.depth.wallpaper.data.Downloader
import com.depth.wallpaper.data.HistoryEntry
import com.depth.wallpaper.data.HistoryTracker
import com.depth.wallpaper.data.OpenverseRepository
import com.depth.wallpaper.data.WallpaperRepository
import com.depth.wallpaper.data.PrefsStore
import com.depth.wallpaper.data.Resolution
import com.depth.wallpaper.data.Wallpaper
import com.depth.wallpaper.data.saveToGallery as saveImageToGallery
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val appCtx: Application = app
    private val prefs = PrefsStore(app)
    private val downloader = Downloader(app)

    val favorites: StateFlow<Set<String>> =
        prefs.favorites.stateIn(viewModelScope, SharingStarted.Eagerly, emptySet())
    val quality: StateFlow<Resolution> =
        prefs.quality.stateIn(viewModelScope, SharingStarted.Eagerly, Resolution.QHD)
    val dynamicTheme: StateFlow<Boolean> =
        prefs.dynamicTheme.stateIn(viewModelScope, SharingStarted.Eagerly, false)
    val autoMinutes: StateFlow<Int> =
        prefs.autoMinutes.stateIn(viewModelScope, SharingStarted.Eagerly, 0)
    val autoTarget: StateFlow<String> =
        prefs.autoTarget.stateIn(viewModelScope, SharingStarted.Eagerly, "favorites")

    private val _history = MutableStateFlow<List<HistoryEntry>>(emptyList())
    val history: StateFlow<List<HistoryEntry>> = _history.asStateFlow()

    /** key = "<wallpaperId>__<RES>", value = 0..1 */
    private val _progress = MutableStateFlow<Map<String, Float>>(emptyMap())
    val progress: StateFlow<Map<String, Float>> = _progress.asStateFlow()

    private val _downloads = MutableStateFlow<List<DownloadedFile>>(emptyList())
    val downloads: StateFlow<List<DownloadedFile>> = _downloads.asStateFlow()

    private val _messages = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val messages: SharedFlow<String> = _messages.asSharedFlow()

    private val _onlineWallpapers = MutableStateFlow<List<Wallpaper>>(emptyList())
    val onlineWallpapers: StateFlow<List<Wallpaper>> = _onlineWallpapers.asStateFlow()
    private val _onlineLoading = MutableStateFlow(false)
    val onlineLoading: StateFlow<Boolean> = _onlineLoading.asStateFlow()
    private val _onlineError = MutableStateFlow<String?>(null)
    val onlineError: StateFlow<String?> = _onlineError.asStateFlow()
    private var onlineQueryKey = ""
    private var onlinePage = 0
    private var onlineRequestToken = 0

    init {
        refreshDownloads()
        refreshHistory()
        loadOnlineWallpapers()
    }

    fun loadOnlineWallpapers(query: String = "", category: String? = null, append: Boolean = false) {
        val key = "${query.trim()}|${category.orEmpty()}"
        if (append && _onlineLoading.value) return
        if (!append) {
            onlineQueryKey = key
            onlinePage = 0
            _onlineWallpapers.value = emptyList()
        } else if (key != onlineQueryKey) return
        val requestedPage = if (append) onlinePage + 1 else 1
        val token = ++onlineRequestToken
        _onlineLoading.value = true
        _onlineError.value = null
        viewModelScope.launch {
            try {
                val items = withContext(Dispatchers.IO) { OpenverseRepository.search(query, category, requestedPage) }
                if (key == onlineQueryKey && token == onlineRequestToken) {
                    onlinePage = requestedPage
                    val combined = if (append) (_onlineWallpapers.value + items).distinctBy { it.id } else items
                    _onlineWallpapers.value = combined
                    WallpaperRepository.replaceRemote(combined)
                    if (combined.isEmpty()) _onlineError.value = "No openly licensed images found. Try another category or search."
                }
            } catch (e: Exception) {
                if (key == onlineQueryKey && token == onlineRequestToken) _onlineError.value = "Could not load online wallpapers. Check internet and retry."
            } finally {
                if (token == onlineRequestToken) _onlineLoading.value = false
            }
        }
    }

    fun say(msg: String) {
        _messages.tryEmit(msg)
    }

    fun toggleFavorite(id: String) {
        viewModelScope.launch { prefs.toggleFavorite(id) }
    }

    fun setQuality(r: Resolution) {
        viewModelScope.launch { prefs.setQuality(r) }
    }

    fun setDynamicTheme(v: Boolean) {
        viewModelScope.launch { prefs.setDynamicTheme(v) }
    }

    fun setAutoChange(minutes: Int) {
        viewModelScope.launch {
            prefs.setAutoMinutes(minutes)
            if (minutes > 0) AutoWallpaper.schedule(appCtx, minutes, needsNetwork = autoTarget.value == "favorites")
            else AutoWallpaper.cancel(appCtx)
        }
    }

    fun setAutoTarget(t: String) {
        viewModelScope.launch {
            prefs.setAutoTarget(t)
            if (autoMinutes.value > 0) AutoWallpaper.schedule(appCtx, autoMinutes.value, needsNetwork = t == "favorites")
        }
    }

    fun refreshHistory() {
        viewModelScope.launch(Dispatchers.IO) { _history.value = HistoryTracker.entries(appCtx).first() }
    }

    fun clearHistory() {
        viewModelScope.launch {
            HistoryTracker.clear(appCtx)
            refreshHistory()
        }
    }

    fun saveToGallery(file: File) {
        viewModelScope.launch {
            saveImageToGallery(appCtx, file, file.nameWithoutExtension)
                .onSuccess { say("Saved to Gallery → Pictures/DepthWallpaper") }
                .onFailure { say(it.message ?: "Could not save to Gallery") }
        }
    }

    fun exportBackup(uri: Uri) {
        viewModelScope.launch {
            BackupManager.export(
                appCtx, uri,
                BackupData(favorites.value, quality.value.name, dynamicTheme.value, autoMinutes.value, autoTarget.value)
            ).onSuccess { say("Backup exported") }
                .onFailure { say("Export failed") }
        }
    }

    fun importBackup(uri: Uri) {
        viewModelScope.launch {
            BackupManager.import(appCtx, uri)
                .onSuccess { b ->
                    val q = runCatching { Resolution.valueOf(b.quality) }.getOrDefault(Resolution.QHD)
                    prefs.restore(b.favorites, q, b.dynamicTheme, b.autoMinutes, b.autoTarget)
                    if (b.autoMinutes > 0) AutoWallpaper.schedule(appCtx, b.autoMinutes, needsNetwork = b.autoTarget == "favorites")
                    else AutoWallpaper.cancel(appCtx)
                    refreshHistory()
                    say("Backup restored")
                }
                .onFailure { say("Import failed. Choose a valid Depth Wallpaper backup file.") }
        }
    }

    fun refreshDownloads() {
        viewModelScope.launch(Dispatchers.IO) { _downloads.value = downloader.list() }
    }

    /** Returns the file immediately if already downloaded (no duplicate downloads). */
    suspend fun fetch(w: Wallpaper, r: Resolution): Result<File> {
        val existing = downloader.fileFor(w, r)
        if (existing.exists() && existing.length() > 0) return Result.success(existing)
        val key = "${w.id}__${r.name}"
        if (key in _progress.value) return Result.failure(IllegalStateException("Already downloading"))
        _progress.update { it + (key to 0f) }
        return try {
            val f = downloader.download(w, r) { p -> _progress.update { m -> m + (key to p) } }
            Result.success(f)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Result.failure(e)
        } finally {
            _progress.update { it - key }
            refreshDownloads()
        }
    }

    fun download(w: Wallpaper, r: Resolution) {
        viewModelScope.launch {
            val already = downloader.fileFor(w, r).exists()
            fetch(w, r)
                .onSuccess { say(if (already) "Already downloaded (${r.label})" else "Saved ${r.label} wallpaper") }
                .onFailure { say("Download failed. Check your connection and tap Download to retry.") }
        }
    }

    fun delete(d: DownloadedFile) {
        viewModelScope.launch(Dispatchers.IO) {
            d.file.delete()
            _downloads.value = downloader.list()
        }
    }

    /** Resolves a file name inside the wallpaper folder (names only, no paths). */
    fun fileNamed(name: String): File = File(downloader.dir, File(name).name)

    suspend fun saveEdited(bmp: Bitmap): File = withContext(Dispatchers.IO) {
        val f = File(downloader.dir, "custom_${System.currentTimeMillis()}__EDIT.jpg")
        f.outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 95, it) }
        _downloads.value = downloader.list()
        f
    }
}
