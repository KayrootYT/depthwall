package com.depth.wallpaper.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.ChevronRight
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.Download
import androidx.compose.material.icons.outlined.Email
import androidx.compose.material.icons.outlined.FolderOpen
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.Palette
import androidx.compose.material.icons.outlined.Save
import androidx.compose.material.icons.outlined.Schedule
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.Switch
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import com.depth.wallpaper.data.AppConfig
import com.depth.wallpaper.data.DepthConfig
import com.depth.wallpaper.data.DepthConfigStore
import com.depth.wallpaper.data.Resolution
import com.depth.wallpaper.data.openUrl
import com.depth.wallpaper.data.sendFeedback
import com.depth.wallpaper.ui.AppViewModel
import com.depth.wallpaper.ui.components.GlassChip
import com.depth.wallpaper.ui.components.GlassSurface
import com.depth.wallpaper.ui.components.TopBar
import com.depth.wallpaper.ui.theme.BrandGradient
import com.depth.wallpaper.ui.theme.GoldPro
import com.depth.wallpaper.ui.theme.NavySurface
import com.depth.wallpaper.ui.theme.NeonCyan
import com.depth.wallpaper.ui.theme.NeonPurple
import com.depth.wallpaper.ui.theme.TextPrimary
import com.depth.wallpaper.ui.theme.TextSecondary
import androidx.compose.foundation.background
import androidx.compose.ui.draw.clip

@Composable
fun ProfileScreen(vm: AppViewModel, nav: NavHostController) {
    val ctx = LocalContext.current
    val favs by vm.favorites.collectAsStateWithLifecycle()
    val downloads by vm.downloads.collectAsStateWithLifecycle()
    val quality by vm.quality.collectAsStateWithLifecycle()
    val dynamicTheme by vm.dynamicTheme.collectAsStateWithLifecycle()
    val autoMinutes by vm.autoMinutes.collectAsStateWithLifecycle()
    val autoTarget by vm.autoTarget.collectAsStateWithLifecycle()
    var perfConfig by remember { mutableStateOf(DepthConfigStore.load(ctx)) }

    fun applyPerformancePreset(preset: String) {
        val next = when (preset) {
            "Battery Saver" -> perfConfig.copy(batterySaver = true, layers = 3, bgBlur = 0f, response = 0.10f)
            "Ultra Quality" -> perfConfig.copy(batterySaver = false, layers = 7, response = 0.18f)
            else -> perfConfig.copy(batterySaver = false, layers = 5, response = 0.14f)
        }
        perfConfig = next
        DepthConfigStore.save(ctx, next)
        vm.say("$preset profile applied")
    }

    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri -> uri?.let { vm.exportBackup(it) } }
    val importLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri -> uri?.let { vm.importBackup(it) } }

    Column(Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState())) {
        TopBar("Profile", onBack = { nav.popBackStack() })

        Row(Modifier.padding(horizontal = 20.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(
                "D",
                color = TextPrimary,
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier
                    .size(64.dp)
                    .clip(CircleShape)
                    .background(BrandGradient)
                    .padding(top = 12.dp)
                    .align(Alignment.CenterVertically),
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
            Spacer(Modifier.width(14.dp))
            Column {
                Text("Depth User", color = TextPrimary, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text("Local profile · no sign-in required", color = TextSecondary, fontSize = 12.sp)
            }
        }

        GlassSurface(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
            RoundedCornerShape(22.dp),
            glow = NeonPurple.copy(alpha = 0.35f),
            onClick = { nav.navigate("studio?mode=depth") }
        ) {
            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Star, null, tint = GoldPro, modifier = Modifier.size(34.dp))
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("Pro unlocked", color = TextPrimary, fontWeight = FontWeight.Bold)
                    Text("All features are free. Open Depth Studio", color = TextSecondary, fontSize = 12.sp)
                }
                Icon(Icons.Outlined.ChevronRight, null, tint = TextSecondary)
            }
        }

        Row1(Icons.Outlined.FavoriteBorder, "My Favorites", "${favs.size} wallpapers") { nav.navigate("favorites") }
        Row1(Icons.Outlined.Download, "My Downloads", "${downloads.size} files") { nav.navigate("downloads") }
        Row1(Icons.Outlined.History, "Wallpaper History", "") { nav.navigate("history") }

        Text(
            "Premium feature hub · all 10",
            color = TextSecondary,
            fontSize = 12.sp,
            modifier = Modifier.padding(start = 20.dp, top = 18.dp, bottom = 8.dp)
        )
        GlassSurface(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp),
            RoundedCornerShape(22.dp),
            glow = NeonPurple.copy(alpha = 0.18f)
        ) {
            Column(Modifier.padding(vertical = 4.dp)) {
                Row1(Icons.Outlined.Palette, "1. AI Depth Studio Pro", "Depth controls") { nav.navigate("studio?mode=depth") }
                Row1(Icons.Outlined.Schedule, "2. Motion Parallax Pro", "Gyro / touch") { nav.navigate("studio?mode=depth") }
                Row1(Icons.Outlined.Palette, "3. Liquid Glass UI", "Premium theme") { nav.navigate("home") }
                Row1(Icons.Outlined.Lock, "4. AMOLED Battery Mode", if (perfConfig.batterySaver) "On" else "Off") {
                    applyPerformancePreset(if (perfConfig.batterySaver) "Balanced" else "Battery Saver")
                }
                Row1(Icons.Outlined.Star, "5. Daily Wallpaper Drop", "Refresh") { vm.loadOnlineWallpapers(); nav.navigate("home") }
                Row1(Icons.Outlined.Schedule, "6. Depth Clock", "Clock controls") { nav.navigate("studio?mode=clock") }
                Row1(Icons.Outlined.FavoriteBorder, "7. Smart Wallpaper Feed", "Favorites / history") { nav.navigate("favorites") }
                Row1(Icons.Outlined.Palette, "8. AI Wallpaper Generator", "Create") { nav.navigate("generate") }
                Row1(Icons.Outlined.Palette, "9. Performance Control Center", "${perfConfig.layers} layers") {
                    applyPerformancePreset("Balanced")
                }
                Row1(Icons.Outlined.Schedule, "10. Live Scene Effects", "Motion settings") { nav.navigate("studio?mode=depth") }
            }
        }

        Text(
            "Premium control center",
            color = TextSecondary,
            fontSize = 12.sp,
            modifier = Modifier.padding(start = 20.dp, top = 18.dp, bottom = 8.dp)
        )
        GlassSurface(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp),
            RoundedCornerShape(22.dp),
            glow = NeonCyan.copy(alpha = 0.16f)
        ) {
            Column(Modifier.padding(16.dp)) {
                Text("Performance profile", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text("Choose the balance between depth layers and battery use.", color = TextSecondary, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp, bottom = 12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    GlassChip("Battery Saver", perfConfig.batterySaver && perfConfig.layers <= 3) { applyPerformancePreset("Battery Saver") }
                    GlassChip("Balanced", !perfConfig.batterySaver && perfConfig.layers in 4..5) { applyPerformancePreset("Balanced") }
                }
                Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    GlassChip("Ultra Quality", !perfConfig.batterySaver && perfConfig.layers >= 7) { applyPerformancePreset("Ultra Quality") }
                    GlassChip("Open Depth Studio", false) { nav.navigate("studio?mode=depth") }
                }
                Text("Current: ${perfConfig.layers} layers · ${if (perfConfig.batterySaver) "battery saver on" else "standard frame pacing"}", color = TextSecondary, fontSize = 11.sp, modifier = Modifier.padding(top = 10.dp))
            }
        }

        GlassSurface(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
            RoundedCornerShape(20.dp),
            glow = NeonPurple.copy(alpha = 0.14f),
            onClick = { vm.loadOnlineWallpapers() }
        ) {
            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Star, null, tint = GoldPro, modifier = Modifier.size(28.dp))
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("Daily Wallpaper Drop", color = TextPrimary, fontWeight = FontWeight.Bold)
                    Text("Refresh new wallpapers from connected sources", color = TextSecondary, fontSize = 12.sp)
                }
                Icon(Icons.Outlined.ChevronRight, null, tint = TextSecondary)
            }
        }

        Text(
            "Auto wallpaper changer",
            color = TextSecondary,
            fontSize = 12.sp,
            modifier = Modifier.padding(start = 20.dp, top = 18.dp, bottom = 8.dp)
        )
        Row(
            Modifier.padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf(0 to "Off", 15 to "15 min", 30 to "30 min", 60 to "1 hour", 1440 to "Daily").forEach { (m, label) ->
                GlassChip(label, autoMinutes == m) { vm.setAutoChange(m) }
            }
        }
        Row(
            Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            GlassChip("From Favorites", autoTarget == "favorites") { vm.setAutoTarget("favorites") }
            GlassChip("From Downloads", autoTarget == "downloads") { vm.setAutoTarget("downloads") }
        }
        Text(
            "Changes the wallpaper automatically, even when the app is closed. Android may shift the timing slightly to save battery.",
            color = TextSecondary,
            fontSize = 11.sp,
            modifier = Modifier.padding(start = 20.dp)
        )

        Row(
            Modifier.fillMaxWidth().clickable { vm.setDynamicTheme(!dynamicTheme) }
                .padding(horizontal = 20.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Outlined.Palette, null, tint = NeonCyan)
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text("Dynamic theme (Material You)", color = TextPrimary, fontSize = 15.sp)
                Text("App colours follow your wallpaper. Android 12+.", color = TextSecondary, fontSize = 12.sp)
            }
            Switch(checked = dynamicTheme, onCheckedChange = { vm.setDynamicTheme(it) })
        }

        Row1(Icons.Outlined.Save, "Export backup", "favorites + settings") {
            exportLauncher.launch("depthwallpaper_backup.json")
        }
        Row1(Icons.Outlined.FolderOpen, "Import backup", "") {
            importLauncher.launch(arrayOf("*/*"))
        }

        Text(
            "Wallpaper quality",
            color = TextSecondary,
            fontSize = 12.sp,
            modifier = Modifier.padding(start = 20.dp, top = 18.dp, bottom = 8.dp)
        )
        Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Resolution.values().forEach { r ->
                GlassChip("${r.label} · ${r.dims}", quality == r) { vm.setQuality(r) }
            }
        }
        Text(
            "Used as the default resolution in the preview screen.",
            color = TextSecondary,
            fontSize = 11.sp,
            modifier = Modifier.padding(start = 20.dp, top = 6.dp)
        )

        Spacer(Modifier.height(14.dp))
        Row1(Icons.Outlined.Lock, "Privacy Policy", "") {
            if (AppConfig.PRIVACY_URL.isBlank()) vm.say("Add your Privacy Policy link in AppConfig.kt")
            else openUrl(ctx, AppConfig.PRIVACY_URL)
        }
        Row1(Icons.Outlined.Description, "Terms of Service", "") {
            if (AppConfig.TERMS_URL.isBlank()) vm.say("Add your Terms link in AppConfig.kt")
            else openUrl(ctx, AppConfig.TERMS_URL)
        }
        Row1(Icons.Outlined.Email, "Help & Feedback", "") {
            if (AppConfig.FEEDBACK_EMAIL.isBlank()) vm.say("Add your feedback email in AppConfig.kt")
            else sendFeedback(ctx, AppConfig.FEEDBACK_EMAIL)
        }
        Spacer(Modifier.height(130.dp))
    }
}

@Composable
private fun Row1(icon: ImageVector, title: String, trailing: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 20.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = NeonCyan)
        Spacer(Modifier.width(14.dp))
        Text(title, color = TextPrimary, fontSize = 15.sp, modifier = Modifier.weight(1f))
        if (trailing.isNotEmpty()) Text(trailing, color = TextSecondary, fontSize = 13.sp)
        Spacer(Modifier.width(6.dp))
        Icon(Icons.Outlined.ChevronRight, null, tint = TextSecondary)
    }
}
