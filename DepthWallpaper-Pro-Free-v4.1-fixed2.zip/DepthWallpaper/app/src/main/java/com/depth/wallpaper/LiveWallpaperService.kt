package com.depth.wallpaper

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.service.wallpaper.WallpaperService
import android.view.Choreographer
import android.view.MotionEvent
import android.view.SurfaceHolder
import com.depth.wallpaper.data.DepthConfig
import com.depth.wallpaper.data.DepthConfigStore
import com.depth.wallpaper.data.DepthMode
import com.depth.wallpaper.data.DepthPipeline
import com.depth.wallpaper.data.DepthRenderer
import com.depth.wallpaper.data.DepthScene
import com.depth.wallpaper.data.InputMode
import com.depth.wallpaper.data.ParallaxTracker
import com.depth.wallpaper.data.ParticleEffects
import com.depth.wallpaper.data.SceneBuilder
import java.io.File
import java.util.concurrent.Executors
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Live wallpaper: layered depth parallax, 3D tilt, classic parallax, optional depth clock.
 * Input can be gyroscope, touch or an automatic floating motion. Settings come from Depth Studio
 * (DepthConfigStore); the photo and its depth map are files written by the app.
 */
class LiveWallpaperService : WallpaperService() {
    override fun onCreateEngine(): Engine = DepthEngine()

    private inner class DepthEngine : Engine(), SensorEventListener, Choreographer.FrameCallback {
        private val manager = getSystemService(SENSOR_SERVICE) as SensorManager
        private val sensor = manager.getDefaultSensor(Sensor.TYPE_GAME_ROTATION_VECTOR)
            ?: manager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
        private val tracker = ParallaxTracker()
        private val renderer = DepthRenderer()
        private val particleEffects = ParticleEffects()
        private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val main = Handler(Looper.getMainLooper())
        private val decoder = Executors.newSingleThreadExecutor()
        private val imageFile get() = File(filesDir, "live_wallpaper.jpg")
        private val depthFile get() = File(filesDir, "live_depth.png")

        private var cfg = DepthConfig()
        private var scene: DepthScene? = null
        private var loadedSig = ""
        private var loading = false
        private var destroyed = false
        private var visible = false
        private var framePosted = false
        private var surfaceW = 1
        private var surfaceH = 1
        private var dirty = true
        private var lastMinute = -1L
        private var lastDraw = 0L
        private var lastParticleFrame = 0L

        override fun onCreate(surfaceHolder: SurfaceHolder) {
            super.onCreate(surfaceHolder)
            cfg = DepthConfigStore.load(this@LiveWallpaperService)
            loadIfNeeded()
        }

        override fun onVisibilityChanged(isVisible: Boolean) {
            visible = isVisible
            if (isVisible) {
                cfg = DepthConfigStore.load(this@LiveWallpaperService)
                setTouchEventsEnabled(cfg.input == InputMode.TOUCH)
                loadIfNeeded() // picks up a new photo / new settings
                tracker.reset()
                if (cfg.input == InputMode.GYRO && sensor != null) {
                    manager.registerListener(this, sensor, SensorManager.SENSOR_DELAY_GAME)
                }
                dirty = true
                postFrame()
            } else {
                manager.unregisterListener(this)
                Choreographer.getInstance().removeFrameCallback(this)
                framePosted = false
            }
        }

        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height)
            surfaceW = width.coerceAtLeast(1)
            surfaceH = height.coerceAtLeast(1)
            loadedSig = ""
            loadIfNeeded()
            dirty = true
            drawFrame()
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder) {
            visible = false
            manager.unregisterListener(this)
            Choreographer.getInstance().removeFrameCallback(this)
            framePosted = false
            super.onSurfaceDestroyed(holder)
        }

        override fun onSensorChanged(event: SensorEvent) {
            tracker.onSensor(event.values)
        }

        override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit

        override fun onTouchEvent(event: MotionEvent) {
            if (cfg.input != InputMode.TOUCH) return
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE ->
                    tracker.setTarget((event.x / surfaceW - 0.5f) * 2f, (event.y / surfaceH - 0.5f) * 2f)
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> tracker.setTarget(0f, 0f)
            }
        }

        private fun postFrame() {
            if (!framePosted && visible && !destroyed) {
                framePosted = true
                Choreographer.getInstance().postFrameCallback(this)
            }
        }

        override fun doFrame(frameTimeNanos: Long) {
            framePosted = false
            if (!visible || destroyed) return
            if (cfg.input == InputMode.AUTO) {
                val t = SystemClock.uptimeMillis() / 1000.0
                tracker.setTarget((sin(t * 0.9) * 0.9).toFloat(), (cos(t * 0.65) * 0.6).toFloat())
            }
            val moved = tracker.step(cfg.response)
            val minute = System.currentTimeMillis() / 60000L
            if (cfg.clockOn && minute != lastMinute) {
                lastMinute = minute
                dirty = true
            }
            val now = SystemClock.uptimeMillis()
            val particlesOn = cfg.particleEffect != "OFF"
            val particleInterval = if (cfg.batterySaver) 50L else 25L // 20 fps saver / up to 40 fps normal
            val particleTick = particlesOn && now - lastParticleFrame >= particleInterval
            if (moved || dirty || particleTick) {
                // Cap particle animation separately so overlays don't force full-rate GPU work.
                if (!cfg.batterySaver || dirty || now - lastDraw >= 33L || (particlesOn && now - lastDraw >= particleInterval)) {
                    lastDraw = now
                    if (particleTick) lastParticleFrame = now
                    drawFrame()
                }
            }
            postFrame()
        }

        private fun signature(): String {
            val c = cfg
            val classic = c.mode == DepthMode.CLASSIC
            val img = imageFile.let { if (it.exists()) it.lastModified() else 0L }
            val dep = depthFile.let { if (it.exists()) it.lastModified() else 0L }
            return "$img|$dep|${surfaceW}x$surfaceH|$classic|${c.layers}|${c.fgCut}|${c.bgBlur}"
        }

        private fun loadIfNeeded() {
            val sig = signature()
            if (loading || sig == loadedSig) return
            loading = true
            val w = surfaceW
            val h = surfaceH
            val c = cfg
            decoder.execute {
                val next = runCatching { buildScene(c, w, h) }.getOrNull()
                main.post {
                    loading = false
                    if (destroyed) {
                        next?.recycle()
                        return@post
                    }
                    val old = scene
                    scene = next
                    loadedSig = sig
                    dirty = true
                    old?.recycle()
                    drawFrame()
                    // Settings may have changed while we were building.
                    if (visible) loadIfNeeded()
                }
            }
        }

        private fun buildScene(c: DepthConfig, w: Int, h: Int): DepthScene? {
            val f = imageFile
            if (!f.exists()) return null
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(f.absolutePath, bounds)
            if (bounds.outWidth <= 0) return null
            val limit = (max(w, h) * 1.05f).toInt().coerceIn(720, 1280)
            var sample = 1
            while (max(bounds.outWidth, bounds.outHeight) / (sample * 2) >= limit) sample *= 2
            val src = BitmapFactory.decodeFile(f.absolutePath, BitmapFactory.Options().apply { inSampleSize = sample })
                ?: return null
            val d = depthFile
            val depthBmp = if (c.mode != DepthMode.CLASSIC && d.exists()) BitmapFactory.decodeFile(d.absolutePath) else null
            if (depthBmp == null) return DepthScene(src, emptyList())
            // Live wallpaper must remain responsive on mid/low-memory phones. If depth slicing
            // fails, fall back to the original photo instead of leaving a black preview.
            return try {
                val field = DepthPipeline.fromGray(depthBmp)
                val safeLayers = c.layers.coerceIn(2, 4)
                val safeBlur = c.bgBlur.coerceIn(0f, 0.25f)
                val sc = SceneBuilder.build(src, field, safeLayers, c.fgCut, safeBlur, limit)
                src.recycle()
                sc
            } catch (_: Throwable) {
                DepthScene(src, emptyList())
            } finally {
                if (!depthBmp.isRecycled) depthBmp.recycle()
            }
        }

        private fun drawFrame() {
            if (!visible && !dirty) return
            val holder = surfaceHolder
            var canvas: Canvas? = null
            try {
                canvas = runCatching { holder.lockHardwareCanvas() }.getOrNull() ?: holder.lockCanvas() ?: return
                val sc = scene
                if (sc != null && !sc.base.isRecycled) {
                    renderer.draw(canvas, surfaceW, surfaceH, sc, cfg, tracker.x, tracker.y)
                    val now = SystemClock.uptimeMillis()
                    val dt = if (lastParticleFrame == 0L) 0.025f else ((now - lastParticleFrame).coerceIn(1L, 50L) / 1000f)
                    particleEffects.draw(canvas, surfaceW, surfaceH, cfg.particleEffect, cfg.particleIntensity, dt)
                } else {
                    canvas.drawColor(Color.BLACK)
                    textPaint.color = Color.WHITE
                    textPaint.textSize = 36f
                    textPaint.textAlign = Paint.Align.CENTER
                    canvas.drawText("Open Depth Wallpaper and pick a wallpaper", surfaceW / 2f, surfaceH / 2f, textPaint)
                }
                dirty = false
            } catch (_: Throwable) {
                // A single rendering failure must not crash the live wallpaper service.
                runCatching { canvas?.drawColor(Color.BLACK) }
                dirty = true
            } finally {
                val c = canvas
                if (c != null) runCatching { holder.unlockCanvasAndPost(c) }
            }
        }

        override fun onDestroy() {
            destroyed = true
            visible = false
            manager.unregisterListener(this)
            Choreographer.getInstance().removeFrameCallback(this)
            decoder.shutdown()
            scene?.recycle()
            scene = null
            super.onDestroy()
        }
    }
}
