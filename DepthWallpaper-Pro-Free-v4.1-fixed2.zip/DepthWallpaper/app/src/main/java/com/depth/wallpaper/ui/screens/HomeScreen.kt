package com.depth.wallpaper.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.ChevronRight
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import com.depth.wallpaper.data.Wallpaper
import com.depth.wallpaper.data.WallpaperRepository
import com.depth.wallpaper.ui.AppViewModel
import com.depth.wallpaper.ui.components.AppImage
import com.depth.wallpaper.ui.components.GlassIconButton
import com.depth.wallpaper.ui.components.GlassSurface
import com.depth.wallpaper.ui.components.SectionHeader
import com.depth.wallpaper.ui.components.WallpaperCard
import com.depth.wallpaper.ui.theme.BrandGradient
import com.depth.wallpaper.ui.theme.ElectricBlue
import com.depth.wallpaper.ui.theme.GoldPro
import com.depth.wallpaper.ui.theme.NeonPurple
import com.depth.wallpaper.ui.theme.TextPrimary
import com.depth.wallpaper.ui.theme.TextSecondary

@Composable
fun HomeScreen(vm: AppViewModel, nav: NavHostController) {
    val favs by vm.favorites.collectAsStateWithLifecycle()
    val online by vm.onlineWallpapers.collectAsStateWithLifecycle()
    val onlineError by vm.onlineError.collectAsStateWithLifecycle()
    val feed = online.take(10)
    val featuredFeed = online.drop(10).take(8)
    val recentFeed = online.drop(18).take(10)
    val popularFeed = online.drop(28).take(10)
    LazyColumn(
        Modifier.fillMaxSize().statusBarsPadding(),
        contentPadding = PaddingValues(bottom = 130.dp)
    ) {
        item { HomeHeader { nav.navigate("profile") } }
        item { SearchPill { nav.navigate("explore") } }
        item { CategoryCircles { nav.navigate("explore?cat=$it") } }
        if (online.isEmpty()) {
            item {
                Text(
                    onlineError ?: "Connecting to live wallpaper library…",
                    color = TextSecondary,
                    fontSize = 13.sp,
                    modifier = Modifier.fillMaxWidth().clickable { vm.loadOnlineWallpapers() }.padding(horizontal = 22.dp, vertical = 24.dp)
                )
            }
        } else {
            item { Section("Live from Openverse", feed, 130.dp, favs, vm, nav) }
            item { ProBanner { nav.navigate("studio?mode=depth") } }
            if (featuredFeed.isNotEmpty()) item { Section("Featured Wallpapers", featuredFeed, 190.dp, favs, vm, nav) }
            if (recentFeed.isNotEmpty()) item { Section("New Discoveries", recentFeed, 130.dp, favs, vm, nav) }
            if (popularFeed.isNotEmpty()) item { Section("More to Explore", popularFeed, 130.dp, favs, vm, nav) }
        }
    }
}

@Composable
private fun HomeHeader(onProfile: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(
                "Depth",
                style = TextStyle(brush = BrandGradient, fontSize = 36.sp, fontWeight = FontWeight.ExtraBold)
            )
            Text("Wallpaper", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
            Text("Bring Your Screen to Life", color = TextSecondary, fontSize = 13.sp)
        }
        GlassIconButton(Icons.Filled.Star, "Profile", tint = GoldPro, onClick = onProfile)
    }
}

@Composable
private fun SearchPill(onClick: () -> Unit) {
    GlassSurface(
        Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 6.dp).height(52.dp),
        RoundedCornerShape(26.dp),
        onClick = onClick
    ) {
        Row(Modifier.padding(horizontal = 16.dp).align(Alignment.CenterStart), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Outlined.Search, null, tint = TextSecondary)
            Spacer(Modifier.width(10.dp))
            Text("Search wallpapers…", color = TextSecondary, fontSize = 15.sp)
        }
    }
}

@Composable
private fun CategoryCircles(onClick: (String) -> Unit) {
    val names = listOf("Nature", "Anime", "Cars", "Space", "Minimal")
    val cats = WallpaperRepository.categories.filter { it.name in names }
    LazyRow(
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 14.dp),
        horizontalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        items(cats, key = { it.name }) { c ->
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.clickable { onClick(c.name) }
            ) {
                Box(
                    Modifier
                        .size(64.dp)
                        .clip(CircleShape)
                        .border(2.dp, BrandGradient, CircleShape)
                ) { AppImage(c.coverUrl, Modifier.fillMaxSize()) }
                Spacer(Modifier.height(6.dp))
                Text(c.name, color = TextPrimary, fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun Section(
    title: String,
    list: List<Wallpaper>,
    cardWidth: Dp,
    favs: Set<String>,
    vm: AppViewModel,
    nav: NavHostController
) {
    Column {
        SectionHeader(title, actionLabel = "See All", onAction = { nav.navigate("explore") })
        LazyRow(
            contentPadding = PaddingValues(horizontal = 20.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(list, key = { it.id }) { w ->
                WallpaperCard(
                    w = w,
                    favorite = w.id in favs,
                    onToggleFav = { vm.toggleFavorite(w.id) },
                    onClick = { nav.navigate("preview/${w.id}") },
                    modifier = Modifier.width(cardWidth),
                    badge = if (w.isOnline) "ONLINE" else "4K"
                )
            }
        }
    }
}

@Composable
private fun ProBanner(onClick: () -> Unit) {
    GlassSurface(
        Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 18.dp),
        RoundedCornerShape(22.dp),
        glow = NeonPurple.copy(alpha = 0.22f),
        onClick = onClick
    ) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.Star, null, tint = GoldPro, modifier = Modifier.size(36.dp))
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text("Pro unlocked - everything is free", color = TextPrimary, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                Text("Depth Studio, 3D live wallpapers, 4K, no ads", color = TextSecondary, fontSize = 12.sp)
            }
            Icon(Icons.Outlined.ChevronRight, null, tint = TextSecondary)
        }
    }
}
