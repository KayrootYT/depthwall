# DepthWallpaper v4 — Repair Audit

## Changes made in this repair pass

### Phase 1: Build and CI
- CI now provisions JDK 17 and Gradle 8.9.
- CI attempts debug build, Android lint, unit tests, and minified release build.
- CI uploads debug/release APKs and the lint report when present.
- Added unit tests for `smoothstep` and `boxBlur` math helpers.
- Documented the missing Gradle Wrapper and build prerequisites.

### Phase 2: Depth and image pipeline
- Reduced blur's intermediate bitmap allocations; the reduced bitmap is now recycled after upscaling.
- AI image generation now validates requested dimensions and prompt length, caps the response at 25 MB, checks decoded image dimensions, and uses sampled bitmap decoding.
- Depth estimation remains an on-device heuristic, not a neural depth model. This is documented honestly in README.

### Phase 3: Reliability and performance
- Wallpaper downloads now have a 50 MB cap, reject non-image content types when provided, check basic image signatures, and delete partial files on failure.
- Automatic wallpaper worker preserves coroutine cancellation and reports failure after retries are exhausted.

### Phase 4: Data safety and release hardening
- Backup import/export now limits file size and favorites count, checks backup version, and normalizes imported settings.
- Gallery saving now sanitizes filenames and deletes an inserted MediaStore row if the write/finalization fails.
- Release APK assembly was added to CI to exercise R8/resource shrinking.

## Verification performed here
- Parsed all 8 XML files successfully.
- Kotlin parser reported no syntax/parse errors in main source files; this is not equivalent to a Gradle build because Android/AndroidX dependencies are unavailable locally.
- Added one unit-test source file (3 tests); tests have not been executed here.

## Remaining verification / release blockers
- Android SDK and Gradle are not installed in this environment; external downloads are unavailable. Debug/release compilation, lint and unit tests must be verified by GitHub Actions or Android Studio.
- Test the app on a physical Android 16 device and at least one lower-memory device: wallpaper apply/preview, rotation, gyro fallback, background/foreground lifecycle, AI failures, offline generator, backup restore and Gallery export.
- Gallery export on Android 8/9 may require runtime storage permission; test and add a permission request flow if those OS versions are supported.
- Production publishing still needs real privacy policy/terms links and a release signing configuration.
- The public third-party AI endpoint can change, rate-limit or fail; the offline procedural generator remains the fallback.
