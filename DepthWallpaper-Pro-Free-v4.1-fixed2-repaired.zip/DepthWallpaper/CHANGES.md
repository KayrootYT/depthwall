# Changes

## Audit repair pass (v4.1 source update)

### Phase 1 — Build pipeline
- Updated GitHub Actions to build the debug APK, run Android lint and unit tests, and assemble a minified release APK.
- Added artifact upload for debug/release APKs and the lint report.
- Clarified that Gradle Wrapper files are not present in this archive and documented the CI/local prerequisites.
- Added unit tests for depth math helpers.

### Phase 2 — Depth / image pipeline
- Kept the depth estimator explicitly documented as a heuristic rather than claiming neural depth inference.
- Reduced blur processing's intermediate bitmap allocations to lower memory pressure.
- Added AI image response size/dimension checks and sampled decoding to reduce oversized bitmap allocation risk.

### Phase 3 — Reliability / performance
- Added a 50 MB limit, response type checks and basic image-signature validation to wallpaper downloads.
- Preserved coroutine cancellation in the automatic wallpaper worker rather than treating cancellation as a retry.
- Failed automatic wallpaper work now reports failure after retry exhaustion instead of silently reporting success.

### Phase 4 — Data / release hardening
- Added backup size/version/favorite-count checks and normalized imported settings.
- Added cleanup of incomplete Gallery MediaStore entries on save failures and safer output filenames.
- Added release build verification to CI.

### Verification status
- Static source inspection and Kotlin parser pass completed in the available environment.
- Android SDK and Gradle are not installed in the environment and external network access is unavailable, so Android compilation, lint, unit test execution, release shrinking and on-device runtime behavior remain **unverified** until GitHub Actions or Android Studio runs the build.
- A production release still needs a real privacy policy/terms URL and device testing (especially Android 8/9 Gallery permission behavior, Android 16 wallpaper service lifecycle, and vendor-specific battery management).


# 4.0
- New: Auto Wallpaper Changer (WorkManager) - Off / 15 / 30 / 60 min / Daily, source = Favorites or Downloads.
- New: Wallpaper History screen with one-tap re-apply; every apply is recorded (HistoryTracker).
- New: Save to Gallery via MediaStore (Pictures/DepthWallpaper), no storage permission needed on Android 10+.
- New: Backup & Restore of favorites + settings as JSON (Storage Access Framework).
- New: Dynamic Material You theme toggle (Android 12+), AMOLED background kept.
- Search in Explore now also matches wallpaper tags.
- Release build: R8 minification + resource shrinking enabled; proguard-rules.pro added.
- Gradle: androidx.work:work-runtime-ktx:2.10.0; versionCode 4, versionName 4.0.

# 2.0
- New: Depth Studio, layered depth live wallpaper, 3D tilt, depth clock, subject tap-select, touch/auto input.
- New: Generator (free AI prompt + 5 offline styles).
- Pro labels removed: all features unlocked.
- Live wallpaper service rewritten on top of the shared DepthRenderer.
- Removed the old heuristic-only DepthMapEngine (replaced by DepthPipeline).
