# Depth Wallpaper 4.0 (Android, Jetpack Compose)

Package: `com.depth.wallpaper`. Dark AMOLED + glass UI. **Every feature is unlocked and free** - there is no paywall, billing or ads in the code.

## Build (no Android Studio needed)
1. Put the contents of this folder at the repository root (keep `.github/workflows/build.yml`).
2. Push to GitHub, then open **Actions → Android CI**. You can also run it manually with **Run workflow**.
3. The workflow assembles the debug APK, runs Android lint and unit tests, and uploads available reports as the `DepthWallpaper-debug-build` artifact.
4. Download the artifact and install `app-debug.apk` on a test phone.

The CI workflow provisions Gradle 8.9 and JDK 17. This source archive does not include the Gradle Wrapper; local builds require Gradle 8.9 and the Android SDK for API 35. In Android Studio, open this folder and run `:app:assembleDebug`.

## Features
**New in 4.0**
- **Auto Wallpaper Changer** (Profile): Off / 15 min / 30 min / 1 hour / Daily. Picks from your Favorites or Downloads and sets the wallpaper even when the app is closed (WorkManager).
- **Wallpaper History** (Profile): every wallpaper you set is recorded; one-tap "Apply" to go back.
- **Save to Gallery**: downloads can be copied to `Pictures/DepthWallpaper` so they show up in your gallery app.
- **Backup & Restore** (Profile): export/import favorites and settings as a JSON file.
- **Dynamic theme (Material You)**: app colours follow your wallpaper on Android 12+ (toggle in Profile).
- **Tag search** in Explore.
**Depth Studio** (Create tab, Preview "Depth" button, Downloads layers icon)
- Pick any photo; an on-device depth map is built (colour saliency + focus + ground bias), all adjustable.
- **Tap subject**: colour-based selection that pushes the subject to the foreground (tap more to add, tolerance slider).
- Depth layers (2-7), foreground cut-off, background blur, auto-filled hidden areas (no ghosting).
- Effects: **Depth Parallax**, **3D Tilt** (perspective), **Classic** parallax.
- Controlled by **Gyro**, **Touch** or **Auto float**; intensity, smoothness, invert direction, battery saver (30 fps).
- **Depth Clock**: clock sits behind your subject (size, position, colour, 24h, date, bold).
- Output: **Live Wallpaper**, or a **still** (set / save / share) with the clock burned in.

**Generator** (Create -> Open Generator)
- Free **AI prompt** images (public Pollinations endpoint, no API key, needs internet).
- Offline procedural art: Mesh, Aurora, Waves, Peaks, Nebula.

**Existing**: Home, Explore, Favorites, Downloads, 4K wallpapers, Blur / Color filters / Anaglyph / Artistic editor.

## Honest limits
- Depth is a heuristic, not a neural network. Use "Tap subject" and the sliders for tricky photos.
- AI prompt uses a third-party service; it can be slow, rate-limited or change without notice.
- A local Android build cannot be verified in this environment because Android SDK/Gradle are not installed and network access to fetch them is unavailable. Use the GitHub Actions workflow to obtain the first real build result.
- If parallax feels inverted on your phone, switch on "Invert motion direction" in Motion.

## Live wallpaper catalogue

The Explore and Home feeds use the Openverse Images API (`https://api.openverse.org/v1/images/`) for openly licensed image discovery, filtered to `license_type=commercial`. Basic anonymous access is used initially; the API may rate-limit requests. The app shows creator and licence metadata on the preview screen. Users should follow the individual source and licence links before redistribution.

Selecting **Depth** on an online wallpaper downloads the image and passes it into the existing on-device `DepthPipeline` in Depth Studio. The current engine is a lightweight heuristic depth estimator, not a neural monocular-depth model; results vary by image and should be adjusted in Studio before applying.


## Online wallpaper sources (v4.1 update)

The Explore/Home feed queries three sources: Wallhaven (SFW-only search; rights vary per image), Wikimedia Commons (items without visible licence metadata are skipped), and NASA Images (check each item's credits/usage notes). The app merges available results and continues if an individual source fails. No API key is hardcoded. Online feed requires an internet connection. A source listing is not a guarantee that every item can be redistributed; check each item's source/rights before publishing or redistributing it.
