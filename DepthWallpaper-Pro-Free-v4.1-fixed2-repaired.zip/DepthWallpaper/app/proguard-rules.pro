# Depth Wallpaper release rules

# Data classes are serialized to JSON (backup/history) - keep their members
-keepclassmembers class com.depth.wallpaper.data.** { *; }

-dontwarn javax.annotation.**
-dontwarn org.codehaus.mojo.animal_sniffer.**
