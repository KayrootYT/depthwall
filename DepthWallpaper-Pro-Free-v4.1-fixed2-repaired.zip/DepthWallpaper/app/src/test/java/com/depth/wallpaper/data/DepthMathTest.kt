package com.depth.wallpaper.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class DepthMathTest {
    @Test fun smoothstepClampsAndInterpolates() {
        assertEquals(0f, smoothstep(0f, 1f, -1f), 0.0001f)
        assertEquals(0.5f, smoothstep(0f, 1f, 0.5f), 0.0001f)
        assertEquals(1f, smoothstep(0f, 1f, 2f), 0.0001f)
    }

    @Test fun blurPreservesArraySizeAndFiniteValues() {
        val source = floatArrayOf(0f, 1f, 0f, 1f, 0f, 1f)
        val result = boxBlur(source, 3, 2, 1)
        assertEquals(source.size, result.size)
        assertTrue(result.all { it.isFinite() && it in 0f..1f })
        assertTrue(result[0] > 0f)
    }

    @Test fun blurRadiusZeroReturnsCopy() {
        val source = floatArrayOf(0.2f, 0.8f)
        val result = boxBlur(source, 2, 1, 0)
        assertEquals(source.toList(), result.toList())
    }
}
