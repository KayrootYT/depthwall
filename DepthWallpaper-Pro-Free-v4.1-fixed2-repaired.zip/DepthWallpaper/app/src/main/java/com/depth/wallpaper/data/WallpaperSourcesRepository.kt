package com.depth.wallpaper.data

import android.net.Uri
import android.text.Html
import android.os.Build
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext

/**
 * Aggregates three wallpaper/image catalogues. Each provider is isolated so one unavailable
 * API does not prevent the other two from showing results.
 * Wallhaven is a discovery source; its images do not all have open licences.
 */
object WallpaperSourcesRepository {
    private val categoryQueries = mapOf(
        "Nature" to "nature landscape",
        "Mountains" to "mountain landscape",
        "Anime" to "anime",
        "Cars" to "sports car",
        "Space" to "galaxy nebula space",
        "Abstract" to "abstract digital art",
        "Minimal" to "minimal dark",
        "Animals" to "wildlife animal",
        "Architecture" to "architecture",
        "City" to "city night skyline"
    )

    suspend fun search(query: String, category: String?, page: Int = 1): List<Wallpaper> = coroutineScope {
        val q = query.trim().take(160).ifBlank {
            category?.takeIf { it != "All" }?.let { categoryQueries[it] } ?: "nature landscape"
        }
        val p = page.coerceAtLeast(1)
        val wallhaven = async(Dispatchers.IO) { runCatching { searchWallhaven(q, category, p) }.getOrDefault(emptyList()) }
        val commons = async(Dispatchers.IO) { runCatching { searchCommons(q, category, p) }.getOrDefault(emptyList()) }
        val nasa = async(Dispatchers.IO) { runCatching { searchNasa(q, category, p) }.getOrDefault(emptyList()) }
        val lists = listOf(wallhaven.await(), commons.await(), nasa.await())
        interleave(lists).distinctBy { it.id }
    }

    private fun searchWallhaven(query: String, category: String?, page: Int): List<Wallpaper> {
        val endpoint = "https://wallhaven.cc/api/v1/search?q=${Uri.encode(query)}&purity=100&categories=110&sorting=toplist&topRange=1M&page=$page"
        val root = JSONObject(get(endpoint, "application/json"))
        val results = root.optJSONArray("data") ?: return emptyList()
        return buildList {
            for (i in 0 until results.length()) {
                val item = results.optJSONObject(i) ?: continue
                val imageUrl = item.optString("path").takeIf { it.startsWith("https://") } ?: continue
                val thumbs = item.optJSONObject("thumbs")
                val thumbnail = thumbs?.optString("large")?.takeIf { it.startsWith("https://") }
                    ?: thumbs?.optString("original")?.takeIf { it.startsWith("https://") } ?: imageUrl
                val id = item.optString("id").takeIf { it.isNotBlank() && it != "null" } ?: "wh_${page}_$i"
                val tags = item.optJSONArray("tags")
                val title = if (tags != null && tags.length() > 0) tags.optJSONObject(0)?.optString("name") ?: "Wallpaper $id" else "Wallpaper $id"
                val pageUrl = item.optString("url").takeIf { it.startsWith("https://") } ?: "https://wallhaven.cc/w/$id"
                add(Wallpaper(
                    id = "wallhaven_$id", title = title.replace('_', ' ').replace('-', ' ').take(100),
                    category = category?.takeIf { it != "All" } ?: "Discover",
                    seed = "wallhaven-$id", imageUrl = imageUrl, thumbnailUrl = thumbnail,
                    creator = item.optJSONObject("uploader")?.optString("username")?.takeIf { it.isNotBlank() && it != "null" } ?: "Wallhaven uploader",
                    license = "Wallhaven — image rights vary; check original creator's terms",
                    licenseUrl = null, sourceUrl = pageUrl, sourceName = "Wallhaven"
                ))
            }
        }
    }

    private fun searchCommons(query: String, category: String?, page: Int): List<Wallpaper> {
        val offset = ((page - 1).coerceAtLeast(0) * 20)
        val searchTerm = "filetype:bitmap $query"
        val endpoint = "https://commons.wikimedia.org/w/api.php?action=query&generator=search&gsrsearch=${Uri.encode(searchTerm)}&gsrnamespace=6&gsrlimit=20&gsroffset=$offset&prop=imageinfo&iiprop=url%7Cextmetadata&iiurlwidth=720&format=json&origin=*"
        val root = JSONObject(get(endpoint, "application/json"))
        val pages = root.optJSONObject("query")?.optJSONObject("pages") ?: return emptyList()
        val iterator = pages.keys()
        return buildList {
            while (iterator.hasNext()) {
                val pageObj = pages.optJSONObject(iterator.next()) ?: continue
                val info = pageObj.optJSONArray("imageinfo")?.optJSONObject(0) ?: continue
                val meta = info.optJSONObject("extmetadata")
                val licenseShort = metadata(meta, "LicenseShortName")
                // Commons contains freely licensed/public-domain files, but skip entries whose licence is unclear.
                if (licenseShort.isBlank()) continue
                val imageUrl = info.optString("url").takeIf { it.startsWith("https://") } ?: continue
                val thumbnail = info.optString("thumburl").takeIf { it.startsWith("https://") } ?: imageUrl
                val title = pageObj.optString("title").removePrefix("File:").substringBeforeLast('.')
                val artist = metadata(meta, "Artist").ifBlank { metadata(meta, "Credit") }.ifBlank { "Creator not listed" }
                val licenseUrl = metadata(meta, "LicenseUrl").takeIf { it.startsWith("http") }
                val sourceUrl = info.optString("descriptionurl").takeIf { it.startsWith("https://") }
                    ?: "https://commons.wikimedia.org/wiki/${Uri.encode(pageObj.optString("title")).replace("%3A", ":").replace("%20", "_")}"
                val id = pageObj.optString("pageid").ifBlank { "${page}_$title" }
                add(Wallpaper(
                    id = "commons_$id", title = title.take(100),
                    category = category?.takeIf { it != "All" } ?: "Discover",
                    seed = "commons-$id", imageUrl = imageUrl, thumbnailUrl = thumbnail,
                    creator = artist.take(140), license = licenseShort,
                    licenseUrl = licenseUrl, sourceUrl = sourceUrl, sourceName = "Wikimedia Commons"
                ))
            }
        }
    }

    private fun searchNasa(query: String, category: String?, page: Int): List<Wallpaper> {
        val endpoint = "https://images-api.nasa.gov/search?q=${Uri.encode(query)}&media_type=image&page=$page&page_size=20"
        val root = JSONObject(get(endpoint, "application/json"))
        val items = root.optJSONObject("collection")?.optJSONArray("items") ?: return emptyList()
        return buildList {
            for (i in 0 until items.length()) {
                val item = items.optJSONObject(i) ?: continue
                val data = item.optJSONArray("data")?.optJSONObject(0) ?: continue
                val links = item.optJSONArray("links") ?: continue
                var thumbnail: String? = null
                for (j in 0 until links.length()) {
                    val link = links.optJSONObject(j) ?: continue
                    val href = link.optString("href")
                    if (href.startsWith("https://") && (link.optString("rel") == "preview" || thumbnail == null)) thumbnail = href
                    if (link.optString("rel") == "preview") break
                }
                val imageUrl = thumbnail?.takeIf { it.startsWith("https://") } ?: continue
                val nasaId = data.optString("nasa_id").takeIf { it.isNotBlank() && it != "null" } ?: "${page}_$i"
                val title = data.optString("title").takeIf { it.isNotBlank() && it != "null" } ?: "NASA Image $nasaId"
                val creator = data.optString("secondary_creator").takeIf { it.isNotBlank() && it != "null" }
                    ?: data.optString("center").takeIf { it.isNotBlank() && it != "null" } ?: "NASA"
                val details = "https://images.nasa.gov/details/${Uri.encode(nasaId)}"
                add(Wallpaper(
                    id = "nasa_${nasaId.replace(Regex("[^A-Za-z0-9_-]"), "_")}", title = title.take(120),
                    category = category?.takeIf { it != "All" } ?: "Space",
                    seed = "nasa-$nasaId", imageUrl = imageUrl, thumbnailUrl = imageUrl,
                    creator = creator.take(140), license = "NASA media — check item credits and usage notes",
                    licenseUrl = null, sourceUrl = details, sourceName = "NASA Images"
                ))
            }
        }
    }

    private fun metadata(meta: JSONObject?, key: String): String {
        val raw = meta?.optJSONObject(key)?.optString("value").orEmpty()
        if (raw.isBlank() || raw == "null") return ""
        val plain = if (Build.VERSION.SDK_INT >= 24) Html.fromHtml(raw, Html.FROM_HTML_MODE_LEGACY).toString() else Html.fromHtml(raw).toString()
        return plain.replace(Regex("\\s+"), " ").trim()
    }

    private fun get(url: String, accept: String): String {
        val connection = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 9_000
            readTimeout = 12_000
            setRequestProperty("Accept", accept)
            setRequestProperty("User-Agent", "DepthWallpaper-Android/4.1 (Android wallpaper discovery app)")
        }
        try {
            val code = connection.responseCode
            if (code !in 200..299) throw java.io.IOException("HTTP $code")
            return connection.inputStream.bufferedReader().use { it.readText() }
        } finally {
            connection.disconnect()
        }
    }

    private fun interleave(sources: List<List<Wallpaper>>): List<Wallpaper> {
        val result = ArrayList<Wallpaper>()
        val max = sources.maxOfOrNull { it.size } ?: 0
        for (i in 0 until max) for (source in sources) if (i < source.size) result += source[i]
        return result
    }
}
