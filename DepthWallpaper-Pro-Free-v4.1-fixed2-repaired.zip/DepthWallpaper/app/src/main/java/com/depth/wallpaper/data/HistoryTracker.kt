package com.depth.wallpaper.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONObject

private val Context.historyStore by preferencesDataStore(name = "depth_history")

data class HistoryEntry(
    val id: String,
    val title: String,
    val source: String, // APPLIED (user), AUTO (auto changer)
    val time: Long
)

/** Last wallpapers that were set, persisted locally. */
object HistoryTracker {
    private val key = stringPreferencesKey("entries")
    private const val MAX = 50

    fun entries(ctx: Context): Flow<List<HistoryEntry>> =
        ctx.historyStore.data.map { p -> parse(p[key] ?: "[]") }

    suspend fun record(ctx: Context, e: HistoryEntry) {
        ctx.historyStore.edit { p ->
            val cur = parse(p[key] ?: "[]").toMutableList()
            cur.removeAll { it.id == e.id && it.source == e.source }
            cur.add(0, e)
            while (cur.size > MAX) cur.removeAt(cur.size - 1)
            p[key] = write(cur)
        }
    }

    suspend fun clear(ctx: Context) {
        ctx.historyStore.edit { it[key] = "[]" }
    }

    private fun parse(json: String): List<HistoryEntry> = runCatching {
        val arr = JSONArray(json)
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            HistoryEntry(
                id = o.getString("id"),
                title = o.getString("title"),
                source = o.getString("source"),
                time = o.getLong("time")
            )
        }
    }.getOrDefault(emptyList())

    private fun write(list: List<HistoryEntry>): String {
        val arr = JSONArray()
        list.forEach { e ->
            arr.put(
                JSONObject()
                    .put("id", e.id)
                    .put("title", e.title)
                    .put("source", e.source)
                    .put("time", e.time)
            )
        }
        return arr.toString()
    }
}
