package com.depth.wallpaper.data

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

data class BackupData(
    val favorites: Set<String>,
    val quality: String,
    val dynamicTheme: Boolean,
    val autoMinutes: Int,
    val autoTarget: String
)

/** Export/import a small, versioned JSON backup selected through Android's Storage Access Framework. */
object BackupManager {
    private const val VERSION = 1
    private const val MAX_BACKUP_BYTES = 2 * 1024 * 1024
    private const val MAX_FAVORITES = 10_000

    suspend fun export(ctx: Context, uri: Uri, data: BackupData): Result<Unit> =
        withContext(Dispatchers.IO) {
            runCatching {
                require(data.favorites.size <= MAX_FAVORITES) { "Too many favorites to back up" }
                val favs = JSONArray()
                data.favorites.filter { it.isNotBlank() && it.length <= 256 }.forEach { favs.put(it) }
                val json = JSONObject()
                    .put("version", VERSION)
                    .put("favorites", favs)
                    .put("quality", data.quality)
                    .put("dynamic_theme", data.dynamicTheme)
                    .put("auto_minutes", data.autoMinutes.coerceIn(0, 1440))
                    .put("auto_target", data.autoTarget.takeIf { it == "favorites" || it == "downloads" } ?: "favorites")
                    .toString()
                    .toByteArray(Charsets.UTF_8)
                require(json.size <= MAX_BACKUP_BYTES) { "Backup is too large" }
                ctx.contentResolver.openOutputStream(uri, "wt")?.use { it.write(json) }
                    ?: error("Could not write to the selected file")
                Unit
            }
        }

    suspend fun import(ctx: Context, uri: Uri): Result<BackupData> =
        withContext(Dispatchers.IO) {
            runCatching {
                val bytes = ctx.contentResolver.openInputStream(uri)?.use { input ->
                    val out = java.io.ByteArrayOutputStream()
                    val buffer = ByteArray(8 * 1024)
                    var total = 0
                    while (true) {
                        val n = input.read(buffer)
                        if (n < 0) break
                        total += n
                        require(total <= MAX_BACKUP_BYTES) { "Backup file is too large" }
                        out.write(buffer, 0, n)
                    }
                    out.toByteArray()
                } ?: error("Could not read the selected file")
                val o = JSONObject(bytes.toString(Charsets.UTF_8))
                require(o.has("favorites")) { "Not a Depth Wallpaper backup file" }
                val version = o.optInt("version", 0)
                require(version in 0..VERSION) { "This backup was created by a newer app version" }
                val arr = o.getJSONArray("favorites")
                require(arr.length() <= MAX_FAVORITES) { "Backup contains too many favorites" }
                val favs = HashSet<String>()
                for (i in 0 until arr.length()) {
                    val value = arr.optString(i, "")
                    if (value.isNotBlank() && value.length <= 256) favs.add(value)
                }
                val quality = o.optString("quality", "QHD").takeIf { it in setOf("HD", "QHD", "UHD") } ?: "QHD"
                val autoTarget = o.optString("auto_target", "favorites")
                    .takeIf { it == "favorites" || it == "downloads" } ?: "favorites"
                BackupData(
                    favorites = favs,
                    quality = quality,
                    dynamicTheme = o.optBoolean("dynamic_theme", false),
                    autoMinutes = o.optInt("auto_minutes", 0).coerceIn(0, 1440),
                    autoTarget = autoTarget
                )
            }
        }
}
