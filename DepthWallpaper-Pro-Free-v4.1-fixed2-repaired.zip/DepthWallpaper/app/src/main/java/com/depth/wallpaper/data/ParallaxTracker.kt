package com.depth.wallpaper.data

import android.hardware.SensorManager
import kotlin.math.abs

/**
 * Converts rotation-vector sensor events into a smooth, calibrated parallax offset in -1..1.
 *
 * Why this exists: the old code used getOrientation() pitch/roll directly. When a phone is held
 * upright, pitch is ~ -90deg, so the offset sat at its maximum all the time and the axes were swapped.
 *
 * Here we read the world "up" vector expressed in device coordinates (3rd row of the rotation
 * matrix). Its x component changes when the phone tilts left/right, its z component when it tilts
 * forward/back. The first reading becomes the neutral pose, and the neutral pose slowly follows the
 * phone, so the image re-centres by itself if you lean back on a sofa.
 */
class ParallaxTracker(
    /** Tilt (in sine of the angle, ~ 0.3 = 17deg) that produces the full offset. */
    private val fullTilt: Float = 0.30f,
    /** How quickly the neutral pose follows the phone (0 = never, 0.02 = roughly 1s at 50Hz). */
    private val recenterRate: Float = 0.004f
) {
    private val matrix = FloatArray(9)
    private var refX = 0f
    private var refZ = 0f
    private var hasRef = false

    /** Target offsets, -1..1 (before smoothing). */
    var targetX = 0f
        private set
    var targetY = 0f
        private set

    /** Smoothed offsets, -1..1. Call [step] once per frame. */
    var x = 0f
        private set
    var y = 0f
        private set

    /** Sets the target directly (touch / auto-float input), values -1..1. */
    fun setTarget(tx: Float, ty: Float) {
        targetX = tx.coerceIn(-1f, 1f)
        targetY = ty.coerceIn(-1f, 1f)
    }

    fun reset() {
        hasRef = false
        targetX = 0f; targetY = 0f
    }

    fun onSensor(values: FloatArray) {
        if (values.size < 3) return
        SensorManager.getRotationMatrixFromVector(matrix, values)
        val upX = matrix[6]
        val upZ = matrix[8]
        if (!hasRef) {
            refX = upX; refZ = upZ; hasRef = true
        }
        val dx = upX - refX
        val dz = upZ - refZ
        // Let the neutral pose drift toward the current pose (high-pass filter).
        refX += dx * recenterRate
        refZ += dz * recenterRate
        targetX = (dx / fullTilt).coerceIn(-1f, 1f)
        targetY = (-dz / fullTilt).coerceIn(-1f, 1f)
    }

    /** Eases the smoothed values toward the target. Returns true if anything visibly moved. */
    fun step(factor: Float = 0.14f): Boolean {
        val nx = x + (targetX - x) * factor
        val ny = y + (targetY - y) * factor
        val moved = abs(nx - x) > 0.0005f || abs(ny - y) > 0.0005f
        x = nx; y = ny
        return moved
    }
}
