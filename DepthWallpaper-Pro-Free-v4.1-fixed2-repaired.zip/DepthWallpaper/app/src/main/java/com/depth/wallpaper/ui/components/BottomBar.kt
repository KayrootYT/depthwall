package com.depth.wallpaper.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Download
import androidx.compose.material.icons.outlined.Explore
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.depth.wallpaper.ui.theme.BrandGradient
import com.depth.wallpaper.ui.theme.ElectricBlue
import com.depth.wallpaper.ui.theme.NeonCyan
import com.depth.wallpaper.ui.theme.TextSecondary

private data class Tab(val route: String, val label: String, val icon: ImageVector)

/** Floating translucent bottom bar with a glowing centre "Create" button. */
@Composable
fun GlassBottomBar(selected: String, onSelect: (String) -> Unit, modifier: Modifier = Modifier) {
    val left = listOf(
        Tab("home", "Home", Icons.Outlined.Home),
        Tab("explore", "Explore", Icons.Outlined.Explore)
    )
    val right = listOf(
        Tab("favorites", "Favorites", Icons.Outlined.FavoriteBorder),
        Tab("downloads", "Downloads", Icons.Outlined.Download)
    )
    Box(
        modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .padding(horizontal = 16.dp)
            .padding(bottom = 12.dp)
            .height(92.dp)
    ) {
        GlassSurface(
            Modifier.fillMaxWidth().height(68.dp).align(Alignment.BottomCenter),
            RoundedCornerShape(34.dp)
        ) {
            Box(Modifier.fillMaxSize().background(Color(0xCC060B1E))) {
                Row(Modifier.fillMaxSize(), verticalAlignment = Alignment.CenterVertically) {
                    left.forEach { t -> TabItem(t, selected == t.route, Modifier.weight(1f)) { onSelect(t.route) } }
                    Spacer(Modifier.width(72.dp))
                    right.forEach { t -> TabItem(t, selected == t.route, Modifier.weight(1f)) { onSelect(t.route) } }
                }
                Text(
                    "Create",
                    color = if (selected == "create") NeonCyan else TextSecondary,
                    fontSize = 10.sp,
                    modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 8.dp)
                )
            }
        }
        val selectedScale by animateFloatAsState(if (selected == "create") 1.12f else 1f, label = "createScale")
        // No perpetual pulse: saves GPU work while keeping a short selected-state animation.
        val scale = selectedScale
        Box(
            Modifier
                .align(Alignment.TopCenter)
                .size(60.dp)
                .scale(scale)
                .shadow(10.dp, CircleShape, ambientColor = ElectricBlue.copy(alpha = 0.5f), spotColor = ElectricBlue.copy(alpha = 0.5f))
                .clip(CircleShape)
                .background(Brush.linearGradient(listOf(Color(0xFF5B8CFF), ElectricBlue)))
                .border(2.dp, Color.White.copy(alpha = 0.35f), CircleShape)
                .clickable { onSelect("create") },
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Outlined.Add, "Create", tint = Color.White, modifier = Modifier.size(30.dp))
        }
    }
}

@Composable
private fun TabItem(tab: Tab, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val color by animateColorAsState(if (selected) NeonCyan else TextSecondary, label = "tabColor")
    val indicator by animateDpAsState(if (selected) 18.dp else 0.dp, label = "tabIndicator")
    Column(
        modifier
            .fillMaxHeight()
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(tab.icon, tab.label, tint = color, modifier = Modifier.size(24.dp))
        Text(tab.label, color = color, fontSize = 10.sp)
        Spacer(Modifier.height(3.dp))
        Box(Modifier.height(3.dp).width(indicator).clip(CircleShape).background(BrandGradient))
    }
}
