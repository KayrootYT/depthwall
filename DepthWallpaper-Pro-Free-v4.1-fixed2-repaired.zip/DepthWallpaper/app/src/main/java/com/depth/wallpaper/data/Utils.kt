package com.depth.wallpaper.data

import android.app.WallpaperManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.max

object WallpaperTarget {
    val HOME = WallpaperManager.FLAG_SYSTEM
    val LOCK = WallpaperManager.FLAG_LOCK
    val BOTH = WallpaperManager.FLAG_SYSTEM or WallpaperManager.FLAG_LOCK
}

suspend fun applyWallpaper(ctx: Context, file: File, which: Int): Result<Unit> =
    withContext(Dispatchers.IO) {
        runCatching {
            val wm = WallpaperManager.getInstance(ctx)
            if (!wm.isWallpaperSupported) error("Wallpapers are not supported on this device")
            if (!wm.isSetWallpaperAllowed) error("Setting wallpaper is blocked on this device")
            file.inputStream().use { wm.setStream(it, null, true, which) }
            runCatching {
                HistoryTracker.record(
                    ctx,
                    HistoryEntry(
                        id = file.name,
                        title = file.nameWithoutExtension,
                        source = "APPLIED",
                        time = System.currentTimeMillis()
                    )
                )
            }
            Unit
        }
    }

private fun uriFor(ctx: Context, file: File): Uri =
    FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", file)

fun shareFile(ctx: Context, file: File) {
    val i = Intent(Intent.ACTION_SEND).apply {
        type = "image/jpeg"
        putExtra(Intent.EXTRA_STREAM, uriFor(ctx, file))
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    ctx.startActivity(Intent.createChooser(i, "Share wallpaper"))
}

fun viewFile(ctx: Context, file: File) {
    val i = Intent(Intent.ACTION_VIEW).apply {
        setDataAndType(uriFor(ctx, file), "image/jpeg")
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    runCatching { ctx.startActivity(i) }
}

fun openUrl(ctx: Context, url: String): Boolean =
    runCatching { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }.isSuccess

fun sendFeedback(ctx: Context, email: String): Boolean =
    runCatching {
        ctx.startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:$email")).apply {
            putExtra(Intent.EXTRA_SUBJECT, "Depth Wallpaper feedback")
        })
    }.isSuccess

/** Decodes a picked image down to maxSide and fixes EXIF rotation. */
fun decodeScaled(ctx: Context, uri: Uri, maxSide: Int): Bitmap? {
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
    var sample = 1
    while (max(bounds.outWidth, bounds.outHeight) / sample > maxSide) sample *= 2
    val opts = BitmapFactory.Options().apply { inSampleSize = sample }
    var bmp = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
        ?: return null
    val orientation = runCatching {
        ctx.contentResolver.openInputStream(uri)?.use {
            ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
        }
    }.getOrNull() ?: ExifInterface.ORIENTATION_NORMAL
    val deg = when (orientation) {
        ExifInterface.ORIENTATION_ROTATE_90 -> 90f
        ExifInterface.ORIENTATION_ROTATE_180 -> 180f
        ExifInterface.ORIENTATION_ROTATE_270 -> 270f
        else -> 0f
    }
    if (deg != 0f) {
        bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, Matrix().apply { postRotate(deg) }, true)
    }
    return bmp
}
