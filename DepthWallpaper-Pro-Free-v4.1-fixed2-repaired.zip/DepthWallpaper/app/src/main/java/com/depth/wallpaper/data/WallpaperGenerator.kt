package com.depth.wallpaper.data

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Shader
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.PI
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

enum class GenStyle(val label: String) {
    AI("AI Prompt"),
    MESH("Mesh"),
    AURORA("Aurora"),
    WAVES("Waves"),
    PEAKS("Peaks"),
    NEBULA("Nebula")
}

/**
 * Free wallpaper generator.
 *  - AI: free text-to-image through the public Pollinations endpoint (no API key, needs internet).
 *    It is a third-party service, so speed / availability / content are outside this app's control.
 *  - Everything else: procedural art drawn on-device, works offline, every seed is unique.
 */
object WallpaperGenerator {

    suspend fun ai(prompt: String, w: Int, h: Int, seed: Long): Result<Bitmap> = withContext(Dispatchers.IO) {
        runCatching {
            require(w in 512..2048 && h in 512..2048) { "Image dimensions must be between 512 and 2048 pixels" }
            val cleanPrompt = prompt.trim().take(500).ifBlank { "beautiful abstract wallpaper" }
            val text = "$cleanPrompt, phone wallpaper, highly detailed, no text"
            val url = URL("https://image.pollinations.ai/prompt/${Uri.encode(text)}?width=$w&height=$h&seed=$seed&nologo=true")
            val conn = url.openConnection() as HttpURLConnection
            conn.connectTimeout = 20_000
            conn.readTimeout = 120_000
            conn.instanceFollowRedirects = true
            conn.setRequestProperty("User-Agent", "DepthWallpaper/4.0")
            try {
                val code = conn.responseCode
                if (code !in 200..299) throw IOException("AI service returned HTTP $code")
                val bytes = ByteArrayOutputStream()
                conn.inputStream.use { input ->
                    val buffer = ByteArray(16 * 1024)
                    var total = 0
                    while (true) {
                        val n = input.read(buffer)
                        if (n < 0) break
                        total += n
                        if (total > 25 * 1024 * 1024) throw IOException("Generated image is too large (limit 25 MB)")
                        bytes.write(buffer, 0, n)
                    }
                }
                val data = bytes.toByteArray()
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeByteArray(data, 0, data.size, bounds)
                if (bounds.outWidth <= 0 || bounds.outHeight <= 0) throw IOException("AI service did not return a valid image")
                var sample = 1
                while (max(bounds.outWidth, bounds.outHeight) / (sample * 2) >= 2048) sample *= 2
                val opts = BitmapFactory.Options().apply {
                    inSampleSize = sample
                    inPreferredConfig = Bitmap.Config.ARGB_8888
                }
                BitmapFactory.decodeByteArray(data, 0, data.size, opts) ?: throw IOException("Could not decode generated image")
            } finally {
                conn.disconnect()
            }
        }
    }

    fun procedural(style: GenStyle, seed: Long, w: Int, h: Int): Bitmap {
        val rnd = Random(seed)
        return when (style) {
            GenStyle.AURORA -> aurora(rnd, w, h)
            GenStyle.WAVES -> waves(rnd, w, h)
            GenStyle.PEAKS -> peaks(rnd, w, h)
            GenStyle.NEBULA -> nebula(rnd, w, h)
            else -> mesh(rnd, w, h)
        }
    }

    private fun palette(rnd: Random): IntArray {
        val base = rnd.nextFloat() * 360f
        val spread = 25f + rnd.nextFloat() * 70f
        return IntArray(4) { i ->
            Color.HSVToColor(floatArrayOf((base + i * spread) % 360f, 0.55f + rnd.nextFloat() * 0.4f, 0.65f + rnd.nextFloat() * 0.35f))
        }
    }

    private fun dark(c: Int, f: Float): Int =
        Color.rgb((Color.red(c) * f).toInt(), (Color.green(c) * f).toInt(), (Color.blue(c) * f).toInt())

    private fun mix(a: Int, b: Int, t: Float): Int = Color.rgb(
        (Color.red(a) + (Color.red(b) - Color.red(a)) * t).toInt().coerceIn(0, 255),
        (Color.green(a) + (Color.green(b) - Color.green(a)) * t).toInt().coerceIn(0, 255),
        (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t).toInt().coerceIn(0, 255)
    )

    private fun newCanvas(w: Int, h: Int): Pair<Bitmap, Canvas> {
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        return bmp to Canvas(bmp)
    }

    private fun blobs(c: Canvas, rnd: Random, pal: IntArray, w: Int, h: Int, count: Int, minR: Float, maxR: Float, alpha: Int) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        repeat(count) {
            val cx = rnd.nextFloat() * w
            val cy = rnd.nextFloat() * h
            val r = (minR + rnd.nextFloat() * (maxR - minR)) * max(w, h)
            val col = pal[rnd.nextInt(pal.size)]
            val center = Color.argb(alpha, Color.red(col), Color.green(col), Color.blue(col))
            val edge = Color.argb(0, Color.red(col), Color.green(col), Color.blue(col))
            p.shader = RadialGradient(cx, cy, r, center, edge, Shader.TileMode.CLAMP)
            c.drawCircle(cx, cy, r, p)
        }
    }

    private fun mesh(rnd: Random, w: Int, h: Int): Bitmap {
        val (bmp, c) = newCanvas(w, h)
        val pal = palette(rnd)
        c.drawColor(dark(pal[0], 0.28f))
        blobs(c, rnd, pal, w, h, 7, 0.28f, 0.6f, 235)
        return bmp
    }

    private fun nebula(rnd: Random, w: Int, h: Int): Bitmap {
        val (bmp, c) = newCanvas(w, h)
        val pal = palette(rnd)
        c.drawColor(Color.rgb(3, 4, 12))
        blobs(c, rnd, pal, w, h, 6, 0.2f, 0.5f, 120)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        repeat(420) {
            val a = 60 + rnd.nextInt(195)
            p.color = Color.argb(a, 255, 255, 255)
            val r = 0.8f + rnd.nextFloat() * rnd.nextFloat() * 3.2f
            c.drawCircle(rnd.nextFloat() * w, rnd.nextFloat() * h, r, p)
        }
        repeat(10) {
            val x = rnd.nextFloat() * w
            val y = rnd.nextFloat() * h
            p.shader = RadialGradient(x, y, 26f, Color.argb(200, 255, 255, 255), Color.argb(0, 255, 255, 255), Shader.TileMode.CLAMP)
            c.drawCircle(x, y, 26f, p)
            p.shader = null
        }
        return bmp
    }

    private fun aurora(rnd: Random, w: Int, h: Int): Bitmap {
        val (bmp, c) = newCanvas(w, h)
        val pal = palette(rnd)
        val sky = Paint().apply {
            shader = LinearGradient(0f, 0f, 0f, h.toFloat(), Color.rgb(2, 6, 20), dark(pal[0], 0.22f), Shader.TileMode.CLAMP)
        }
        c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), sky)
        val (layer, lc) = newCanvas(w, h)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        repeat(4) { i ->
            val baseY = h * (0.25f + 0.12f * i + rnd.nextFloat() * 0.06f)
            val amp = h * (0.03f + rnd.nextFloat() * 0.05f)
            val freq = (1.2f + rnd.nextFloat() * 2f) * (2f * PI.toFloat() / w)
            val phase = rnd.nextFloat() * 6.28f
            val tall = h * (0.12f + rnd.nextFloat() * 0.18f)
            // Build one closed ribbon: upper edge left->right, lower edge right->left.
            val ribbon = Path()
            ribbon.moveTo(0f, baseY + sin(phase) * amp)
            var x = 0f
            while (x <= w) {
                ribbon.lineTo(x, baseY + sin(x * freq + phase) * amp)
                x += 12f
            }
            x = w.toFloat()
            while (x >= 0f) {
                ribbon.lineTo(x, baseY + sin(x * freq + phase) * amp + tall * (0.7f + 0.3f * sin(x * freq * 2.3f + phase)))
                x -= 12f
            }
            ribbon.close()
            val col = pal[i % pal.size]
            p.shader = LinearGradient(
                0f, baseY - amp, 0f, baseY + tall + amp,
                Color.argb(190, Color.red(col), Color.green(col), Color.blue(col)),
                Color.argb(0, Color.red(col), Color.green(col), Color.blue(col)),
                Shader.TileMode.CLAMP
            )
            lc.drawPath(ribbon, p)
        }
        val soft = ImageEffects.blur(layer, 0.28f)
        c.drawBitmap(soft, 0f, 0f, null)
        if (soft !== layer) soft.recycle()
        layer.recycle()
        val sp = Paint(Paint.ANTI_ALIAS_FLAG)
        repeat(260) {
            sp.color = Color.argb(70 + rnd.nextInt(185), 255, 255, 255)
            c.drawCircle(rnd.nextFloat() * w, rnd.nextFloat() * h * 0.7f, 0.7f + rnd.nextFloat() * 1.8f, sp)
        }
        return bmp
    }

    private fun waves(rnd: Random, w: Int, h: Int): Bitmap {
        val (bmp, c) = newCanvas(w, h)
        val pal = palette(rnd)
        val bg = Paint().apply {
            shader = LinearGradient(0f, 0f, 0f, h.toFloat(), pal[0], dark(pal[1], 0.5f), Shader.TileMode.CLAMP)
        }
        c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), bg)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        val layers = 7
        for (i in 0 until layers) {
            val t = i / (layers - 1f)
            val baseY = h * (0.3f + 0.65f * t)
            val a1 = h * (0.02f + rnd.nextFloat() * 0.03f)
            val a2 = h * (0.01f + rnd.nextFloat() * 0.02f)
            val f1 = (1f + rnd.nextFloat() * 1.6f) * (2f * PI.toFloat() / w)
            val f2 = (3f + rnd.nextFloat() * 3f) * (2f * PI.toFloat() / w)
            val ph1 = rnd.nextFloat() * 6.28f
            val ph2 = rnd.nextFloat() * 6.28f
            val path = Path()
            path.moveTo(0f, h.toFloat())
            var x = 0f
            while (x <= w) {
                path.lineTo(x, baseY + sin(x * f1 + ph1) * a1 + sin(x * f2 + ph2) * a2)
                x += 10f
            }
            path.lineTo(w.toFloat(), h.toFloat())
            path.close()
            p.color = mix(pal[2], dark(pal[3], 0.35f), t)
            p.alpha = 235
            c.drawPath(path, p)
        }
        return bmp
    }

    private fun peaks(rnd: Random, w: Int, h: Int): Bitmap {
        val (bmp, c) = newCanvas(w, h)
        val pal = palette(rnd)
        val sky = Paint().apply {
            shader = LinearGradient(0f, 0f, 0f, h * 0.75f, dark(pal[0], 0.55f), mix(pal[1], Color.WHITE, 0.35f), Shader.TileMode.CLAMP)
        }
        c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), sky)
        val sunX = w * (0.25f + rnd.nextFloat() * 0.5f)
        val sunY = h * (0.28f + rnd.nextFloat() * 0.12f)
        val sp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = RadialGradient(sunX, sunY, w * 0.5f, Color.argb(210, 255, 240, 210), Color.argb(0, 255, 240, 210), Shader.TileMode.CLAMP)
        }
        c.drawCircle(sunX, sunY, w * 0.5f, sp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        val ridges = 6
        val haze = mix(pal[1], Color.WHITE, 0.5f)
        for (i in 0 until ridges) {
            val t = i / (ridges - 1f)
            val baseY = h * (0.42f + 0.5f * t)
            val amp = h * (0.07f + 0.05f * (1f - t))
            val fa = 1.2f + rnd.nextFloat() * 1.5f
            val fb = 3f + rnd.nextFloat() * 4f
            val fc = 8f + rnd.nextFloat() * 8f
            val pa = rnd.nextFloat() * 6.28f
            val pb = rnd.nextFloat() * 6.28f
            val pc = rnd.nextFloat() * 6.28f
            val k = 2f * PI.toFloat() / w
            val path = Path()
            path.moveTo(0f, h.toFloat())
            var x = 0f
            while (x <= w) {
                val v = sin(x * k * fa + pa) * 0.6f + sin(x * k * fb + pb) * 0.3f + sin(x * k * fc + pc) * 0.12f
                path.lineTo(x, baseY - amp * (0.5f + v))
                x += 6f
            }
            path.lineTo(w.toFloat(), h.toFloat())
            path.close()
            p.color = mix(haze, dark(pal[2], 0.18f), min(1f, t * 1.15f))
            c.drawPath(path, p)
        }
        return bmp
    }
}
