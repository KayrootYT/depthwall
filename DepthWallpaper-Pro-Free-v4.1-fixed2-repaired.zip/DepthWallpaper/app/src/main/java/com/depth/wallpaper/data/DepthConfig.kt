package com.depth.wallpaper.data

import android.content.Context

enum class DepthMode(val label: String) {
    DEPTH("Depth Parallax"),
    TILT3D("3D Tilt"),
    CLASSIC("Classic")
}

enum class InputMode(val label: String) {
    GYRO("Gyro"),
    TOUCH("Touch"),
    AUTO("Auto float")
}

/** Everything the live wallpaper and the Depth Studio preview share. */
data class DepthConfig(
    val mode: DepthMode = DepthMode.DEPTH,
    val input: InputMode = InputMode.GYRO,
    val intensity: Float = 0.6f,
    val response: Float = 0.14f,
    val layers: Int = 5,
    val fgCut: Float = 0.7f,
    val bgBlur: Float = 0f,
    val invertMotion: Boolean = false,
    val batterySaver: Boolean = false,
    /** Optional lightweight animated overlay for the live wallpaper. */
    val particleEffect: String = "OFF",
    val particleIntensity: Float = 0.65f,
    val clockOn: Boolean = false,
    val clock24: Boolean = false,
    val showDate: Boolean = true,
    val clockSize: Float = 0.13f,
    val clockY: Float = 0.24f,
    val clockColor: Int = 0,
    val clockBold: Boolean = false
) {
    companion object {
        val CLOCK_COLORS = intArrayOf(
            0xFFFFFFFF.toInt(), 0xFF000000.toInt(), 0xFF35E0FF.toInt(), 0xFFFFC53D.toInt(), 0xFFFF4D6D.toInt()
        )
        val CLOCK_COLOR_NAMES = listOf("White", "Black", "Cyan", "Gold", "Pink")
    }
}

object DepthConfigStore {
    private const val FILE = "depth_cfg"

    fun load(ctx: Context): DepthConfig {
        val p = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        val d = DepthConfig()
        return DepthConfig(
            mode = runCatching { DepthMode.valueOf(p.getString("mode", d.mode.name) ?: d.mode.name) }.getOrDefault(d.mode),
            input = runCatching { InputMode.valueOf(p.getString("input", d.input.name) ?: d.input.name) }.getOrDefault(d.input),
            intensity = p.getFloat("intensity", d.intensity).coerceIn(0f, 1.5f),
            response = p.getFloat("response", d.response).coerceIn(0.03f, 0.5f),
            layers = p.getInt("layers", d.layers).coerceIn(2, 7),
            fgCut = p.getFloat("fgCut", d.fgCut).coerceIn(0.3f, 0.95f),
            bgBlur = p.getFloat("bgBlur", d.bgBlur).coerceIn(0f, 1f),
            invertMotion = p.getBoolean("invertMotion", d.invertMotion),
            batterySaver = p.getBoolean("batterySaver", d.batterySaver),
            particleEffect = (p.getString("particleEffect", d.particleEffect) ?: d.particleEffect).let { if (it in setOf("OFF", "RAIN", "SNOW", "PETALS")) it else "OFF" },
            particleIntensity = p.getFloat("particleIntensity", d.particleIntensity).coerceIn(0.25f, 1f),
            clockOn = p.getBoolean("clockOn", d.clockOn),
            clock24 = p.getBoolean("clock24", d.clock24),
            showDate = p.getBoolean("showDate", d.showDate),
            clockSize = p.getFloat("clockSize", d.clockSize).coerceIn(0.06f, 0.2f),
            clockY = p.getFloat("clockY", d.clockY).coerceIn(0.05f, 0.9f),
            clockColor = p.getInt("clockColor", d.clockColor).coerceIn(0, DepthConfig.CLOCK_COLORS.size - 1),
            clockBold = p.getBoolean("clockBold", d.clockBold)
        )
    }

    fun save(ctx: Context, c: DepthConfig) {
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit()
            .putString("mode", c.mode.name)
            .putString("input", c.input.name)
            .putFloat("intensity", c.intensity)
            .putFloat("response", c.response)
            .putInt("layers", c.layers)
            .putFloat("fgCut", c.fgCut)
            .putFloat("bgBlur", c.bgBlur)
            .putBoolean("invertMotion", c.invertMotion)
            .putBoolean("batterySaver", c.batterySaver)
            .putString("particleEffect", c.particleEffect)
            .putFloat("particleIntensity", c.particleIntensity)
            .putBoolean("clockOn", c.clockOn)
            .putBoolean("clock24", c.clock24)
            .putBoolean("showDate", c.showDate)
            .putFloat("clockSize", c.clockSize)
            .putFloat("clockY", c.clockY)
            .putInt("clockColor", c.clockColor)
            .putBoolean("clockBold", c.clockBold)
            .apply()
    }
}
