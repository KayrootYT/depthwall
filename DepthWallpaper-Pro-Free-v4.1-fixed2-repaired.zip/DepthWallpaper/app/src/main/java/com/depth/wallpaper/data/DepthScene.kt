package com.depth.wallpaper.data

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.Typeface
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * A wallpaper split into depth slices: [base] is the full (hidden areas filled) background,
 * [overlays] are cut-outs of everything nearer than a threshold, ordered far -> near.
 * `factor` is 0 (far) .. 1 (nearest).
 */
class DepthScene(val base: Bitmap, val overlays: List<Overlay>) {
    class Overlay(val bitmap: Bitmap, val factor: Float)

    fun recycle() {
        if (!base.isRecycled) base.recycle()
        overlays.forEach { if (!it.bitmap.isRecycled) it.bitmap.recycle() }
    }
}

object SceneBuilder {

    private fun scaledCopy(src: Bitmap, longSide: Int): Bitmap {
        val m = max(src.width, src.height)
        if (m <= longSide) return src.copy(Bitmap.Config.ARGB_8888, false) ?: error("Out of memory")
        val s = longSide.toFloat() / m
        return Bitmap.createScaledBitmap(src, max(2, (src.width * s).toInt()), max(2, (src.height * s).toInt()), true)
    }

    /** Single-layer scene (classic parallax / still preview before depth is ready). */
    fun flat(src: Bitmap, longSide: Int): DepthScene = DepthScene(scaledCopy(src, longSide), emptyList())

    fun build(src: Bitmap, depth: DepthField, layerCount: Int, fgCut: Float, bgBlur: Float, longSide: Int): DepthScene {
        val scaled = scaledCopy(src, longSide)
        val w = scaled.width
        val h = scaled.height
        val total = w * h
        val n = layerCount.coerceIn(2, 7)
        val cut = fgCut.coerceIn(0.3f, 0.95f)
        val px = IntArray(total)
        scaled.getPixels(px, 0, w, 0, 0, w, h)
        val d = sampleDepth(depth, w, h)
        val step = cut / (n - 1)
        val feather = min(0.06f, step * 0.5f)

        val overlays = ArrayList<DepthScene.Overlay>()
        for (k in 1 until n) {
            val t = step * k
            val out = IntArray(total)
            var any = false
            for (i in 0 until total) {
                val a = smoothstep(t - feather, t + feather, d[i])
                if (a > 0.003f) {
                    any = true
                    out[i] = ((a * 255f + 0.5f).toInt() shl 24) or (px[i] and 0x00FFFFFF)
                }
            }
            if (!any) continue
            val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            bmp.setPixels(out, 0, w, 0, 0, w, h)
            overlays.add(DepthScene.Overlay(bmp, k.toFloat() / (n - 1)))
        }

        var base = if (overlays.isEmpty()) scaled else fillHidden(scaled, px, d, w, h, step, feather)
        if (base !== scaled) scaled.recycle()
        if (bgBlur > 0.01f) {
            val blurred = ImageEffects.blur(base, bgBlur)
            if (blurred !== base) {
                base.recycle()
                base = blurred
            }
        }
        return DepthScene(base, overlays)
    }

    private fun sampleDepth(f: DepthField, w: Int, h: Int): FloatArray {
        val out = FloatArray(w * h)
        val fx = (f.w - 1).toFloat() / max(1, w - 1)
        val fy = (f.h - 1).toFloat() / max(1, h - 1)
        for (y in 0 until h) {
            val gy = y * fy
            val y0 = gy.toInt().coerceIn(0, f.h - 1)
            val y1 = min(f.h - 1, y0 + 1)
            val ty = gy - y0
            for (x in 0 until w) {
                val gx = x * fx
                val x0 = gx.toInt().coerceIn(0, f.w - 1)
                val x1 = min(f.w - 1, x0 + 1)
                val tx = gx - x0
                val a = f.v[y0 * f.w + x0]
                val b = f.v[y0 * f.w + x1]
                val c = f.v[y1 * f.w + x0]
                val e = f.v[y1 * f.w + x1]
                out[y * w + x] = (a + (b - a) * tx) * (1f - ty) + (c + (e - c) * tx) * ty
            }
        }
        return out
    }

    /**
     * Cheap "inpainting": the background copy gets the foreground area replaced by the colours around it
     * (normalised blur). When a near layer shifts away it reveals smooth background instead of a ghost.
     */
    private fun fillHidden(scaled: Bitmap, px: IntArray, d: FloatArray, w: Int, h: Int, t1: Float, feather: Float): Bitmap {
        val ds = max(1, max(w, h) / 192)
        val lw = max(4, w / ds)
        val lh = max(4, h / ds)
        val small = Bitmap.createScaledBitmap(scaled, lw, lh, true)
        val sp = IntArray(lw * lh)
        small.getPixels(sp, 0, lw, 0, 0, lw, lh)
        if (small !== scaled) small.recycle()

        val m = FloatArray(lw * lh)
        for (y in 0 until lh) {
            val sy = min(h - 1, y * h / lh)
            for (x in 0 until lw) {
                val sx = min(w - 1, x * w / lw)
                m[y * lw + x] = smoothstep(t1 - feather, t1 + feather, d[sy * w + sx])
            }
        }
        val grow = boxBlur(m, lw, lh, 3)
        for (i in grow.indices) grow[i] = min(1f, grow[i] * 2.5f)

        val cnt = lw * lh
        val wt = FloatArray(cnt) { 1f - grow[it] }
        val cr = FloatArray(cnt)
        val cg = FloatArray(cnt)
        val cb = FloatArray(cnt)
        var sumW = 0f
        var sumR = 0f
        var sumG = 0f
        var sumB = 0f
        for (i in 0 until cnt) {
            val c = sp[i]
            val r = ((c shr 16) and 0xFF) * wt[i]
            val g = ((c shr 8) and 0xFF) * wt[i]
            val b = (c and 0xFF) * wt[i]
            cr[i] = r; cg[i] = g; cb[i] = b
            sumW += wt[i]; sumR += r; sumG += g; sumB += b
        }
        val avgR = if (sumW > 0.01f) sumR / sumW else 128f
        val avgG = if (sumW > 0.01f) sumG / sumW else 128f
        val avgB = if (sumW > 0.01f) sumB / sumW else 128f

        val r1 = max(3, lw / 10)
        val r2 = max(6, lw / 3)
        val aR = boxBlur(cr, lw, lh, r1); val aG = boxBlur(cg, lw, lh, r1)
        val aB = boxBlur(cb, lw, lh, r1); val aW = boxBlur(wt, lw, lh, r1)
        val bR = boxBlur(cr, lw, lh, r2); val bG = boxBlur(cg, lw, lh, r2)
        val bB = boxBlur(cb, lw, lh, r2); val bW = boxBlur(wt, lw, lh, r2)

        val fillSmall = IntArray(cnt)
        for (i in 0 until cnt) {
            val r: Float
            val g: Float
            val b: Float
            if (aW[i] > 0.04f) {
                r = aR[i] / aW[i]; g = aG[i] / aW[i]; b = aB[i] / aW[i]
            } else if (bW[i] > 0.004f) {
                r = bR[i] / bW[i]; g = bG[i] / bW[i]; b = bB[i] / bW[i]
            } else {
                r = avgR; g = avgG; b = avgB
            }
            fillSmall[i] = (0xFF shl 24) or (r.toInt().coerceIn(0, 255) shl 16) or
                (g.toInt().coerceIn(0, 255) shl 8) or b.toInt().coerceIn(0, 255)
        }
        val maskSmall = IntArray(cnt) { i ->
            val v = (grow[i] * 255f + 0.5f).toInt().coerceIn(0, 255)
            (0xFF shl 24) or (v shl 16) or (v shl 8) or v
        }
        val fillBmpSmall = Bitmap.createBitmap(lw, lh, Bitmap.Config.ARGB_8888)
        fillBmpSmall.setPixels(fillSmall, 0, lw, 0, 0, lw, lh)
        val maskBmpSmall = Bitmap.createBitmap(lw, lh, Bitmap.Config.ARGB_8888)
        maskBmpSmall.setPixels(maskSmall, 0, lw, 0, 0, lw, lh)
        val fillBig = Bitmap.createScaledBitmap(fillBmpSmall, w, h, true)
        val maskBig = Bitmap.createScaledBitmap(maskBmpSmall, w, h, true)

        val fillPx = IntArray(w * h)
        val maskPx = IntArray(w * h)
        fillBig.getPixels(fillPx, 0, w, 0, 0, w, h)
        maskBig.getPixels(maskPx, 0, w, 0, 0, w, h)
        if (fillBig !== fillBmpSmall) fillBig.recycle()
        if (maskBig !== maskBmpSmall) maskBig.recycle()
        fillBmpSmall.recycle()
        maskBmpSmall.recycle()

        val out = IntArray(w * h)
        for (i in 0 until w * h) {
            val t = ((maskPx[i] shr 16) and 0xFF) / 255f
            val a = px[i]
            val b = fillPx[i]
            val r = (((a shr 16) and 0xFF) * (1f - t) + ((b shr 16) and 0xFF) * t).toInt()
            val g = (((a shr 8) and 0xFF) * (1f - t) + ((b shr 8) and 0xFF) * t).toInt()
            val bl = ((a and 0xFF) * (1f - t) + (b and 0xFF) * t).toInt()
            out[i] = (0xFF shl 24) or (r.coerceIn(0, 255) shl 16) or (g.coerceIn(0, 255) shl 8) or bl.coerceIn(0, 255)
        }
        val res = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        res.setPixels(out, 0, w, 0, 0, w, h)
        return res
    }
}

/** Draws a [DepthScene] with parallax / 3D tilt / optional depth clock. Not thread-safe: one instance per surface. */
class DepthRenderer {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val matrix = Matrix()
    private val srcPts = FloatArray(8)
    private val dstPts = FloatArray(8)
    private val cornerX = FloatArray(4)
    private val cornerY = FloatArray(4)
    private val dst = Rect()
    private val thin: Typeface = Typeface.create("sans-serif-thin", Typeface.NORMAL)
    private val bold: Typeface = Typeface.create("sans-serif", Typeface.BOLD)
    private val regular: Typeface = Typeface.create("sans-serif", Typeface.NORMAL)
    private val dateFmt = SimpleDateFormat("EEEE, d MMMM", Locale.getDefault())
    private var cachedMinute = -1L
    private var cachedClock24 = false
    private var timeText = ""
    private var dateText = ""

    fun amplitude(cfg: DepthConfig, w: Int, h: Int): Float =
        cfg.intensity.coerceIn(0f, 1.5f) * 0.05f * min(w, h)

    /** Scale that makes the bitmap cover the surface with enough spare edge for the full motion. */
    fun coverScale(w: Int, h: Int, bw: Int, bh: Int, cfg: DepthConfig): Float {
        val s0 = max(w.toFloat() / bw, h.toFloat() / bh)
        val amp = amplitude(cfg, w, h)
        val sw = bw * s0
        val sh = bh * s0
        var z = max(1f, max((w + 2f * amp) / sw, (h + 2f * amp) / sh))
        if (cfg.mode == DepthMode.TILT3D) z *= 1.10f + 0.06f * cfg.intensity.coerceIn(0f, 1.5f)
        return s0 * z
    }

    /** Plain cover-fit draw (used for the depth-map view). */
    fun drawPlain(canvas: Canvas, w: Int, h: Int, bmp: Bitmap) {
        canvas.drawColor(Color.BLACK)
        val s = max(w.toFloat() / bmp.width, h.toFloat() / bmp.height)
        val dw = (bmp.width * s).toInt()
        val dh = (bmp.height * s).toInt()
        val l = (w - dw) / 2
        val t = (h - dh) / 2
        dst.set(l, t, l + dw, t + dh)
        canvas.drawBitmap(bmp, null, dst, paint)
    }

    fun draw(canvas: Canvas, w: Int, h: Int, scene: DepthScene, cfg: DepthConfig, ox: Float, oy: Float) {
        canvas.drawColor(Color.BLACK)
        val base = scene.base
        if (base.isRecycled) return
        val s = coverScale(w, h, base.width, base.height, cfg)
        val sign = if (cfg.invertMotion) -1f else 1f
        val x = ox * sign
        val y = oy * sign
        val useOverlays = cfg.mode != DepthMode.CLASSIC && scene.overlays.isNotEmpty()
        var clockDone = !cfg.clockOn

        drawLayer(canvas, base, 0f, w, h, s, cfg, x, y)
        if (useOverlays) {
            for (o in scene.overlays) {
                if (!clockDone && o.factor >= 0.999f) {
                    drawClock(canvas, w, h, cfg)
                    clockDone = true
                }
                if (!o.bitmap.isRecycled) drawLayer(canvas, o.bitmap, o.factor, w, h, s, cfg, x, y)
            }
        }
        if (!clockDone) drawClock(canvas, w, h, cfg)
    }

    private fun drawLayer(
        canvas: Canvas, bmp: Bitmap, f: Float, w: Int, h: Int, s: Float,
        cfg: DepthConfig, x: Float, y: Float
    ) {
        val bw = bmp.width.toFloat()
        val bh = bmp.height.toFloat()
        if (cfg.mode == DepthMode.TILT3D) {
            val k = cfg.intensity.coerceIn(0f, 1.5f)
            val maxAng = 12f * k
            val ay = Math.toRadians((x * maxAng).toDouble())
            val ax = Math.toRadians((-y * maxAng).toDouble())
            val cY = cos(ay).toFloat(); val sY = sin(ay).toFloat()
            val cX = cos(ax).toFloat(); val sX = sin(ax).toFloat()
            val span = 0.06f * h * max(0.3f, k)
            val z = (f - 0.5f) * 2f * span
            val focal = 2.4f * max(w, h)
            val hw = bw * s / 2f
            val hh = bh * s / 2f
            srcPts[0] = 0f; srcPts[1] = 0f
            srcPts[2] = bw; srcPts[3] = 0f
            srcPts[4] = bw; srcPts[5] = bh
            srcPts[6] = 0f; srcPts[7] = bh
            cornerX[0] = -hw; cornerX[1] = hw; cornerX[2] = hw; cornerX[3] = -hw
            cornerY[0] = -hh; cornerY[1] = -hh; cornerY[2] = hh; cornerY[3] = hh
            for (i in 0 until 4) {
                val px = cornerX[i]
                val py = cornerY[i]
                val x1 = px * cY + z * sY
                val z1 = -px * sY + z * cY
                val y2 = py * cX - z1 * sX
                val z2 = py * sX + z1 * cX
                val p = focal / (focal - z2)
                dstPts[i * 2] = w / 2f + x1 * p
                dstPts[i * 2 + 1] = h / 2f + y2 * p
            }
            matrix.setPolyToPoly(srcPts, 0, dstPts, 0, 4)
            canvas.drawBitmap(bmp, matrix, paint)
        } else {
            val amp = amplitude(cfg, w, h)
            val k = 1f - 2f * f
            val dx = x * amp * k
            val dy = y * amp * k * 0.8f
            canvas.save()
            canvas.translate(w / 2f + dx, h / 2f + dy)
            canvas.scale(s, s)
            canvas.drawBitmap(bmp, -bw / 2f, -bh / 2f, paint)
            canvas.restore()
        }
    }

    private fun drawClock(canvas: Canvas, w: Int, h: Int, cfg: DepthConfig) {
        val now = System.currentTimeMillis()
        val minute = now / 60000L
        if (minute != cachedMinute || cfg.clock24 != cachedClock24) {
            cachedMinute = minute
            cachedClock24 = cfg.clock24
            val cal = Calendar.getInstance()
            val mi = cal.get(Calendar.MINUTE)
            timeText = if (cfg.clock24) {
                String.format(Locale.US, "%02d:%02d", cal.get(Calendar.HOUR_OF_DAY), mi)
            } else {
                val hr = cal.get(Calendar.HOUR).let { if (it == 0) 12 else it }
                String.format(Locale.US, "%d:%02d", hr, mi)
            }
            dateText = dateFmt.format(cal.time)
        }
        textPaint.color = DepthConfig.CLOCK_COLORS[cfg.clockColor.coerceIn(0, DepthConfig.CLOCK_COLORS.size - 1)]
        textPaint.textAlign = Paint.Align.CENTER
        val size = h * cfg.clockSize
        textPaint.typeface = if (cfg.clockBold) bold else thin
        textPaint.textSize = size
        val baseline = h * cfg.clockY + size * 0.35f
        canvas.drawText(timeText, w / 2f, baseline, textPaint)
        if (cfg.showDate) {
            textPaint.typeface = regular
            textPaint.textSize = size * 0.2f
            canvas.drawText(dateText, w / 2f, baseline - size * 0.8f, textPaint)
        }
    }
}
