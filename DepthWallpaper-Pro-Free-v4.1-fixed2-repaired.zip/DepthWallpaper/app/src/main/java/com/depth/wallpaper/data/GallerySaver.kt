package com.depth.wallpaper.data

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/** Copies an image to the public gallery. Android 10+ uses scoped storage without storage permission. */
suspend fun saveToGallery(ctx: Context, file: File, displayName: String): Result<Unit> =
    withContext(Dispatchers.IO) {
        var insertedUri: Uri? = null
        runCatching {
            require(file.isFile && file.length() > 0L) { "Image file is missing or empty" }
            val safeName = displayName
                .substringAfterLast('/')
                .substringAfterLast('\\')
                .replace(Regex("[^A-Za-z0-9._ -]"), "_")
                .trim().trimEnd('.')
                .take(100).ifBlank { "DepthWallpaper" }
            val finalName = if (safeName.endsWith(".jpg", ignoreCase = true) || safeName.endsWith(".jpeg", ignoreCase = true)) safeName else "$safeName.jpg"
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, finalName)
                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                if (Build.VERSION.SDK_INT >= 29) {
                    put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/DepthWallpaper")
                    put(MediaStore.Images.Media.IS_PENDING, 1)
                }
            }
            val resolver = ctx.contentResolver
            insertedUri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                ?: error("Gallery is not available on this device")
            resolver.openOutputStream(insertedUri!!, "w")?.use { out ->
                file.inputStream().use { input -> input.copyTo(out) }
            } ?: error("Could not write to the gallery")
            if (Build.VERSION.SDK_INT >= 29) {
                val ready = ContentValues().apply { put(MediaStore.Images.Media.IS_PENDING, 0) }
                check(resolver.update(insertedUri!!, ready, null, null) > 0) { "Could not finish saving the image" }
            }
            Unit
        }.onFailure {
            insertedUri?.let { uri -> runCatching { ctx.contentResolver.delete(uri, null, null) } }
        }
    }
