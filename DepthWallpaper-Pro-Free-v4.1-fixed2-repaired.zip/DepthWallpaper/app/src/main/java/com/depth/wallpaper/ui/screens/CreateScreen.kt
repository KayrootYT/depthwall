package com.depth.wallpaper.ui.screens

import android.graphics.Bitmap
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.Autorenew
import androidx.compose.material.icons.outlined.Schedule
import androidx.compose.material.icons.outlined.BlurOn
import androidx.compose.material.icons.outlined.Layers
import androidx.compose.material.icons.outlined.OpenWith
import androidx.compose.material.icons.outlined.Palette
import androidx.compose.material.icons.outlined.PhotoLibrary
import androidx.compose.material.icons.outlined.ViewInAr
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.depth.wallpaper.data.ImageEffects
import com.depth.wallpaper.data.applyWallpaper
import com.depth.wallpaper.data.decodeScaled
import com.depth.wallpaper.ui.AppViewModel
import com.depth.wallpaper.ui.components.AppImage
import com.depth.wallpaper.ui.components.GlassChip
import com.depth.wallpaper.ui.components.GlassSurface
import com.depth.wallpaper.ui.components.GradientButton
import com.depth.wallpaper.ui.components.SetWallpaperDialog
import com.depth.wallpaper.ui.components.TopBar
import com.depth.wallpaper.ui.theme.ElectricBlue
import com.depth.wallpaper.ui.theme.GoldPro
import com.depth.wallpaper.ui.theme.NavySurface
import com.depth.wallpaper.ui.theme.NeonCyan
import com.depth.wallpaper.ui.theme.NeonPurple
import com.depth.wallpaper.ui.theme.TextPrimary
import com.depth.wallpaper.ui.theme.TextSecondary
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private data class Effect(val id: String, val title: String, val subtitle: String, val icon: ImageVector)

private val EFFECTS = listOf(
    Effect("studio_clock", "Depth Clock", "Subject over the clock", Icons.Outlined.Schedule),
    Effect("studio_parallax", "Depth Parallax", "Layers move with gyro", Icons.Outlined.Layers),
    Effect("studio_tilt", "3D Tilt", "Real 3D live wallpaper", Icons.Outlined.ViewInAr),
    Effect("studio_auto", "Auto Float", "Moves by itself", Icons.Outlined.Autorenew),
    Effect("blur", "Blur Effect", "", Icons.Outlined.BlurOn),
    Effect("filters", "Color Filters", "", Icons.Outlined.Palette),
    Effect("3d", "3D Anaglyph", "", Icons.Outlined.ViewInAr),
    Effect("art", "Artistic Styles", "", Icons.Outlined.AutoAwesome)
)

@Composable
fun CreateScreen(vm: AppViewModel, nav: NavHostController) {
    Column(Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState())) {
        TopBar("Create") {
            Icon(Icons.Filled.Star, "All features unlocked", tint = GoldPro)
        }

        GlassSurface(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
            RoundedCornerShape(24.dp),
            glow = NeonPurple.copy(alpha = 0.35f)
        ) {
            Column(Modifier.padding(18.dp)) {
                Text("Generate Wallpaper", color = TextPrimary, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text(
                    "Free AI prompt (online) plus Mesh, Aurora, Waves, Peaks and Nebula art made on your phone.",
                    color = TextSecondary,
                    fontSize = 13.sp
                )
                Spacer(Modifier.height(12.dp))
                GradientButton(
                    text = "Open Generator",
                    modifier = Modifier.fillMaxWidth(),
                    icon = Icons.Outlined.AutoAwesome,
                    onClick = { nav.navigate("generate") }
                )
            }
        }

        GlassSurface(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp),
            RoundedCornerShape(24.dp),
            glow = ElectricBlue.copy(alpha = 0.35f),
            onClick = { nav.navigate("studio?mode=depth") }
        ) {
            Column(Modifier.padding(18.dp)) {
                Text("Depth Studio", color = TextPrimary, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Text(
                    "Pick any photo, build a depth map, tap the subject, then make a depth / 3D live wallpaper.",
                    color = TextSecondary,
                    fontSize = 12.sp
                )
            }
        }

        EFFECTS.chunked(2).forEach { row ->
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                row.forEach { e ->
                    GlassSurface(
                        Modifier.weight(1f).height(120.dp),
                        RoundedCornerShape(22.dp),
                        glow = ElectricBlue.copy(alpha = 0.25f),
                        onClick = {
                            if (e.id.startsWith("studio_")) nav.navigate("studio?mode=${e.id.removePrefix("studio_")}")
                            else nav.navigate("editor/${e.id}")
                        }
                    ) {
                        Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(e.icon, null, tint = NeonCyan, modifier = Modifier.size(34.dp))
                            Spacer(Modifier.height(8.dp))
                            Text(e.title, color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                            if (e.subtitle.isNotEmpty()) Text(e.subtitle, color = TextSecondary, fontSize = 10.sp)
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(130.dp))
    }
}

@Composable
fun EditorScreen(vm: AppViewModel, nav: NavHostController, effect: String) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var source by remember { mutableStateOf<Bitmap?>(null) }
    var result by remember { mutableStateOf<Bitmap?>(null) }
    var option by rememberSaveable { mutableIntStateOf(0) }
    var strength by rememberSaveable { mutableFloatStateOf(0.5f) }
    var busy by remember { mutableStateOf(false) }
    var showSet by remember { mutableStateOf(false) }
    val options = remember(effect) { ImageEffects.optionsFor(effect) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            scope.launch {
                busy = true
                val bmp = withContext(Dispatchers.IO) { runCatching { decodeScaled(ctx, uri, 1600) }.getOrNull() }
                if (bmp == null) vm.say("Couldn't open that image") else source = bmp
                busy = false
            }
        }
    }
    fun pick() = picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))

    LaunchedEffect(source, option, strength) {
        val s = source ?: return@LaunchedEffect
        delay(120)
        busy = true
        result = withContext(Dispatchers.Default) { ImageEffects.apply(effect, s, option, strength) }
        busy = false
    }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        TopBar(ImageEffects.titleFor(effect), onBack = { nav.popBackStack() })

        Box(
            Modifier.weight(1f).fillMaxWidth().padding(horizontal = 16.dp),
            contentAlignment = Alignment.Center
        ) {
            val shown = result ?: source
            if (shown == null) {
                GlassSurface(Modifier.fillMaxWidth().height(220.dp), RoundedCornerShape(24.dp), onClick = { pick() }) {
                    Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Outlined.PhotoLibrary, null, tint = NeonCyan, modifier = Modifier.size(40.dp))
                        Spacer(Modifier.height(10.dp))
                        Text("Choose a photo", color = TextPrimary, fontWeight = FontWeight.SemiBold)
                        Text("Your photo stays on this device", color = TextSecondary, fontSize = 12.sp)
                    }
                }
            } else {
                Image(
                    bitmap = shown.asImageBitmap(),
                    contentDescription = "Preview",
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.fillMaxSize()
                )
            }
            if (busy) CircularProgressIndicator(color = NeonCyan)
        }

        Column(Modifier.padding(16.dp)) {
            if (options.isNotEmpty()) {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    itemsIndexed(options) { i, name -> GlassChip(name, option == i) { option = i } }
                }
                Spacer(Modifier.height(8.dp))
            }
            Text("Strength", color = TextSecondary, fontSize = 12.sp)
            Slider(
                value = strength,
                onValueChange = { strength = it },
                colors = SliderDefaults.colors(
                    thumbColor = NeonCyan,
                    activeTrackColor = ElectricBlue,
                    inactiveTrackColor = Color.White.copy(alpha = 0.15f)
                )
            )
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                GlassSurface(Modifier.weight(1f).height(54.dp), RoundedCornerShape(18.dp), onClick = { pick() }) {
                    Text("Photo", color = TextPrimary, modifier = Modifier.align(Alignment.Center))
                }
                GradientButton(
                    text = "Save",
                    modifier = Modifier.weight(1f),
                    enabled = result != null
                ) {
                    val r = result ?: return@GradientButton
                    scope.launch {
                        vm.saveEdited(r)
                        vm.say("Saved to Downloads")
                    }
                }
                GradientButton(
                    text = "Set",
                    modifier = Modifier.weight(1f),
                    enabled = result != null
                ) { showSet = true }
            }
            Spacer(Modifier.height(100.dp))
        }
    }

    if (showSet) {
        SetWallpaperDialog(onDismiss = { showSet = false }) { target ->
            showSet = false
            val r = result ?: return@SetWallpaperDialog
            scope.launch {
                val file = vm.saveEdited(r)
                applyWallpaper(ctx, file, target)
                    .onSuccess { vm.say("Wallpaper set!") }
                    .onFailure { vm.say("Couldn't set wallpaper: ${it.message}") }
            }
        }
    }
}
