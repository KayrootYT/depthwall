package com.depth.wallpaper.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.History
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import com.depth.wallpaper.data.HistoryEntry
import com.depth.wallpaper.data.Resolution
import com.depth.wallpaper.data.WallpaperRepository
import com.depth.wallpaper.data.WallpaperTarget
import com.depth.wallpaper.data.applyWallpaper
import com.depth.wallpaper.ui.AppViewModel
import com.depth.wallpaper.ui.components.EmptyState
import com.depth.wallpaper.ui.components.GlassSurface
import com.depth.wallpaper.ui.components.TopBar
import com.depth.wallpaper.ui.theme.ElectricBlue
import com.depth.wallpaper.ui.theme.NeonCyan
import com.depth.wallpaper.ui.theme.TextPrimary
import com.depth.wallpaper.ui.theme.TextSecondary
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun HistoryScreen(vm: AppViewModel, nav: NavHostController) {
    val ctx = LocalContext.current
    val entries by vm.history.collectAsStateWithLifecycle()
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }
    val fmt = remember { SimpleDateFormat("d MMM yyyy, hh:mm a", Locale.getDefault()) }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        TopBar("History", onBack = { nav.popBackStack() })

        if (entries.isEmpty()) {
            EmptyState(
                icon = Icons.Outlined.History,
                title = "No history yet",
                subtitle = "Every wallpaper you set (manually or by the auto changer) is listed here.",
                actionLabel = "Explore wallpapers",
                onAction = { nav.navigate("explore") }
            )
        } else {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.End
            ) {
                TextButton(onClick = { vm.clearHistory() }) {
                    Text("Clear all", color = TextSecondary)
                }
            }
            LazyColumn(
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 40.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(entries, key = { it.id + it.time + it.source }) { e ->
                    GlassSurface(Modifier.fillMaxWidth(), RoundedCornerShape(18.dp)) {
                        Row(
                            Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(e.title, color = TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                                Text(
                                    "${if (e.source == "AUTO") "Auto changer" else "Set by you"} · ${fmt.format(Date(e.time))}",
                                    color = TextSecondary,
                                    fontSize = 12.sp
                                )
                            }
                            Spacer(Modifier.width(8.dp))
                            TextButton(
                                enabled = !busy,
                                onClick = {
                                    busy = true
                                    scope.launch {
                                        reapply(ctx, vm, e)
                                        busy = false
                                    }
                                }
                            ) {
                                Text("Apply", color = ElectricBlue)
                            }
                        }
                    }
                }
            }
        }
    }
}

private suspend fun reapply(ctx: android.content.Context, vm: AppViewModel, e: HistoryEntry) {
    val local = vm.fileNamed(e.id)
    val result = when {
        local.exists() -> applyWallpaper(ctx, local, WallpaperTarget.BOTH)
        else -> {
            val w = WallpaperRepository.byId(e.id)
            if (w == null) Result.failure<java.lang.IllegalStateException>(IllegalStateException("Wallpaper is no longer available"))
            else vm.fetch(w, Resolution.HD).fold(
                onSuccess = { applyWallpaper(ctx, it, WallpaperTarget.BOTH) },
                onFailure = { Result.failure(it) }
            )
        }
    }
    vm.say(result.fold({ "Wallpaper applied" }, { it.message ?: "Could not apply" }))
}
