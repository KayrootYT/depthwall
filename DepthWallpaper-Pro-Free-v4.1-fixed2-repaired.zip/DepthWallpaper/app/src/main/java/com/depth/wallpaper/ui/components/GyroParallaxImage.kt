package com.depth.wallpaper.ui.components

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.Lifecycle
import com.depth.wallpaper.data.ParallaxTracker
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import kotlin.math.max
import kotlin.math.min

/**
 * Gyroscope/rotation-vector driven parallax preview. This moves a single image subtly;
 * it does not invent foreground/background depth layers. Real layered depth requires a depth map.
 */
@Composable
fun GyroParallaxImage(
    model: Any?,
    modifier: Modifier = Modifier,
    placeholderUrl: String? = null,
    enabled: Boolean = true,
    maxShiftDp: Float = 14f
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    var shiftX by remember { mutableFloatStateOf(0f) }
    var shiftY by remember { mutableFloatStateOf(0f) }

    DisposableEffect(context, lifecycleOwner, enabled) {
        val manager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val sensor = manager.getDefaultSensor(Sensor.TYPE_GAME_ROTATION_VECTOR)
            ?: manager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
        var started = false
        val tracker = ParallaxTracker()
        val listener = object : SensorEventListener {
            override fun onSensorChanged(event: SensorEvent) {
                tracker.onSensor(event.values)
                tracker.step()
                shiftX = tracker.x
                shiftY = tracker.y
            }
            override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit
        }
        fun start() {
            if (enabled && !started && sensor != null) {
                tracker.reset()
                started = manager.registerListener(listener, sensor, SensorManager.SENSOR_DELAY_GAME)
            }
        }
        fun stop() {
            if (started) manager.unregisterListener(listener)
            started = false
        }
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_RESUME -> start()
                Lifecycle.Event.ON_PAUSE, Lifecycle.Event.ON_STOP -> stop()
                else -> Unit
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        if (lifecycleOwner.lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED)) start()
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
            stop()
        }
    }

    Box(modifier = modifier) {
        AppImage(
            model = model,
            modifier = Modifier.fillMaxSize().graphicsLayer {
                val x = shiftX.coerceIn(-1f, 1f) * max(0f, maxShiftDp)
                val y = shiftY.coerceIn(-1f, 1f) * max(0f, maxShiftDp)
                translationX = x * density
                translationY = y * density
                scaleX = 1.08f
                scaleY = 1.08f
            },
            placeholderUrl = placeholderUrl
        )
    }
}
