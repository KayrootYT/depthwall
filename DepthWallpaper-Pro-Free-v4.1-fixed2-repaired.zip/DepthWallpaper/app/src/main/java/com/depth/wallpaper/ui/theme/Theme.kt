package com.depth.wallpaper.ui.theme

import android.os.Build
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

// ---- Design tokens ----
val Amoled = Color(0xFF000000)
val Navy = Color(0xFF0A1128)
val NavySurface = Color(0xFF111B3A)
val ElectricBlue = Color(0xFF2F6BFF)
val NeonPurple = Color(0xFFA85BFF)
val NeonCyan = Color(0xFF35E0FF)
val TextPrimary = Color(0xFFFFFFFF)
val TextSecondary = Color(0xFFA9B4D0)
val GoldPro = Color(0xFFFFC53D)
val HeartRed = Color(0xFFFF4D6D)
val BrandGradient = Brush.horizontalGradient(listOf(ElectricBlue, NeonPurple))
val BlueGradient = Brush.horizontalGradient(listOf(Color(0xFF2F6BFF), Color(0xFF5B8CFF)))

private val baseScheme = darkColorScheme(
    primary = ElectricBlue,
    secondary = NeonPurple,
    tertiary = NeonCyan,
    background = Amoled,
    surface = NavySurface,
    onPrimary = Color.White,
    onBackground = TextPrimary,
    onSurface = TextPrimary
)

/**
 * App theme. Pass dynamic = true to follow the system Material You palette
 * (Android 12+); the AMOLED background is kept either way.
 */
@Composable
fun DepthTheme(dynamic: Boolean = false, content: @Composable () -> Unit) {
    val scheme = if (dynamic && Build.VERSION.SDK_INT >= 31) {
        val dyn = dynamicDarkColorScheme(LocalContext.current)
        darkColorScheme(
            primary = dyn.primary,
            onPrimary = dyn.onPrimary,
            primaryContainer = dyn.primaryContainer,
            onPrimaryContainer = dyn.onPrimaryContainer,
            secondary = dyn.secondary,
            onSecondary = dyn.onSecondary,
            secondaryContainer = dyn.secondaryContainer,
            tertiary = dyn.tertiary,
            onTertiary = dyn.onTertiary,
            surfaceVariant = dyn.surfaceVariant,
            onSurfaceVariant = dyn.onSurfaceVariant,
            outline = dyn.outline,
            background = Amoled,
            onBackground = TextPrimary,
            surface = NavySurface,
            onSurface = TextPrimary
        )
    } else baseScheme

    MaterialTheme(colorScheme = scheme) {
        Surface(modifier = Modifier.fillMaxSize(), color = Amoled, contentColor = TextPrimary, content = content)
    }
}
