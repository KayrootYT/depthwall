package com.depth.wallpaper.data

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

/** Small, allocation-conscious Canvas particle overlay for live wallpaper scenes. */
class ParticleEffects {
    private data class Particle(var x: Float, var y: Float, var speed: Float, var size: Float, var drift: Float, var phase: Float)
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeCap = Paint.Cap.ROUND; style = Paint.Style.STROKE }
    private var particles = ArrayList<Particle>()
    private var lastMode = "OFF"
    private var lastW = 0
    private var lastH = 0
    private var clock = 0f

    fun draw(canvas: Canvas, width: Int, height: Int, mode: String, intensity: Float, dtSeconds: Float) {
        if (mode == "OFF" || width <= 0 || height <= 0) return
        val w = width.toFloat(); val h = height.toFloat()
        if (mode != lastMode || width != lastW || height != lastH) reset(mode, width, height, intensity)
        clock += dtSeconds.coerceIn(0f, 0.05f)
        val density = (width * height / 9500f * intensity).toInt().coerceIn(24, if (mode == "RAIN") 150 else 95)
        while (particles.size < density) particles.add(newParticle(w, h, mode, true))
        while (particles.size > density) particles.removeAt(particles.lastIndex)
        when (mode) {
            "RAIN" -> {
                paint.color = 0x6679CFFF; paint.strokeWidth = (width * 0.0015f).coerceIn(1.1f, 2.4f)
                for (p in particles) {
                    p.x += (p.drift - width * 0.035f) * dtSeconds
                    p.y += p.speed * dtSeconds
                    if (p.y > h + 35f || p.x < -20f) { p.x = Random.nextFloat() * w; p.y = -Random.nextFloat() * h * 0.25f; p.speed = h * (0.65f + Random.nextFloat() * 0.65f) }
                    canvas.drawLine(p.x, p.y, p.x - width * 0.008f, p.y + p.size * 5f, paint)
                }
            }
            "SNOW" -> {
                paint.style = Paint.Style.FILL; paint.color = 0xBFFFFFFF.toInt()
                for (p in particles) {
                    p.x += (sin(clock * 1.3f + p.phase) * p.drift + cos(p.phase) * 4f) * dtSeconds
                    p.y += p.speed * dtSeconds
                    if (p.y > h + 8f) { p.y = -8f; p.x = Random.nextFloat() * w }
                    if (p.x < -8f) p.x = w + 8f else if (p.x > w + 8f) p.x = -8f
                    canvas.drawCircle(p.x, p.y, p.size, paint)
                }
                paint.style = Paint.Style.STROKE
            }
            "PETALS" -> {
                paint.style = Paint.Style.FILL
                for (p in particles) {
                    p.x += (sin(clock * 1.5f + p.phase) * p.drift) * dtSeconds
                    p.y += p.speed * dtSeconds
                    if (p.y > h + 14f) { p.y = -12f; p.x = Random.nextFloat() * w }
                    if (p.x < -12f) p.x = w + 10f else if (p.x > w + 12f) p.x = -10f
                    paint.color = if (p.phase.toInt() % 2 == 0) 0xDFFF9FCA.toInt() else 0xDFFFC6D8.toInt()
                    canvas.save(); canvas.rotate((sin(clock + p.phase) * 45f), p.x, p.y)
                    canvas.drawOval(p.x - p.size, p.y - p.size * 1.8f, p.x + p.size, p.y + p.size * 1.8f, paint)
                    canvas.restore()
                }
                paint.style = Paint.Style.STROKE
            }
        }
    }

    private fun reset(mode: String, width: Int, height: Int, intensity: Float) {
        lastMode = mode; lastW = width; lastH = height; particles.clear(); clock = 0f
        val count = (width * height / 9500f * intensity).toInt().coerceIn(24, if (mode == "RAIN") 150 else 95)
        repeat(count) { particles.add(newParticle(width.toFloat(), height.toFloat(), mode, false)) }
    }

    private fun newParticle(w: Float, h: Float, mode: String, startAbove: Boolean): Particle {
        val size = when (mode) { "RAIN" -> 1.2f + Random.nextFloat() * 1.4f; "SNOW" -> 1f + Random.nextFloat() * 2.4f; else -> 2f + Random.nextFloat() * 3f }
        val speed = when (mode) { "RAIN" -> h * (0.65f + Random.nextFloat() * 0.65f); "SNOW" -> h * (0.035f + Random.nextFloat() * 0.09f); else -> h * (0.045f + Random.nextFloat() * 0.10f) }
        return Particle(Random.nextFloat() * w, if (startAbove) -Random.nextFloat() * h else Random.nextFloat() * h, speed, size, 8f + Random.nextFloat() * 30f, Random.nextFloat() * 6.28f)
    }
}
