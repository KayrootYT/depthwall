package com.depth.wallpaper.data

import android.graphics.Bitmap
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/** User-adjustable knobs of the on-device depth estimate. All 0..1. */
data class DepthParams(
    val smooth: Float = 0.45f,
    val contrast: Float = 0.5f,
    val vertical: Float = 0.35f,
    val focus: Float = 0.5f,
    val saliency: Float = 0.55f,
    val invert: Boolean = false
)

/** Depth values 0 (far) .. 1 (near) on a small grid. */
class DepthField(val w: Int, val h: Int, val v: FloatArray)

internal fun smoothstep(e0: Float, e1: Float, x: Float): Float {
    if (e1 <= e0) return if (x >= e0) 1f else 0f
    val t = ((x - e0) / (e1 - e0)).coerceIn(0f, 1f)
    return t * t * (3f - 2f * t)
}

internal fun boxBlur(src: FloatArray, w: Int, h: Int, r: Int): FloatArray {
    if (r <= 0) return src.copyOf()
    val tmp = FloatArray(src.size)
    val out = FloatArray(src.size)
    val div = (2 * r + 1).toFloat()
    for (y in 0 until h) {
        val row = y * w
        var sum = 0f
        for (x in -r..r) sum += src[row + x.coerceIn(0, w - 1)]
        for (x in 0 until w) {
            tmp[row + x] = sum / div
            sum += src[row + min(w - 1, x + r + 1)] - src[row + max(0, x - r)]
        }
    }
    for (x in 0 until w) {
        var sum = 0f
        for (y in -r..r) sum += tmp[y.coerceIn(0, h - 1) * w + x]
        for (y in 0 until h) {
            out[y * w + x] = sum / div
            sum += tmp[min(h - 1, y + r + 1) * w + x] - tmp[max(0, y - r) * w + x]
        }
    }
    return out
}

/**
 * On-device depth estimation. This is a multi-cue heuristic (colour saliency, focus/sharpness,
 * ground-is-near bias) plus an optional user-selected subject. It is NOT a neural network, so it
 * will not be perfect on every photo - which is why every cue is exposed as a slider in Depth Studio.
 */
object DepthPipeline {
    const val WORK_SIDE = 640

    class Work(val w: Int, val h: Int, val rgb: IntArray)
    class SubjectResult(val mask: FloatArray, val coverage: Float)

    fun prepare(src: Bitmap): Work {
        val m = max(src.width, src.height)
        val k = min(1f, WORK_SIDE.toFloat() / m)
        val w = max(8, (src.width * k).toInt())
        val h = max(8, (src.height * k).toInt())
        val scaled = if (w == src.width && h == src.height) src else Bitmap.createScaledBitmap(src, w, h, true)
        val px = IntArray(w * h)
        scaled.getPixels(px, 0, w, 0, 0, w, h)
        if (scaled !== src) scaled.recycle()
        return Work(w, h, px)
    }

    private fun stretch(a: FloatArray, lo: Float = 0.02f, hi: Float = 0.98f) {
        var mn = Float.MAX_VALUE
        var mx = -Float.MAX_VALUE
        for (v in a) {
            if (v < mn) mn = v
            if (v > mx) mx = v
        }
        val range = mx - mn
        if (range < 1e-6f) {
            a.fill(0.5f)
            return
        }
        val hist = IntArray(256)
        for (v in a) hist[(((v - mn) / range) * 255f).toInt().coerceIn(0, 255)]++
        val total = a.size
        var acc = 0
        var loBin = 0
        var hiBin = 255
        for (i in 0..255) {
            acc += hist[i]
            if (acc >= total * lo) { loBin = i; break }
        }
        acc = 0
        for (i in 255 downTo 0) {
            acc += hist[i]
            if (acc >= total * (1f - hi)) { hiBin = i; break }
        }
        val lov = mn + range * loBin / 255f
        val hiv = mn + range * (hiBin + 1) / 255f
        val d = max(1e-6f, hiv - lov)
        for (i in a.indices) a[i] = ((a[i] - lov) / d).coerceIn(0f, 1f)
    }

    fun estimate(work: Work, p: DepthParams, subject: FloatArray?): DepthField {
        val w = work.w
        val h = work.h
        val n = w * h
        val rgb = work.rgb
        val lum = FloatArray(n)
        val col = FloatArray(n)
        var mr = 0.0
        var mg = 0.0
        var mb = 0.0
        for (c in rgb) {
            mr += ((c shr 16) and 0xFF)
            mg += ((c shr 8) and 0xFF)
            mb += (c and 0xFF)
        }
        val fr = (mr / n).toFloat()
        val fg = (mg / n).toFloat()
        val fb = (mb / n).toFloat()
        for (i in 0 until n) {
            val c = rgb[i]
            val r = ((c shr 16) and 0xFF).toFloat()
            val g = ((c shr 8) and 0xFF).toFloat()
            val b = (c and 0xFF).toFloat()
            lum[i] = 0.299f * r + 0.587f * g + 0.114f * b
            val dr = r - fr
            val dg = g - fg
            val db = b - fb
            col[i] = sqrt(dr * dr + dg * dg + db * db)
        }
        val sal = boxBlur(col, w, h, max(1, w / 32))
        stretch(sal)

        val sharpRaw = FloatArray(n)
        for (y in 0 until h) {
            val y0 = max(0, y - 1)
            val y1 = min(h - 1, y + 1)
            for (x in 0 until w) {
                val x0 = max(0, x - 1)
                val x1 = min(w - 1, x + 1)
                sharpRaw[y * w + x] = abs(lum[y * w + x1] - lum[y * w + x0]) + abs(lum[y1 * w + x] - lum[y0 * w + x])
            }
        }
        val sharp = boxBlur(sharpRaw, w, h, max(2, w / 20))
        stretch(sharp)

        val wS = 0.15f + 1.35f * p.saliency
        val wF = 0.15f + 1.35f * p.focus
        val wV = 1.5f * p.vertical
        val total = wS + wF + wV + 0.0001f
        val dep = FloatArray(n)
        for (y in 0 until h) {
            val vy = y.toFloat() / (h - 1)
            val cyy = vy - 0.5f
            for (x in 0 until w) {
                val cxx = x.toFloat() / (w - 1) - 0.5f
                val centre = exp(-(cxx * cxx * 5f + cyy * cyy * 3f))
                val i = y * w + x
                dep[i] = (sal[i] * (0.55f + 0.45f * centre) * wS + sharp[i] * wF + vy * wV) / total
            }
        }
        val rad = max(1, ((0.5f + p.smooth * 3f) * w / 100f).toInt())
        var d = boxBlur(dep, w, h, rad)
        d = boxBlur(d, w, h, rad)
        stretch(d)
        val gain = 0.7f + p.contrast * 1.8f
        for (i in 0 until n) d[i] = ((d[i] - 0.5f) * gain + 0.5f).coerceIn(0f, 1f)

        if (subject != null) {
            var m = boxBlur(subject, w, h, max(2, w / 90))
            for (i in 0 until n) m[i] = smoothstep(0.25f, 0.65f, m[i])
            m = boxBlur(m, w, h, 2)
            for (i in 0 until n) d[i] = d[i] * 0.55f * (1f - m[i]) + (0.8f + 0.2f * d[i]) * m[i]
        }
        if (p.invert) for (i in 0 until n) d[i] = 1f - d[i]
        return DepthField(w, h, d)
    }

    /**
     * Flood-fills similar colours around the tapped point and ADDS them to [existing].
     * Returns null when the area is too tiny or swallows most of the photo.
     */
    fun selectSubject(work: Work, existing: FloatArray?, sx: Int, sy: Int, tolerance: Float): SubjectResult? {
        val w = work.w
        val h = work.h
        val n = w * h
        val rgb = work.rgb
        var sr = 0
        var sg = 0
        var sb = 0
        var cnt = 0
        for (dy in -2..2) for (dx in -2..2) {
            val x = (sx + dx).coerceIn(0, w - 1)
            val y = (sy + dy).coerceIn(0, h - 1)
            val c = rgb[y * w + x]
            sr += (c shr 16) and 0xFF
            sg += (c shr 8) and 0xFF
            sb += c and 0xFF
            cnt++
        }
        sr /= cnt; sg /= cnt; sb /= cnt
        val tol = 14f + tolerance.coerceIn(0f, 1f) * 100f
        val tol2 = tol * tol
        val visited = BooleanArray(n)
        val queue = IntArray(n)
        var head = 0
        var tail = 0
        val start = sy.coerceIn(0, h - 1) * w + sx.coerceIn(0, w - 1)
        queue[tail++] = start
        visited[start] = true
        val out = existing?.copyOf() ?: FloatArray(n)
        var added = 0
        while (head < tail) {
            val i = queue[head++]
            val c = rgb[i]
            val dr = ((c shr 16) and 0xFF) - sr
            val dg = ((c shr 8) and 0xFF) - sg
            val db = (c and 0xFF) - sb
            if ((dr * dr + dg * dg + db * db).toFloat() > tol2) continue
            out[i] = 1f
            added++
            val x = i % w
            val y = i / w
            if (x > 0 && !visited[i - 1]) { visited[i - 1] = true; queue[tail++] = i - 1 }
            if (x < w - 1 && !visited[i + 1]) { visited[i + 1] = true; queue[tail++] = i + 1 }
            if (y > 0 && !visited[i - w]) { visited[i - w] = true; queue[tail++] = i - w }
            if (y < h - 1 && !visited[i + w]) { visited[i + w] = true; queue[tail++] = i + w }
        }
        var total = 0
        for (v in out) if (v > 0f) total++
        val coverage = total.toFloat() / n
        if (added < n * 0.002f || coverage > 0.7f) return null
        return SubjectResult(out, coverage)
    }

    fun toGray(f: DepthField): Bitmap {
        val px = IntArray(f.w * f.h) { i ->
            val v = (f.v[i] * 255f + 0.5f).toInt().coerceIn(0, 255)
            (0xFF shl 24) or (v shl 16) or (v shl 8) or v
        }
        return Bitmap.createBitmap(f.w, f.h, Bitmap.Config.ARGB_8888).also { it.setPixels(px, 0, f.w, 0, 0, f.w, f.h) }
    }

    fun fromGray(b: Bitmap): DepthField {
        val w = b.width
        val h = b.height
        val px = IntArray(w * h)
        b.getPixels(px, 0, w, 0, 0, w, h)
        return DepthField(w, h, FloatArray(w * h) { i -> ((px[i] shr 16) and 0xFF) / 255f })
    }
}
