package com.depth.wallpaper.data

import android.content.Context
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.first
import java.util.concurrent.TimeUnit

/**
 * Automatically changes the wallpaper on a schedule.
 * Source can be the user's Favorites (needs network to fetch) or local Downloads (works offline).
 */
class AutoWallpaperWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {

    override suspend fun doWork(): Result {
        val prefs = PrefsStore(applicationContext)
        return try {
            val target = prefs.autoTarget.first()
            val file = if (target == "downloads") {
                val files = Downloader(applicationContext).list()
                if (files.isEmpty()) null else files.random().file
            } else {
                val favs = prefs.favorites.first().toList()
                val w = if (favs.isNotEmpty()) WallpaperRepository.byId(favs.random()) else null
                if (w == null) {
                    // Fallback: nothing in favourites -> pick a random downloaded one.
                    val files = Downloader(applicationContext).list()
                    if (files.isEmpty()) null else files.random().file
                } else {
                    Downloader(applicationContext).download(w, Resolution.HD) {}
                }
            } ?: return Result.success() // nothing to set yet; try again next cycle

            val r = applyWallpaper(applicationContext, file, WallpaperTarget.BOTH)
            if (r.isSuccess) {
                HistoryTracker.record(
                    applicationContext,
                    HistoryEntry(file.name, file.nameWithoutExtension, "AUTO", System.currentTimeMillis())
                )
                Result.success()
            } else if (runAttemptCount < 3) Result.retry() else Result.success()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            if (runAttemptCount < 3) Result.retry() else Result.failure()
        }
    }
}

object AutoWallpaper {
    private const val WORK = "auto_wallpaper_change"

    /** minutes <= 0 cancels the schedule. WorkManager minimum interval is 15 minutes. */
    fun schedule(ctx: Context, minutes: Int, needsNetwork: Boolean) {
        if (minutes <= 0) {
            cancel(ctx)
            return
        }
        val constraints = Constraints.Builder()
            .setRequiresBatteryNotLow(true)
            .apply { if (needsNetwork) setRequiredNetworkType(NetworkType.CONNECTED) }
            .build()
        val request = PeriodicWorkRequestBuilder<AutoWallpaperWorker>(
            minutes.coerceAtLeast(15).toLong(), TimeUnit.MINUTES
        ).setConstraints(constraints).build()
        WorkManager.getInstance(ctx)
            .enqueueUniquePeriodicWork(WORK, ExistingPeriodicWorkPolicy.UPDATE, request)
    }

    fun cancel(ctx: Context) {
        WorkManager.getInstance(ctx).cancelUniqueWork(WORK)
    }
}
