package com.depth.wallpaper.ui.screens

import android.text.format.Formatter
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Layers
import androidx.compose.material.icons.outlined.Download
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material.icons.outlined.BookmarkAdd
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import com.depth.wallpaper.data.DownloadedFile
import com.depth.wallpaper.data.WallpaperRepository
import com.depth.wallpaper.data.shareFile
import com.depth.wallpaper.data.viewFile
import com.depth.wallpaper.ui.AppViewModel
import com.depth.wallpaper.ui.components.AppImage
import com.depth.wallpaper.ui.components.EmptyState
import com.depth.wallpaper.ui.components.GlassSurface
import com.depth.wallpaper.ui.components.TopBar
import com.depth.wallpaper.ui.theme.ElectricBlue
import com.depth.wallpaper.ui.theme.HeartRed
import com.depth.wallpaper.ui.theme.NavySurface
import com.depth.wallpaper.ui.theme.NeonCyan
import com.depth.wallpaper.ui.theme.TextPrimary
import com.depth.wallpaper.ui.theme.TextSecondary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun DownloadsScreen(vm: AppViewModel, nav: NavHostController) {
    val ctx = LocalContext.current
    val items by vm.downloads.collectAsStateWithLifecycle()
    val progress by vm.progress.collectAsStateWithLifecycle()
    var toDelete by remember { mutableStateOf<DownloadedFile?>(null) }
    val dateFmt = remember { SimpleDateFormat("d MMM yyyy", Locale.getDefault()) }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        TopBar("Downloads")
        if (items.isEmpty() && progress.isEmpty()) {
            EmptyState(
                icon = Icons.Outlined.Download,
                title = "No downloads yet",
                subtitle = "Wallpapers you download are saved here and work offline.",
                actionLabel = "Explore Wallpapers",
                onAction = { nav.navigate("explore") }
            )
        } else {
            LazyColumn(
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 130.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(progress.entries.toList(), key = { "p_" + it.key }) { e ->
                    val id = e.key.substringBefore("__")
                    val res = e.key.substringAfter("__")
                    val title = WallpaperRepository.byId(id)?.title ?: "Wallpaper"
                    GlassSurface(Modifier.fillMaxWidth(), RoundedCornerShape(18.dp)) {
                        Column(Modifier.padding(14.dp)) {
                            Text("Downloading $title ($res)", color = TextPrimary, fontSize = 14.sp)
                            Spacer(Modifier.height(8.dp))
                            LinearProgressIndicator(
                                progress = { e.value },
                                modifier = Modifier.fillMaxWidth(),
                                color = ElectricBlue,
                                trackColor = NavySurface
                            )
                        }
                    }
                }
                items(items, key = { it.file.name }) { d ->
                    GlassSurface(
                        Modifier.fillMaxWidth(),
                        RoundedCornerShape(18.dp),
                        onClick = {
                            if (d.wallpaperId != null) nav.navigate("preview/${d.wallpaperId}")
                            else viewFile(ctx, d.file)
                        }
                    ) {
                        Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                            AppImage(d.file, Modifier.size(56.dp, 80.dp).clip(RoundedCornerShape(12.dp)))
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(d.title, color = TextPrimary, fontSize = 15.sp)
                                Text(
                                    "${d.resolution} • ${Formatter.formatShortFileSize(ctx, d.sizeBytes)} • ${dateFmt.format(Date(d.modified))}",
                                    color = TextSecondary,
                                    fontSize = 12.sp
                                )
                            }
                            IconButton(onClick = { nav.navigate("studio?mode=depth&src=${d.file.name}") }) {
                                Icon(Icons.Outlined.Layers, "Depth Studio", tint = NeonCyan)
                            }
                            IconButton(onClick = { shareFile(ctx, d.file) }) {
                                Icon(Icons.Outlined.Share, "Share", tint = NeonCyan)
                            }
                            IconButton(onClick = { vm.saveToGallery(d.file) }) {
                                Icon(Icons.Outlined.BookmarkAdd, "Save to Gallery", tint = NeonCyan)
                            }
                            IconButton(onClick = { toDelete = d }) {
                                Icon(Icons.Outlined.Delete, "Delete", tint = HeartRed)
                            }
                        }
                    }
                }
            }
        }
    }

    toDelete?.let { d ->
        AlertDialog(
            onDismissRequest = { toDelete = null },
            containerColor = NavySurface,
            title = { Text("Delete download?", color = TextPrimary) },
            text = { Text("${d.title} (${d.resolution}) will be removed from this device.", color = TextSecondary) },
            confirmButton = {
                TextButton(onClick = { vm.delete(d); toDelete = null }) { Text("Delete", color = HeartRed) }
            },
            dismissButton = {
                TextButton(onClick = { toDelete = null }) { Text("Cancel", color = TextSecondary) }
            }
        )
    }
}
