package com.depth.wallpaper.data

import android.net.Uri
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Fetches openly licensed images from Openverse. No API key is needed for basic anonymous access. */
object OpenverseRepository {
    private val categoryQueries = mapOf(
        "Nature" to "nature landscape wallpaper",
        "Mountains" to "mountain landscape wallpaper",
        "Anime" to "anime illustration wallpaper",
        "Cars" to "sports car wallpaper",
        "Space" to "galaxy nebula space wallpaper",
        "Abstract" to "abstract digital art wallpaper",
        "Minimal" to "minimal dark wallpaper",
        "Animals" to "wildlife animal wallpaper",
        "Architecture" to "architecture city wallpaper",
        "City" to "city night skyline wallpaper"
    )

    fun search(query: String, category: String?, page: Int = 1): List<Wallpaper> {
        val effectiveQuery = when {
            query.isNotBlank() -> query.trim().take(180)
            category != null && category != "All" -> categoryQueries[category] ?: "$category wallpaper"
            else -> "mobile wallpaper nature landscape"
        }
        val encoded = Uri.encode(effectiveQuery)
        val endpoint = "https://api.openverse.org/v1/images/?q=$encoded&license_type=commercial&page_size=20&page=${page.coerceAtLeast(1)}&filter_dead=true"
        val connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 12_000
            readTimeout = 18_000
            setRequestProperty("Accept", "application/json")
            setRequestProperty("User-Agent", "DepthWallpaper-Android/4.1 (Openverse API client)")
        }
        try {
            val code = connection.responseCode
            if (code !in 200..299) throw java.io.IOException("Openverse HTTP $code")
            val body = connection.inputStream.bufferedReader().use { it.readText() }
            val results = JSONObject(body).optJSONArray("results") ?: return emptyList()
            val fallbackCategory = category?.takeIf { it != "All" } ?: "Discover"
            return buildList {
                for (i in 0 until results.length()) {
                    val item = results.optJSONObject(i) ?: continue
                    val imageUrl = item.optString("url").takeIf { it.startsWith("https://") || it.startsWith("http://") } ?: continue
                    val thumbnail = item.optString("thumbnail").takeIf { it.startsWith("https://") || it.startsWith("http://") } ?: imageUrl
                    val title = item.optString("title").takeIf { it.isNotBlank() && it != "null" } ?: "Openly Licensed Wallpaper"
                    val uuid = item.optString("id").takeIf { it.isNotBlank() && it != "null" } ?: "${page}_$i"
                    val creator = item.optString("creator").takeIf { it.isNotBlank() && it != "null" } ?: "Creator not listed"
                    val license = item.optString("license").takeIf { it.isNotBlank() && it != "null" } ?: "Check source licence"
                    val licenseUrl = item.optString("license_url").takeIf { it.startsWith("http") }
                    val sourceUrl = item.optString("foreign_landing_url").takeIf { it.startsWith("http") }
                    val safeCategory = category?.takeIf { it != "All" } ?: fallbackCategory
                    add(Wallpaper(
                        id = "ov_${uuid.replace(Regex("[^A-Za-z0-9_-]"), "_")}",
                        title = title,
                        category = safeCategory,
                        seed = "openverse-${uuid.hashCode().toUInt().toString(16)}",
                        imageUrl = imageUrl,
                        thumbnailUrl = thumbnail,
                        creator = creator,
                        license = license,
                        licenseUrl = licenseUrl,
                        sourceUrl = sourceUrl
                    ))
                }
            }
        } finally {
            connection.disconnect()
        }
    }
}
