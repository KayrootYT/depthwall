package com.depth.wallpaper.ui.screens

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.depth.wallpaper.data.GenStyle
import com.depth.wallpaper.data.WallpaperGenerator
import com.depth.wallpaper.data.applyWallpaper
import com.depth.wallpaper.ui.AppViewModel
import com.depth.wallpaper.ui.components.GlassChip
import com.depth.wallpaper.ui.components.GlassSurface
import com.depth.wallpaper.ui.components.GradientButton
import com.depth.wallpaper.ui.components.SetWallpaperDialog
import com.depth.wallpaper.ui.components.TopBar
import com.depth.wallpaper.ui.theme.ElectricBlue
import com.depth.wallpaper.ui.theme.NeonCyan
import com.depth.wallpaper.ui.theme.TextPrimary
import com.depth.wallpaper.ui.theme.TextSecondary
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.random.Random

private val SAMPLE_PROMPTS = listOf(
    "neon city street at night, rain",
    "misty mountains at sunrise, cinematic",
    "astronaut standing on a red planet",
    "lonely lighthouse in a stormy sea",
    "cherry blossom forest, anime style"
)

/** Free wallpaper generator: online AI prompt (no key) + offline procedural styles. */
@Composable
fun GenerateScreen(vm: AppViewModel, nav: NavHostController) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var style by rememberSaveable { mutableStateOf(GenStyle.MESH.name) }
    var prompt by rememberSaveable { mutableStateOf("") }
    var bmp by remember { mutableStateOf<Bitmap?>(null) }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var showSet by remember { mutableStateOf(false) }

    val metrics = ctx.resources.displayMetrics
    val ratio = metrics.heightPixels.toFloat() / metrics.widthPixels
    val current = GenStyle.valueOf(style)

    fun generate() {
        if (busy) return
        scope.launch {
            busy = true
            error = null
            val seed = Random.nextLong(1, 1_000_000_000)
            if (current == GenStyle.AI) {
                val w = 768
                val h = ((w * ratio) / 8f).toInt() * 8
                WallpaperGenerator.ai(prompt, w, h.coerceIn(768, 1536), seed)
                    .onSuccess { bmp = it }
                    .onFailure { error = "AI generation failed (${it.message}). Check your internet and try again." }
            } else {
                val w = 1080
                val h = (w * ratio).toInt()
                bmp = withContext(Dispatchers.Default) {
                    runCatching { WallpaperGenerator.procedural(current, seed, w, h) }.getOrNull()
                }
                if (bmp == null) error = "Not enough memory to generate this wallpaper."
            }
            busy = false
        }
    }

    LaunchedEffect(Unit) { if (bmp == null) generate() }

    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
        TopBar("Generate", onBack = { nav.popBackStack() })

        Row(
            Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            GenStyle.values().forEach { s ->
                GlassChip(s.label, s == current) {
                    style = s.name
                    if (s != GenStyle.AI) {
                        // procedural styles are instant: regenerate right away
                        scope.launch {
                            busy = true
                            error = null
                            val w = 1080
                            val h = (w * ratio).toInt()
                            bmp = withContext(Dispatchers.Default) {
                                runCatching { WallpaperGenerator.procedural(s, Random.nextLong(1, 1_000_000_000), w, h) }.getOrNull()
                            }
                            busy = false
                        }
                    }
                }
            }
        }

        if (current == GenStyle.AI) {
            Column(Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                OutlinedTextField(
                    value = prompt,
                    onValueChange = { prompt = it },
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("Describe your wallpaper…", color = TextSecondary) },
                    maxLines = 2,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedBorderColor = NeonCyan,
                        unfocusedBorderColor = Color.White.copy(alpha = 0.25f),
                        cursorColor = NeonCyan
                    )
                )
                Spacer(Modifier.height(6.dp))
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SAMPLE_PROMPTS.forEach { sp -> GlassChip(sp, false) { prompt = sp } }
                }
                Text(
                    "Free online AI (no account). Uses a public third-party service, so it needs internet and can be slow.",
                    color = TextSecondary, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp)
                )
            }
        }

        Box(
            Modifier.weight(1f).fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp),
            contentAlignment = Alignment.Center
        ) {
            val shown = bmp
            if (shown != null) {
                Image(
                    bitmap = shown.asImageBitmap(),
                    contentDescription = "Generated wallpaper",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .aspectRatio(1f / ratio, matchHeightConstraintsFirst = true)
                        .clip(RoundedCornerShape(22.dp))
                )
            }
            if (busy) CircularProgressIndicator(color = NeonCyan, modifier = Modifier.size(40.dp))
            error?.let { Text(it, color = TextSecondary, fontSize = 13.sp, modifier = Modifier.padding(24.dp)) }
        }

        Column(Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
            GradientButton(
                text = if (current == GenStyle.AI) "Generate with AI" else "Shuffle",
                modifier = Modifier.fillMaxWidth(),
                icon = Icons.Outlined.AutoAwesome,
                enabled = !busy
            ) { generate() }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                GenButton("Depth Studio", bmp != null && !busy, Modifier.weight(1.4f)) {
                    val b = bmp ?: return@GenButton
                    scope.launch {
                        val f = vm.saveEdited(b)
                        nav.navigate("studio?mode=depth&src=${f.name}")
                    }
                }
                GenButton("Save", bmp != null && !busy, Modifier.weight(1f)) {
                    val b = bmp ?: return@GenButton
                    scope.launch {
                        vm.saveEdited(b)
                        vm.say("Saved to Downloads")
                    }
                }
                GenButton("Set", bmp != null && !busy, Modifier.weight(1f)) { showSet = true }
            }
        }
    }

    if (showSet) {
        SetWallpaperDialog(onDismiss = { showSet = false }) { target ->
            showSet = false
            val b = bmp ?: return@SetWallpaperDialog
            scope.launch {
                val f = vm.saveEdited(b)
                applyWallpaper(ctx, f, target)
                    .onSuccess { vm.say("Wallpaper set!") }
                    .onFailure { vm.say("Couldn't set wallpaper: ${it.message}") }
            }
        }
    }
}

@Composable
private fun GenButton(text: String, enabled: Boolean, modifier: Modifier, onClick: () -> Unit) {
    GlassSurface(modifier.height(52.dp), RoundedCornerShape(16.dp), onClick = { if (enabled) onClick() }) {
        Text(
            text,
            color = if (enabled) TextPrimary else TextSecondary,
            fontWeight = FontWeight.SemiBold,
            fontSize = 14.sp,
            modifier = Modifier.align(Alignment.Center)
        )
    }
}
