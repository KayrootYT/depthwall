# Live Scene Particle Effects

Added to Depth Studio > Motion tab:
- Off
- Rain (light blue streaks)
- Snow (soft white flakes)
- Petals (pink drifting petals)
- Particle density slider

The overlay is drawn by LiveWallpaperService on top of the depth scene. It runs only when an effect is selected; Battery Saver uses a slower particle update interval. Settings are stored in DepthConfigStore and applied when the live wallpaper is launched.

Note: the particle overlay is intentionally lightweight Canvas drawing. Compile and device-test before release; GPU/battery impact varies by device and selected effect.
