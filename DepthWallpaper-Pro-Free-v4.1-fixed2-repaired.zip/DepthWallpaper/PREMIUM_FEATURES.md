# Premium Feature Pack — 10-feature checklist

This checklist maps each requested premium feature to the current app implementation. It deliberately distinguishes existing functionality from capabilities that still need a separate model/backend.

1. **AI Depth Studio Pro** — Depth Studio has adjustable heuristic depth estimation, subject-mask controls, layers, blur, contrast and save/apply/share actions. **Limitation:** current `DepthPipeline` is heuristic-based; it is not a neural AI depth model.
2. **Motion Parallax Pro** — Existing live wallpaper scene supports gyroscope/touch/auto-float input, intensity, response, invert direction and depth layers.
3. **Dynamic Liquid Glass UI** — Existing Compose glass surfaces, gradient styling, selected-state animation and screen transitions are retained.
4. **AMOLED Battery Mode** — Battery Saver profile lowers layers, disables background blur in the preset, and limits live rendering to 30 fps.
5. **Daily Wallpaper Drop** — Online feed aggregates Wallhaven (SFW discovery), Wikimedia Commons (licence metadata) and NASA Images. Feed is refreshed from Profile; provider availability/rate limits apply.
6. **Depth Clock & Parallax** — Existing clock can sit between scene layers; supports date, 12/24-hour mode, font weight, size, vertical position and colour.
7. **Smart Wallpaper Feed** — Existing favorites, downloads, history, online category search and pagination are retained.
8. **AI Wallpaper Generator** — Existing online generation attempt plus local procedural generator fallback. Online generation can fail/rate-limit; it is not guaranteed to be free or always available.
9. **Performance Control Center** — Profile exposes Battery Saver, Balanced and Ultra Quality presets and current layer count.
10. **Live Scene Effects** — Existing depth/3D tilt/classic modes, background blur and motion controls are linked from the hub. **Limitation:** separate rain/snow particle overlays are not implemented as independent scene effects in this build.

## Source and licensing notes

- Wallhaven is used for wallpaper discovery, not as a blanket open-license source. Check each creator's rights before redistribution.
- Wikimedia Commons entries are filtered by licence metadata where available; attribution and each item's licence should be retained.
- NASA images should still be checked for item-specific credit and third-party restrictions.
- The project has not been compiled or device-tested in this packaging environment. Run GitHub Actions and test on the target Android device before release.
