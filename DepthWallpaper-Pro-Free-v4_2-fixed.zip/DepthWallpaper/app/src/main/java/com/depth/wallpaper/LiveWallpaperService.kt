package com.depth.wallpaper

import android.app.ActivityManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.os.Process
import android.os.SystemClock
import android.service.wallpaper.WallpaperService
import android.util.Log
import android.view.MotionEvent
import android.view.SurfaceHolder
import com.depth.wallpaper.data.DepthConfig
import com.depth.wallpaper.data.DepthConfigStore
import com.depth.wallpaper.data.DepthMode
import com.depth.wallpaper.data.DepthPipeline
import com.depth.wallpaper.data.DepthRenderer
import com.depth.wallpaper.data.DepthScene
import com.depth.wallpaper.data.InputMode
import com.depth.wallpaper.data.ParallaxTracker
import com.depth.wallpaper.data.ParticleEffects
import com.depth.wallpaper.data.SceneBuilder
import java.io.File
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin

/**
 * Live wallpaper: layered depth parallax, 3D tilt, classic parallax, optional depth clock.
 *
 * Stability notes (v4.2):
 *  - A WallpaperService runs inside the app process, so its Engine callbacks run on the app's MAIN
 *    thread. Previously every frame was drawn on that thread; when the surface blocked (lock /
 *    unlockCanvasAndPost) the whole app AND the wallpaper froze -> black screen + hang.
 *    Now all drawing / sensor handling happens on a dedicated render thread and the heavy scene
 *    build happens on a separate low-priority thread. The main thread only forwards events.
 *  - Software canvas (lockCanvas) is used instead of lockHardwareCanvas, and bitmaps are only
 *    recycled by the render thread, so a bitmap can never be freed while it is being drawn.
 *  - A draw error no longer paints a black frame and retriggers itself in an endless loop.
 */
class LiveWallpaperService : WallpaperService() {
    override fun onCreateEngine(): Engine = DepthEngine()

    private inner class DepthEngine : Engine(), SensorEventListener {
        private val manager = getSystemService(SENSOR_SERVICE) as SensorManager
        private val sensor: Sensor? = manager.getDefaultSensor(Sensor.TYPE_GAME_ROTATION_VECTOR)
            ?: manager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
        private val lowRam = runCatching {
            (getSystemService(ACTIVITY_SERVICE) as ActivityManager).isLowRamDevice
        }.getOrDefault(false)

        private val renderThread = HandlerThread("DepthRender", Process.THREAD_PRIORITY_DISPLAY).also { it.start() }
        private val buildThread = HandlerThread("DepthBuild", Process.THREAD_PRIORITY_BACKGROUND).also { it.start() }
        private val handler = Handler(renderThread.looper)      // render thread
        private val buildHandler = Handler(buildThread.looper)  // scene building
        private val main = Handler(Looper.getMainLooper())

        // ---- state owned by the render thread ----
        private val tracker = ParallaxTracker()
        private val renderer = DepthRenderer()
        private val particleEffects = ParticleEffects()
        private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private var cfg = DepthConfig()
        private var scene: DepthScene? = null
        private var loadedSig = ""
        private var loading = false
        private var buildFailed = false
        private var visible = false
        private var framePending = false
        private var idle = false
        private var surfaceW = 1
        private var surfaceH = 1
        private var dirty = true
        private var lastMinute = -1L
        private var lastDrawTime = 0L
        private var failures = 0

        // ---- shared across threads ----
        @Volatile private var destroyed = false
        @Volatile private var hasSurface = false
        @Volatile private var touchMode = false
        private val drawLock = Any()

        private val imageFile get() = File(filesDir, "live_wallpaper.jpg")
        private val depthFile get() = File(filesDir, "live_depth.png")
        private val frameRunnable = Runnable { frame() }

        // ------------------------------------------------------------------ Engine callbacks (main thread)

        override fun onCreate(surfaceHolder: SurfaceHolder) {
            super.onCreate(surfaceHolder)
            handler.post { cfg = DepthConfigStore.load(this@LiveWallpaperService) }
        }

        override fun onVisibilityChanged(isVisible: Boolean) {
            handler.post { applyVisibility(isVisible) }
        }

        override fun onSurfaceCreated(holder: SurfaceHolder) {
            super.onSurfaceCreated(holder)
            hasSurface = true
        }

        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height)
            hasSurface = true
            val w = width.coerceAtLeast(1)
            val h = height.coerceAtLeast(1)
            handler.post {
                surfaceW = w
                surfaceH = h
                dirty = true
                loadIfNeeded()
                wake()
            }
        }

        override fun onSurfaceRedrawNeeded(holder: SurfaceHolder) {
            super.onSurfaceRedrawNeeded(holder)
            handler.post { dirty = true; wake() }
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder) {
            // Flag first, then wait for an in-flight draw to finish: the surface must not be touched
            // once this callback returns.
            hasSurface = false
            synchronized(drawLock) { /* wait for the render thread to leave drawFrame() */ }
            handler.post { stopFrames() }
            super.onSurfaceDestroyed(holder)
        }

        override fun onTouchEvent(event: MotionEvent) {
            if (!touchMode) return
            val action = event.actionMasked
            val nx = (event.x / surfaceW - 0.5f) * 2f
            val ny = (event.y / surfaceH - 0.5f) * 2f
            handler.post {
                when (action) {
                    MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> tracker.setTarget(nx, ny)
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> tracker.setTarget(0f, 0f)
                }
                wake()
            }
        }

        override fun onDestroy() {
            destroyed = true
            hasSurface = false
            runCatching { manager.unregisterListener(this) }
            handler.removeCallbacksAndMessages(null)
            buildHandler.removeCallbacksAndMessages(null)
            synchronized(drawLock) { }
            handler.post {
                scene?.recycle()
                scene = null
                renderThread.quitSafely()
            }
            buildThread.quitSafely()
            super.onDestroy()
        }

        // ------------------------------------------------------------------ render thread

        private fun applyVisibility(isVisible: Boolean) {
            if (destroyed) return
            visible = isVisible
            if (isVisible) {
                val c = DepthConfigStore.load(this@LiveWallpaperService)
                cfg = c
                touchMode = c.input == InputMode.TOUCH
                main.post { if (!destroyed) runCatching { setTouchEventsEnabled(c.input == InputMode.TOUCH) } }
                loadIfNeeded() // picks up a new photo / new settings
                tracker.reset()
                runCatching { manager.unregisterListener(this) }
                if (c.input == InputMode.GYRO && sensor != null) {
                    runCatching {
                        manager.registerListener(this, sensor, SensorManager.SENSOR_DELAY_GAME, handler)
                    }
                }
                dirty = true
                wake()
            } else {
                runCatching { manager.unregisterListener(this) }
                stopFrames()
            }
        }

        override fun onSensorChanged(event: SensorEvent) { // delivered on the render thread
            if (destroyed) return
            tracker.onSensor(event.values)
            if (idle) wake()
        }

        override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit

        private fun stopFrames() {
            handler.removeCallbacks(frameRunnable)
            framePending = false
            idle = false
        }

        private fun scheduleFrame(delayMs: Long) {
            if (!framePending && visible && !destroyed) {
                framePending = true
                handler.postDelayed(frameRunnable, delayMs)
            }
        }

        /** Cancel a pending idle wait and render the next frame right away. */
        private fun wake() {
            if (!visible || destroyed) return
            handler.removeCallbacks(frameRunnable)
            framePending = false
            idle = false
            scheduleFrame(0L)
        }

        private fun frame() {
            framePending = false
            idle = false
            if (!visible || destroyed) return
            val start = SystemClock.uptimeMillis()
            val c = cfg
            if (c.input == InputMode.AUTO) {
                val t = start / 1000.0
                tracker.setTarget((sin(t * 0.9) * 0.9).toFloat(), (cos(t * 0.65) * 0.6).toFloat())
            }
            val moved = tracker.step(c.response)
            if (c.clockOn) {
                val minute = System.currentTimeMillis() / 60000L
                if (minute != lastMinute) {
                    lastMinute = minute
                    dirty = true
                }
            }
            val particlesOn = c.particleEffect != "OFF" && scene != null
            if (hasSurface && (moved || dirty || particlesOn)) drawFrame()

            val keepRunning = hasSurface && (moved || particlesOn || dirty || c.input == InputMode.AUTO)
            if (keepRunning) {
                val frameMs = if (c.batterySaver) 50L else 33L // 20 / 30 fps is plenty for parallax
                val spent = SystemClock.uptimeMillis() - start
                scheduleFrame((frameMs - spent).coerceAtLeast(6L))
            } else {
                // Nothing to animate: poll slowly (clock minute change); sensor / touch events wake us.
                idle = true
                scheduleFrame(250L)
            }
        }

        private fun signature(): String {
            val c = cfg
            val classic = c.mode == DepthMode.CLASSIC
            val img = imageFile.let { if (it.exists()) it.lastModified() else 0L }
            val dep = depthFile.let { if (it.exists()) it.lastModified() else 0L }
            return "$img|$dep|${surfaceW}x$surfaceH|$classic|${c.layers}|${c.fgCut}|${c.bgBlur}"
        }

        private fun loadIfNeeded() {
            if (destroyed || surfaceW <= 1 || surfaceH <= 1) return // wait for the real surface size
            val sig = signature()
            if (loading || sig == loadedSig) return
            loading = true
            val w = surfaceW
            val h = surfaceH
            val c = cfg
            val posted = buildHandler.post {
                val next = try {
                    buildScene(c, w, h)
                } catch (t: Throwable) {
                    Log.w(TAG, "Scene build failed", t)
                    null
                }
                val delivered = handler.post {
                    loading = false
                    if (destroyed) {
                        next?.recycle()
                        return@post
                    }
                    val old = scene
                    scene = next
                    buildFailed = next == null
                    loadedSig = sig
                    dirty = true
                    old?.recycle() // safe: only this thread draws, and drawing is synchronous
                    wake()
                    // Settings may have changed while we were building.
                    if (visible) loadIfNeeded()
                }
                if (!delivered) next?.recycle()
            }
            if (!posted) loading = false
        }

        // ------------------------------------------------------------------ scene building (build thread)

        private fun decodeSampled(path: String, startSample: Int): Bitmap? {
            var sample = startSample
            repeat(3) {
                try {
                    val opts = BitmapFactory.Options().apply {
                        inSampleSize = sample
                        inPreferredConfig = Bitmap.Config.ARGB_8888
                    }
                    return BitmapFactory.decodeFile(path, opts)
                } catch (_: OutOfMemoryError) {
                    sample *= 2 // low memory: retry smaller
                }
            }
            return null
        }

        private fun buildScene(c: DepthConfig, w: Int, h: Int): DepthScene? {
            val f = imageFile
            if (!f.exists() || f.length() == 0L) return null
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(f.absolutePath, bounds)
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null

            val limit = (max(w, h) * 1.05f).toInt().coerceIn(720, if (lowRam) 960 else 1280)
            var sample = 1
            while (max(bounds.outWidth, bounds.outHeight) / (sample * 2) >= limit) sample *= 2
            var src = decodeSampled(f.absolutePath, sample) ?: return null

            // Never keep a bitmap much larger than we can usefully draw.
            val longSide = max(src.width, src.height)
            if (longSide > limit) {
                val k = limit.toFloat() / longSide
                val scaled = runCatching {
                    Bitmap.createScaledBitmap(src, max(2, (src.width * k).toInt()), max(2, (src.height * k).toInt()), true)
                }.getOrNull()
                if (scaled != null && scaled !== src) {
                    src.recycle()
                    src = scaled
                }
            }

            val d = depthFile
            if (c.mode == DepthMode.CLASSIC || !d.exists()) return DepthScene(src, emptyList())
            val depthBmp = runCatching { BitmapFactory.decodeFile(d.absolutePath) }.getOrNull()
                ?: return DepthScene(src, emptyList())

            // If depth slicing fails (e.g. out of memory), fall back to the plain photo instead of
            // leaving a black wallpaper.
            return try {
                val field = DepthPipeline.fromGray(depthBmp)
                val safeLayers = c.layers.coerceIn(2, if (lowRam) 3 else 4)
                val safeBlur = c.bgBlur.coerceIn(0f, 0.25f)
                val sc = SceneBuilder.build(src, field, safeLayers, c.fgCut, safeBlur, limit)
                src.recycle()
                sc
            } catch (t: Throwable) {
                Log.w(TAG, "Depth slicing failed, using flat photo", t)
                DepthScene(src, emptyList())
            } finally {
                if (!depthBmp.isRecycled) depthBmp.recycle()
            }
        }

        // ------------------------------------------------------------------ drawing (render thread)

        private fun drawFrame() {
            if (!hasSurface) return
            synchronized(drawLock) {
                if (!hasSurface) return
                val holder = surfaceHolder
                var canvas: Canvas? = null
                try {
                    // Software canvas on purpose: lockHardwareCanvas() on wallpaper surfaces is what
                    // produced the black screen / freeze on several devices.
                    canvas = holder.lockCanvas() ?: return
                    val sc = scene
                    if (sc != null && !sc.base.isRecycled) {
                        renderer.draw(canvas, surfaceW, surfaceH, sc, cfg, tracker.x, tracker.y)
                        val now = SystemClock.uptimeMillis()
                        val dt = if (lastDrawTime == 0L) 0.033f else (now - lastDrawTime).coerceIn(1L, 50L) / 1000f
                        lastDrawTime = now
                        if (cfg.particleEffect != "OFF") {
                            // A particle problem must never blank the wallpaper itself.
                            runCatching {
                                particleEffects.draw(canvas, surfaceW, surfaceH, cfg.particleEffect, cfg.particleIntensity, dt)
                            }
                        }
                    } else {
                        canvas.drawColor(Color.BLACK)
                        val msg = when {
                            !imageFile.exists() -> "Open Depth Wallpaper and pick a wallpaper"
                            buildFailed -> "Couldn't load wallpaper. Re-apply it from the app."
                            else -> null
                        }
                        if (msg != null) {
                            textPaint.color = Color.WHITE
                            textPaint.textSize = 16f * resources.displayMetrics.density
                            textPaint.textAlign = Paint.Align.CENTER
                            canvas.drawText(msg, surfaceW / 2f, surfaceH / 2f, textPaint)
                        }
                    }
                    dirty = false
                    failures = 0
                } catch (t: Throwable) {
                    // Do NOT mark dirty again: that made a persistent error spin forever on a black frame.
                    Log.w(TAG, "Draw failed", t)
                    dirty = false
                    if (++failures >= 3 && scene != null) {
                        // Scene is probably corrupt; drop it and rebuild from the files.
                        val bad = scene
                        scene = null
                        loadedSig = ""
                        bad?.recycle()
                        failures = 0
                        handler.post { loadIfNeeded() }
                    }
                } finally {
                    val c = canvas
                    if (c != null) runCatching { holder.unlockCanvasAndPost(c) }
                }
            }
        }
    }

    private companion object {
        const val TAG = "DepthWallpaper"
    }
}
