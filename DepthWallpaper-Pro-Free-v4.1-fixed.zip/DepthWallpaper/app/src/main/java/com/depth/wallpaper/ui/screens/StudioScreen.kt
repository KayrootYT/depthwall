package com.depth.wallpaper.ui.screens

import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Layers
import androidx.compose.material.icons.outlined.PhotoLibrary
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.navigation.NavHostController
import com.depth.wallpaper.LiveWallpaperService
import com.depth.wallpaper.data.DepthConfig
import com.depth.wallpaper.data.DepthConfigStore
import com.depth.wallpaper.data.DepthField
import com.depth.wallpaper.data.DepthMode
import com.depth.wallpaper.data.DepthParams
import com.depth.wallpaper.data.DepthPipeline
import com.depth.wallpaper.data.DepthRenderer
import com.depth.wallpaper.data.DepthScene
import com.depth.wallpaper.data.InputMode
import com.depth.wallpaper.data.ParallaxTracker
import com.depth.wallpaper.data.Resolution
import com.depth.wallpaper.data.SceneBuilder
import com.depth.wallpaper.data.WallpaperRepository
import com.depth.wallpaper.data.applyWallpaper
import com.depth.wallpaper.data.decodeScaled
import com.depth.wallpaper.data.shareFile
import com.depth.wallpaper.ui.AppViewModel
import com.depth.wallpaper.ui.components.GlassChip
import com.depth.wallpaper.ui.components.GlassSurface
import com.depth.wallpaper.ui.components.GradientButton
import com.depth.wallpaper.ui.components.SetWallpaperDialog
import com.depth.wallpaper.ui.components.TopBar
import com.depth.wallpaper.ui.theme.ElectricBlue
import com.depth.wallpaper.ui.theme.NavySurface
import com.depth.wallpaper.ui.theme.NeonCyan
import com.depth.wallpaper.ui.theme.TextPrimary
import com.depth.wallpaper.ui.theme.TextSecondary
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.math.sin

private const val PREVIEW_SIDE = 960
private const val STILL_SIDE = 1920

private fun initialConfig(ctx: Context, mode: String?): DepthConfig {
    val c = DepthConfigStore.load(ctx)
    return when (mode) {
        "parallax" -> c.copy(mode = DepthMode.DEPTH, clockOn = false)
        "clock" -> c.copy(mode = DepthMode.DEPTH, clockOn = true)
        "tilt" -> c.copy(mode = DepthMode.TILT3D)
        "auto" -> c.copy(mode = DepthMode.DEPTH, input = InputMode.AUTO)
        else -> c
    }
}

/**
 * Depth Studio: pick a photo, build a depth map, tune it, preview it live, then set it as a
 * live wallpaper (depth parallax / 3D tilt / depth clock) or export a still.
 */
@Composable
fun StudioScreen(vm: AppViewModel, nav: NavHostController, modeArg: String?, srcArg: String?) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val lifecycleOwner = LocalLifecycleOwner.current
    val renderer = remember { DepthRenderer() }
    val tracker = remember { ParallaxTracker() }

    var cfg by remember { mutableStateOf(initialConfig(ctx, modeArg)) }
    var params by remember { mutableStateOf(DepthParams()) }
    var source by remember { mutableStateOf<Bitmap?>(null) }
    var work by remember { mutableStateOf<DepthPipeline.Work?>(null) }
    var field by remember { mutableStateOf<DepthField?>(null) }
    var scene by remember { mutableStateOf<DepthScene?>(null) }
    var depthBmp by remember { mutableStateOf<Bitmap?>(null) }
    var maskArr by remember { mutableStateOf<FloatArray?>(null) }
    var maskVersion by remember { mutableIntStateOf(0) }
    var maskCoverage by remember { mutableFloatStateOf(0f) }
    var selectMode by remember { mutableStateOf(false) }
    var tolerance by remember { mutableFloatStateOf(0.35f) }
    var showDepth by remember { mutableStateOf(false) }
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var busy by remember { mutableStateOf(false) }
    var showSet by remember { mutableStateOf(false) }
    var ox by remember { mutableFloatStateOf(0f) }
    var oy by remember { mutableFloatStateOf(0f) }

    val metrics = ctx.resources.displayMetrics
    val aspect = metrics.widthPixels.toFloat() / metrics.heightPixels
    val hasGyro = remember {
        val sm = ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        (sm.getDefaultSensor(Sensor.TYPE_GAME_ROTATION_VECTOR) ?: sm.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)) != null
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            scope.launch {
                busy = true
                val bmp = withContext(Dispatchers.IO) { runCatching { decodeScaled(ctx, uri, 2560) }.getOrNull() }
                if (bmp == null) vm.say("Couldn't open that image") else {
                    maskArr = null
                    maskCoverage = 0f
                    field = null
                    source = bmp
                }
                busy = false
            }
        }
    }
    fun pick() = picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))

    // ---- load the photo that was passed in (catalogue wallpaper or a saved file) ----
    LaunchedEffect(srcArg) {
        val a = srcArg ?: return@LaunchedEffect
        busy = true
        val bmp: Bitmap? = if (a.startsWith("wp_")) {
            val wp = WallpaperRepository.byId(a.removePrefix("wp_"))
            if (wp == null) null else {
                val f = vm.fetch(wp, Resolution.QHD).getOrNull()
                if (f == null) null else withContext(Dispatchers.IO) {
                    runCatching { decodeScaled(ctx, Uri.fromFile(f), 2560) }.getOrNull()
                }
            }
        } else {
            val f = vm.fileNamed(a)
            withContext(Dispatchers.IO) { runCatching { decodeScaled(ctx, Uri.fromFile(f), 2560) }.getOrNull() }
        }
        if (bmp == null) vm.say("Couldn't open that image. Check your connection.") else source = bmp
        busy = false
    }

    // ---- depth pipeline ----
    LaunchedEffect(source) {
        val s = source ?: return@LaunchedEffect
        work = withContext(Dispatchers.Default) { DepthPipeline.prepare(s) }
    }
    LaunchedEffect(work, params, maskVersion) {
        val wk = work ?: return@LaunchedEffect
        delay(100)
        busy = true
        val subject = maskArr
        val f = withContext(Dispatchers.Default) { DepthPipeline.estimate(wk, params, subject) }
        field = f
        val g = withContext(Dispatchers.Default) { DepthPipeline.toGray(f) }
        val old = depthBmp
        depthBmp = g
        old?.recycle()
        busy = false
    }
    LaunchedEffect(field, source, cfg.layers, cfg.fgCut, cfg.bgBlur, cfg.mode == DepthMode.CLASSIC) {
        val s = source ?: return@LaunchedEffect
        val f = field
        val c = cfg
        delay(150)
        busy = true
        val next = withContext(Dispatchers.Default) {
            runCatching {
                if (c.mode == DepthMode.CLASSIC || f == null) SceneBuilder.flat(s, PREVIEW_SIDE)
                else SceneBuilder.build(s, f, c.layers, c.fgCut, c.bgBlur, PREVIEW_SIDE)
            }.getOrNull()
        }
        if (next == null) vm.say("Not enough memory for this photo. Try fewer layers.") else {
            val old = scene
            scene = next
            old?.recycle()
        }
        busy = false
    }
    DisposableEffect(Unit) {
        onDispose {
            scene?.recycle()
            depthBmp?.recycle()
        }
    }

    // ---- motion input ----
    LaunchedEffect(cfg.input) {
        tracker.reset()
        tracker.setTarget(0f, 0f)
    }
    LaunchedEffect(Unit) {
        while (true) {
            withFrameNanos { t ->
                if (cfg.input == InputMode.AUTO) {
                    val sec = t / 1_000_000_000.0
                    tracker.setTarget((sin(sec * 0.9) * 0.9).toFloat(), (cos(sec * 0.65) * 0.6).toFloat())
                }
                if (tracker.step(cfg.response)) {
                    ox = tracker.x
                    oy = tracker.y
                }
            }
        }
    }
    DisposableEffect(cfg.input, lifecycleOwner) {
        val sm = ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val sensor = sm.getDefaultSensor(Sensor.TYPE_GAME_ROTATION_VECTOR) ?: sm.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
        var started = false
        val listener = object : SensorEventListener {
            override fun onSensorChanged(event: SensorEvent) {
                tracker.onSensor(event.values)
            }
            override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit
        }
        fun start() {
            if (cfg.input == InputMode.GYRO && !started && sensor != null) {
                tracker.reset()
                started = sm.registerListener(listener, sensor, SensorManager.SENSOR_DELAY_GAME)
            }
        }
        fun stop() {
            if (started) sm.unregisterListener(listener)
            started = false
        }
        val obs = LifecycleEventObserver { _, ev ->
            when (ev) {
                Lifecycle.Event.ON_RESUME -> start()
                Lifecycle.Event.ON_PAUSE -> stop()
                else -> Unit
            }
        }
        lifecycleOwner.lifecycle.addObserver(obs)
        if (lifecycleOwner.lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED)) start()
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(obs)
            stop()
        }
    }

    // ---- actions ----
    fun pickSubject(ix: Int, iy: Int) {
        val wk = work ?: return
        scope.launch {
            busy = true
            val existing = maskArr
            val tol = tolerance
            val res = withContext(Dispatchers.Default) { DepthPipeline.selectSubject(wk, existing, ix, iy, tol) }
            if (res == null) {
                vm.say("Selection too small or too big. Change the tolerance and tap again.")
            } else {
                maskArr = res.mask
                maskCoverage = res.coverage
                maskVersion++
            }
            busy = false
        }
    }

    suspend fun renderStill(): Bitmap? {
        val s = source ?: return null
        val f = field
        val c = cfg
        var w = metrics.widthPixels
        var h = metrics.heightPixels
        val mx = max(w, h)
        if (mx > 2400) {
            val k = 2400f / mx
            w = (w * k).toInt()
            h = (h * k).toInt()
        }
        val ow = w
        val oh = h
        return withContext(Dispatchers.Default) {
            runCatching {
                val sc = if (c.mode == DepthMode.CLASSIC || f == null) SceneBuilder.flat(s, STILL_SIDE)
                else SceneBuilder.build(s, f, c.layers, c.fgCut, c.bgBlur, STILL_SIDE)
                val bmp = Bitmap.createBitmap(ow, oh, Bitmap.Config.ARGB_8888)
                DepthRenderer().draw(android.graphics.Canvas(bmp), ow, oh, sc, c, 0f, 0f)
                sc.recycle()
                bmp
            }.getOrNull()
        }
    }

    fun applyLive() {
        val s = source ?: return
        val f = field
        val c = cfg
        scope.launch {
            busy = true
            val ok = withContext(Dispatchers.IO) {
                runCatching {
                    DepthConfigStore.save(ctx, c)
                    val tmp = File(ctx.filesDir, "live_wallpaper.jpg.tmp")
                    tmp.outputStream().use { s.compress(Bitmap.CompressFormat.JPEG, 92, it) }
                    val live = File(ctx.filesDir, "live_wallpaper.jpg")
                    if (!tmp.renameTo(live)) { tmp.copyTo(live, overwrite = true); tmp.delete() }
                    val depthFile = File(ctx.filesDir, "live_depth.png")
                    if (f != null && c.mode != DepthMode.CLASSIC) {
                        val dtmp = File(ctx.filesDir, "live_depth.png.tmp")
                        val g = DepthPipeline.toGray(f)
                        dtmp.outputStream().use { g.compress(Bitmap.CompressFormat.PNG, 100, it) }
                        g.recycle()
                        if (!dtmp.renameTo(depthFile)) { dtmp.copyTo(depthFile, overwrite = true); dtmp.delete() }
                    } else {
                        depthFile.delete()
                    }
                }.isSuccess
            }
            busy = false
            if (!ok) {
                vm.say("Couldn't prepare the live wallpaper")
                return@launch
            }
            runCatching {
                val intent = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER).apply {
                    putExtra(
                        WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                        ComponentName(ctx, LiveWallpaperService::class.java)
                    )
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                ctx.startActivity(intent)
            }.onFailure { vm.say("Could not open live wallpaper settings: ${it.message}") }
        }
    }

    // ---- UI ----
    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
        TopBar("Depth Studio", onBack = { nav.popBackStack() }) {
            GlassChip("Photo", false) { pick() }
        }

        Box(
            Modifier.weight(1f).fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
            contentAlignment = Alignment.Center
        ) {
            if (source == null) {
                GlassSurface(Modifier.fillMaxWidth().height(200.dp), RoundedCornerShape(24.dp), onClick = { pick() }) {
                    Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Outlined.PhotoLibrary, null, tint = NeonCyan, modifier = Modifier.size(40.dp))
                        Spacer(Modifier.height(10.dp))
                        Text("Choose a photo", color = TextPrimary, fontWeight = FontWeight.SemiBold)
                        Text("Depth is built on this device. Nothing is uploaded.", color = TextSecondary, fontSize = 12.sp)
                    }
                }
            } else {
                Box(
                    Modifier
                        .aspectRatio(aspect, matchHeightConstraintsFirst = true)
                        .clip(RoundedCornerShape(22.dp))
                        .background(Color.Black)
                        .border(1.dp, Color.White.copy(alpha = 0.25f), RoundedCornerShape(22.dp))
                        .pointerInput(selectMode, cfg.input, cfg.mode, work) {
                            if (selectMode) {
                                detectTapGestures { p ->
                                    val wk = work
                                    val sc = scene
                                    if (wk != null && sc != null) {
                                        val s = renderer.coverScale(size.width, size.height, sc.base.width, sc.base.height, cfg)
                                        val u = ((p.x - size.width / 2f) / s + sc.base.width / 2f) / sc.base.width
                                        val v = ((p.y - size.height / 2f) / s + sc.base.height / 2f) / sc.base.height
                                        pickSubject(
                                            (u * wk.w).toInt().coerceIn(0, wk.w - 1),
                                            (v * wk.h).toInt().coerceIn(0, wk.h - 1)
                                        )
                                    }
                                }
                            } else if (cfg.input == InputMode.TOUCH) {
                                detectDragGestures(
                                    onDragEnd = { tracker.setTarget(0f, 0f) },
                                    onDragCancel = { tracker.setTarget(0f, 0f) }
                                ) { change, _ ->
                                    change.consume()
                                    tracker.setTarget(
                                        (change.position.x / size.width - 0.5f) * 2f,
                                        (change.position.y / size.height - 0.5f) * 2f
                                    )
                                }
                            }
                        }
                ) {
                    Canvas(Modifier.fillMaxSize()) {
                        val sc = scene
                        val w = size.width.toInt()
                        val h = size.height.toInt()
                        if (sc != null && w > 0 && h > 0) {
                            val nc = drawContext.canvas.nativeCanvas
                            val dm = depthBmp
                            if (showDepth && dm != null && !dm.isRecycled) {
                                renderer.drawPlain(nc, w, h, dm)
                            } else {
                                val px = if (selectMode) 0f else ox
                                val py = if (selectMode) 0f else oy
                                renderer.draw(nc, w, h, sc, cfg, px, py)
                            }
                        }
                    }
                    if (selectMode) {
                        Text(
                            "Tap the subject",
                            color = Color.White,
                            fontSize = 12.sp,
                            modifier = Modifier
                                .align(Alignment.TopCenter)
                                .padding(10.dp)
                                .clip(CircleShape)
                                .background(Color.Black.copy(alpha = 0.55f))
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                        )
                    }
                }
            }
            if (busy) CircularProgressIndicator(color = NeonCyan, modifier = Modifier.size(36.dp))
        }

        // ---- control panel ----
        Column(Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Depth", "Motion", "Clock", "Output").forEachIndexed { i, name ->
                    GlassChip(name, tab == i) { tab = i }
                }
            }
            Spacer(Modifier.height(6.dp))
            Column(Modifier.height(230.dp).verticalScroll(rememberScrollState())) {
                when (tab) {
                    0 -> DepthTab(
                        params = params,
                        onParams = { params = it },
                        cfg = cfg,
                        onCfg = { cfg = it },
                        selectMode = selectMode,
                        onSelectMode = { selectMode = it },
                        tolerance = tolerance,
                        onTolerance = { tolerance = it },
                        coverage = maskCoverage,
                        hasSubject = maskArr != null,
                        onClearSubject = {
                            maskArr = null
                            maskCoverage = 0f
                            maskVersion++
                        },
                        showDepth = showDepth,
                        onShowDepth = { showDepth = it }
                    )
                    1 -> MotionTab(cfg, hasGyro) { cfg = it }
                    2 -> ClockTab(cfg) { cfg = it }
                    else -> OutputTab(
                        enabled = source != null && !busy,
                        onLive = { applyLive() },
                        onSet = { showSet = true },
                        onSave = {
                            scope.launch {
                                busy = true
                                val bmp = renderStill()
                                if (bmp == null) vm.say("Couldn't render the image") else {
                                    vm.saveEdited(bmp)
                                    vm.say("Saved to Downloads")
                                    bmp.recycle()
                                }
                                busy = false
                            }
                        },
                        onShare = {
                            scope.launch {
                                busy = true
                                val bmp = renderStill()
                                if (bmp == null) vm.say("Couldn't render the image") else {
                                    val f = vm.saveEdited(bmp)
                                    bmp.recycle()
                                    shareFile(ctx, f)
                                }
                                busy = false
                            }
                        }
                    )
                }
            }
        }
    }

    if (showSet) {
        SetWallpaperDialog(onDismiss = { showSet = false }) { target ->
            showSet = false
            scope.launch {
                busy = true
                val bmp = renderStill()
                if (bmp == null) {
                    vm.say("Couldn't render the image")
                } else {
                    val f = vm.saveEdited(bmp)
                    bmp.recycle()
                    applyWallpaper(ctx, f, target)
                        .onSuccess { vm.say("Still wallpaper set!") }
                        .onFailure { vm.say("Couldn't set wallpaper: ${it.message}") }
                }
                busy = false
            }
        }
    }
}

// ---------------------------------------------------------------- tabs

@Composable
private fun DepthTab(
    params: DepthParams,
    onParams: (DepthParams) -> Unit,
    cfg: DepthConfig,
    onCfg: (DepthConfig) -> Unit,
    selectMode: Boolean,
    onSelectMode: (Boolean) -> Unit,
    tolerance: Float,
    onTolerance: (Float) -> Unit,
    coverage: Float,
    hasSubject: Boolean,
    onClearSubject: () -> Unit,
    showDepth: Boolean,
    onShowDepth: (Boolean) -> Unit
) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        GlassChip(if (selectMode) "Selecting…" else "Tap subject", selectMode) { onSelectMode(!selectMode) }
        if (hasSubject) GlassChip("Clear subject", false) { onClearSubject() }
        GlassChip("Depth map", showDepth) { onShowDepth(!showDepth) }
    }
    if (selectMode || hasSubject) {
        LabeledSlider("Selection tolerance", tolerance) { onTolerance(it) }
        if (hasSubject) Text("Subject covers ${(coverage * 100).toInt()}% of the photo. Tap again to add more.", color = TextSecondary, fontSize = 11.sp)
    }
    LabeledSlider("Layers", cfg.layers.toFloat(), 2f..7f, 4, "${cfg.layers}") { onCfg(cfg.copy(layers = it.roundToInt())) }
    LabeledSlider("Foreground cut-off", cfg.fgCut, 0.3f..0.95f) { onCfg(cfg.copy(fgCut = it)) }
    LabeledSlider("Background blur", cfg.bgBlur) { onCfg(cfg.copy(bgBlur = it)) }
    LabeledSlider("Depth smoothness", params.smooth) { onParams(params.copy(smooth = it)) }
    LabeledSlider("Depth contrast", params.contrast) { onParams(params.copy(contrast = it)) }
    LabeledSlider("Subject / colour pop", params.saliency) { onParams(params.copy(saliency = it)) }
    LabeledSlider("Sharpness (in focus = near)", params.focus) { onParams(params.copy(focus = it)) }
    LabeledSlider("Ground is closer", params.vertical) { onParams(params.copy(vertical = it)) }
    SwitchRow("Invert depth", params.invert) { onParams(params.copy(invert = it)) }
}

@Composable
private fun MotionTab(cfg: DepthConfig, hasGyro: Boolean, onCfg: (DepthConfig) -> Unit) {
    Text("Effect", color = TextSecondary, fontSize = 12.sp)
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        DepthMode.values().forEach { m -> GlassChip(m.label, cfg.mode == m) { onCfg(cfg.copy(mode = m)) } }
    }
    Spacer(Modifier.height(6.dp))
    Text("Controlled by", color = TextSecondary, fontSize = 12.sp)
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        InputMode.values().forEach { m -> GlassChip(m.label, cfg.input == m) { onCfg(cfg.copy(input = m)) } }
    }
    if (!hasGyro) Text("No gyroscope found on this device - use Touch or Auto float.", color = TextSecondary, fontSize = 11.sp)
    LabeledSlider("Intensity", cfg.intensity, 0f..1.5f) { onCfg(cfg.copy(intensity = it)) }
    LabeledSlider("Smoothness (higher = snappier)", cfg.response, 0.04f..0.4f) { onCfg(cfg.copy(response = it)) }
    SwitchRow("Invert motion direction", cfg.invertMotion) { onCfg(cfg.copy(invertMotion = it)) }
    SwitchRow("Battery saver (30 fps)", cfg.batterySaver) { onCfg(cfg.copy(batterySaver = it)) }
}

@Composable
private fun ClockTab(cfg: DepthConfig, onCfg: (DepthConfig) -> Unit) {
    SwitchRow("Depth clock", cfg.clockOn) { onCfg(cfg.copy(clockOn = it)) }
    Text(
        "The clock sits between the background and the foreground layer, so your subject overlaps it. " +
            "Pick the subject on the Depth tab for the best result.",
        color = TextSecondary, fontSize = 11.sp
    )
    if (cfg.clockOn) {
        SwitchRow("24-hour time", cfg.clock24) { onCfg(cfg.copy(clock24 = it)) }
        SwitchRow("Show date", cfg.showDate) { onCfg(cfg.copy(showDate = it)) }
        SwitchRow("Bold font", cfg.clockBold) { onCfg(cfg.copy(clockBold = it)) }
        LabeledSlider("Size", cfg.clockSize, 0.06f..0.2f) { onCfg(cfg.copy(clockSize = it)) }
        LabeledSlider("Vertical position", cfg.clockY, 0.05f..0.9f) { onCfg(cfg.copy(clockY = it)) }
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            DepthConfig.CLOCK_COLOR_NAMES.forEachIndexed { i, n -> GlassChip(n, cfg.clockColor == i) { onCfg(cfg.copy(clockColor = i)) } }
        }
    }
}

@Composable
private fun OutputTab(
    enabled: Boolean,
    onLive: () -> Unit,
    onSet: () -> Unit,
    onSave: () -> Unit,
    onShare: () -> Unit
) {
    GradientButton(
        text = "Set as Live Wallpaper",
        modifier = Modifier.fillMaxWidth(),
        icon = Icons.Outlined.Layers,
        enabled = enabled,
        onClick = onLive
    )
    Text(
        "Keeps your settings: depth layers, 3D tilt, clock and motion. Android will ask you to confirm.",
        color = TextSecondary, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp, bottom = 8.dp)
    )
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        OutButton("Set still", enabled, Modifier.weight(1f), onSet)
        OutButton("Save", enabled, Modifier.weight(1f), onSave)
        OutButton("Share", enabled, Modifier.weight(1f), onShare)
    }
    Text(
        "A still is one frame of the current look (clock included) saved as a normal image wallpaper - no battery use.",
        color = TextSecondary, fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp)
    )
}

@Composable
private fun OutButton(text: String, enabled: Boolean, modifier: Modifier, onClick: () -> Unit) {
    GlassSurface(
        modifier.height(50.dp),
        RoundedCornerShape(16.dp),
        onClick = { if (enabled) onClick() }
    ) {
        Text(
            text,
            color = if (enabled) TextPrimary else TextSecondary,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.align(Alignment.Center)
        )
    }
}

@Composable
private fun LabeledSlider(
    label: String,
    value: Float,
    range: ClosedFloatingPointRange<Float> = 0f..1f,
    steps: Int = 0,
    display: String? = null,
    onChange: (Float) -> Unit
) {
    Column(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth()) {
            Text(label, color = TextSecondary, fontSize = 12.sp, modifier = Modifier.weight(1f))
            Text(display ?: "${(value * 100).toInt()}%", color = TextSecondary, fontSize = 12.sp)
        }
        Slider(
            value = value.coerceIn(range.start, range.endInclusive),
            onValueChange = onChange,
            valueRange = range,
            steps = steps,
            colors = SliderDefaults.colors(
                thumbColor = NeonCyan,
                activeTrackColor = ElectricBlue,
                inactiveTrackColor = Color.White.copy(alpha = 0.15f)
            )
        )
    }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable { onChange(!checked) }.padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, color = TextPrimary, fontSize = 14.sp, modifier = Modifier.weight(1f))
        Switch(
            checked = checked,
            onCheckedChange = onChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = ElectricBlue,
                uncheckedTrackColor = NavySurface
            )
        )
    }
}
