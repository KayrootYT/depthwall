package com.depth.wallpaper.data

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Apartment
import androidx.compose.material.icons.outlined.CropSquare
import androidx.compose.material.icons.outlined.DirectionsCar
import androidx.compose.material.icons.outlined.Eco
import androidx.compose.material.icons.outlined.Face
import androidx.compose.material.icons.outlined.Landscape
import androidx.compose.material.icons.outlined.LocationCity
import androidx.compose.material.icons.outlined.Palette
import androidx.compose.material.icons.outlined.Pets
import androidx.compose.material.icons.outlined.Public
import androidx.compose.ui.graphics.vector.ImageVector
import kotlin.random.Random

/** Edit these after you add your own links. Empty = "not configured yet". */
object AppConfig {
    const val PRIVACY_URL = ""
    const val TERMS_URL = ""
    const val FEEDBACK_EMAIL = ""
}

enum class Resolution(val label: String, val w: Int, val h: Int) {
    HD("HD", 1080, 1920),
    QHD("2K", 1440, 2560),
    UHD("4K", 2160, 3840);

    val dims: String get() = "${w}x$h"
}

data class Category(val name: String, val icon: ImageVector) {
    val coverUrl: String get() = "https://picsum.photos/seed/cover-${name.lowercase()}/400/400.jpg"
    val count: Int get() = WallpaperRepository.all.count { it.category == name }
}

data class Wallpaper(val id: String, val title: String, val category: String, val seed: String) {
    val tags: List<String> get() = listOf(category, title.substringBefore(" "), seed.substringAfter("-", ""))
    fun url(r: Resolution) = "https://picsum.photos/seed/$seed/${r.w}/${r.h}.jpg"
    fun thumb() = "https://picsum.photos/seed/$seed/360/640.jpg"
}

/**
 * DEMO catalogue. Images come from picsum.photos (free, no API key) so the app works out of the box.
 * To use your own wallpapers, replace `all` with data loaded from your own server / API.
 * Never hardcode secret API keys in the app.
 */
object WallpaperRepository {
    val categories: List<Category> = listOf(
        Category("Nature", Icons.Outlined.Eco),
        Category("Mountains", Icons.Outlined.Landscape),
        Category("Anime", Icons.Outlined.Face),
        Category("Cars", Icons.Outlined.DirectionsCar),
        Category("Space", Icons.Outlined.Public),
        Category("Abstract", Icons.Outlined.Palette),
        Category("Minimal", Icons.Outlined.CropSquare),
        Category("Animals", Icons.Outlined.Pets),
        Category("Architecture", Icons.Outlined.Apartment),
        Category("City", Icons.Outlined.LocationCity)
    )

    private val adjectives = listOf(
        "Aurora", "Horizon", "Echo", "Drift", "Ember", "Zenith",
        "Mirage", "Velvet", "Nova", "Haze", "Pulse", "Bloom"
    )

    val all: List<Wallpaper> = categories.flatMap { c ->
        adjectives.mapIndexed { i, a ->
            Wallpaper(
                id = "${c.name.lowercase()}_$i",
                title = "$a ${c.name}",
                category = c.name,
                seed = "${c.name.lowercase()}-$i"
            )
        }
    }.shuffled(Random(42))

    private val byIdMap = all.associateBy { it.id }
    fun byId(id: String): Wallpaper? = byIdMap[id]

    /** Search across title, category and tags. */
    fun search(query: String): List<Wallpaper> {
        val q = query.trim()
        if (q.isBlank()) return all
        return all.filter { w ->
            w.title.contains(q, true) || w.category.contains(q, true) ||
                w.tags.any { it.contains(q, true) }
        }
    }

    val trending: List<Wallpaper> get() = all.take(10)
    val featured: List<Wallpaper> get() = all.drop(10).take(8)
    val recent: List<Wallpaper> get() = all.drop(20).take(10)
    val popular: List<Wallpaper> get() = all.drop(30).take(10)
}
