package com.depth.wallpaper.ui

import androidx.compose.animation.fadeIn
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.fadeOut
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.depth.wallpaper.ui.components.GlassBottomBar
import com.depth.wallpaper.ui.screens.CreateScreen
import com.depth.wallpaper.ui.screens.DownloadsScreen
import com.depth.wallpaper.ui.screens.EditorScreen
import com.depth.wallpaper.ui.screens.ExploreScreen
import com.depth.wallpaper.ui.screens.FavoritesScreen
import com.depth.wallpaper.ui.screens.GenerateScreen
import com.depth.wallpaper.ui.screens.StudioScreen
import com.depth.wallpaper.ui.screens.HistoryScreen
import com.depth.wallpaper.ui.screens.HomeScreen
import com.depth.wallpaper.ui.screens.PreviewScreen
import com.depth.wallpaper.ui.screens.ProfileScreen

private val MAIN_ROUTES = setOf("home", "explore", "create", "favorites", "downloads")

@Composable
fun DepthApp(vm: AppViewModel = viewModel()) {
    val nav = rememberNavController()
    val entry by nav.currentBackStackEntryAsState()
    val base = entry?.destination?.route?.substringBefore("?")
    val showBar = base != null && base in MAIN_ROUTES
    val snackbar = remember { SnackbarHostState() }
    val dynamicTheme by vm.dynamicTheme.collectAsStateWithLifecycle()

    LaunchedEffect(Unit) {
        vm.messages.collect { snackbar.showSnackbar(it) }
    }

    DepthTheme(dynamicTheme) {
    Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        NavHost(
            navController = nav,
            startDestination = "home",
            modifier = Modifier.fillMaxSize(),
            enterTransition = { fadeIn(tween(260)) + scaleIn(tween(320), initialScale = 0.94f) },
            exitTransition = { fadeOut(tween(160)) + scaleOut(tween(220), targetScale = 1.03f) },
            popEnterTransition = { fadeIn(tween(240)) + scaleIn(tween(300), initialScale = 1.03f) },
            popExitTransition = { fadeOut(tween(180)) + scaleOut(tween(240), targetScale = 0.94f) }
        ) {
            composable("home") { HomeScreen(vm, nav) }
            composable(
                "explore?cat={cat}",
                arguments = listOf(navArgument("cat") {
                    type = NavType.StringType
                    nullable = true
                    defaultValue = null
                })
            ) { e -> ExploreScreen(vm, nav, e.arguments?.getString("cat")) }
            composable("create") { CreateScreen(vm, nav) }
            composable("generate") { GenerateScreen(vm, nav) }
            composable(
                "studio?mode={mode}&src={src}",
                arguments = listOf(
                    navArgument("mode") { type = NavType.StringType; nullable = true; defaultValue = null },
                    navArgument("src") { type = NavType.StringType; nullable = true; defaultValue = null }
                )
            ) { e ->
                StudioScreen(vm, nav, e.arguments?.getString("mode"), e.arguments?.getString("src"))
            }
            composable("favorites") { FavoritesScreen(vm, nav) }
            composable("downloads") { DownloadsScreen(vm, nav) }
            composable("profile") { ProfileScreen(vm, nav) }
            composable("history") { HistoryScreen(vm, nav) }
            composable("preview/{id}") { e -> PreviewScreen(vm, nav, e.arguments?.getString("id")) }
            composable("editor/{effect}") { e -> EditorScreen(vm, nav, e.arguments?.getString("effect") ?: "blur") }
        }

        SnackbarHost(
            snackbar,
            Modifier
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .padding(bottom = if (showBar) 112.dp else 150.dp)
        )

        if (showBar) {
            GlassBottomBar(
                selected = base ?: "home",
                onSelect = { route ->
                    nav.navigate(route) {
                        popUpTo(nav.graph.findStartDestination().id) { saveState = true }
                        launchSingleTop = true
                        restoreState = true
                    }
                },
                modifier = Modifier.align(Alignment.BottomCenter)
            )
        }
    }
    }
}
